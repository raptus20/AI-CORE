import React from "react";
import { Header } from "@/components/header";
import { StatusOverview } from "@/components/status-overview";
import { ActivityLog } from "@/components/activity-log";
import { CodeSuggestion } from "@/components/code-suggestion";
import { SystemHealth } from "@/components/system-health";
import { SandboxEnvironment } from "@/components/sandbox-environment";
import { AutonomousImprovement } from "@/components/autonomous-improvement";
import { ConsciousnessViewer } from "@/components/consciousness-viewer";
import { AIChat } from "@/components/ai-chat-advanced";
import { CodeAnalysisDashboard } from "@/components/code-analysis-dashboard";
import { AIProviderStatus } from "@/components/ai-provider-status";
import { ConsciousnessCoreDashboard } from "@/components/consciousness-core-dashboard";

export default function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Status Overview */}
      <div className="card-hover">
        <StatusOverview />
      </div>
      
      {/* Activity & Code Suggestions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 card-hover">
          <ActivityLog limit={5} />
        </div>
        
        <div className="lg:col-span-2 card-hover">
          <CodeSuggestion />
        </div>
      </div>
      
      {/* Autonomous Improvement */}
      <div className="card-hover">
        <AutonomousImprovement />
      </div>

      {/* AI Provider Status */}
      <div className="card-hover">
        <AIProviderStatus />
      </div>
        
      {/* System Health & Sandbox Environment */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card-hover">
          <SystemHealth />
        </div>
        
        <div className="lg:col-span-2 card-hover">
          <SandboxEnvironment />
        </div>
      </div>

      {/* Code Analysis Dashboard - Prima sezione */}
      <div className="mb-8">
        <CodeAnalysisDashboard />
      </div>

      {/* Consciousness Core Dashboard */}
      <div className="mb-6">
        <ConsciousnessCoreDashboard />
      </div>
      
      {/* AI Chat & Consciousness System - Sotto l'analisi */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
        <div>
          <AIChat />
        </div>
        <div>
          <ConsciousnessViewer />
        </div>
      </div>
    </div>
  );
}
