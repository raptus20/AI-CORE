import React from "react";
import { Header } from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";

export default function Configuration() {
  const { toast } = useToast();
  
  const handleSaveChanges = () => {
    toast({
      title: "Settings Saved",
      description: "Your configuration changes have been applied.",
    });
  };
  
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">General Configuration</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium block mb-1">AI Model</label>
                    <Select defaultValue="gpt-4o">
                      <SelectTrigger>
                        <SelectValue placeholder="Select Model" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gpt-4o">GPT-4o</SelectItem>
                        <SelectItem value="gpt-4">GPT-4</SelectItem>
                        <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium block mb-1">API Key</label>
                    <Input type="password" value="••••••••••••••••" />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium block mb-1">Update Frequency</label>
                  <div className="flex space-x-4 items-center">
                    <Slider defaultValue={[50]} max={100} step={1} className="flex-1" />
                    <span className="text-sm w-12 text-center">50%</span>
                  </div>
                  <p className="text-xs text-neutral-500 mt-1">
                    Controls how often the AI suggests improvements to the codebase
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-sm font-medium block">Auto-Suggest Improvements</label>
                      <p className="text-xs text-neutral-500">
                        Allow AI to automatically suggest code improvements
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-sm font-medium block">Self-Evaluation</label>
                      <p className="text-xs text-neutral-500">
                        Enable AI self-evaluation capabilities
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-sm font-medium block">Verbose Logging</label>
                      <p className="text-xs text-neutral-500">
                        Enable detailed logging of all AI activities
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-sm font-medium block">Notifications</label>
                      <p className="text-xs text-neutral-500">
                        Receive notifications for important events
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3">
                  <Button variant="outline">
                    Reset to Defaults
                  </Button>
                  <Button 
                    className="bg-primary text-white hover:bg-primary/90"
                    onClick={handleSaveChanges}
                  >
                    Save Changes
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Advanced Settings</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium block mb-1">Max Memory Usage</label>
                  <div className="flex space-x-4 items-center">
                    <Slider defaultValue={[70]} max={100} step={1} className="flex-1" />
                    <span className="text-sm w-12 text-center">70%</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium block mb-1">CPU Allocation</label>
                  <div className="flex space-x-4 items-center">
                    <Slider defaultValue={[50]} max={100} step={1} className="flex-1" />
                    <span className="text-sm w-12 text-center">50%</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium block mb-1">Storage Limit</label>
                  <Select defaultValue="1gb">
                    <SelectTrigger>
                      <SelectValue placeholder="Select Limit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="500mb">500MB</SelectItem>
                      <SelectItem value="1gb">1GB</SelectItem>
                      <SelectItem value="5gb">5GB</SelectItem>
                      <SelectItem value="10gb">10GB</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium block mb-1">Data Retention</label>
                  <Select defaultValue="30">
                    <SelectTrigger>
                      <SelectValue placeholder="Select Period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="pt-2">
                  <Button variant="outline" className="w-full text-red-600 border-red-200 hover:bg-red-50">
                    Reset System
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
