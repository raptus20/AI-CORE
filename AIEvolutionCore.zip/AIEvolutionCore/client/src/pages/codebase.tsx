import React, { useState } from "react";
import { Header } from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CodeEditor } from "@/components/ui/code-editor";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { CodeSuggestion } from "@/components/code-suggestion";
import { useToast } from "@/hooks/use-toast";

export default function Codebase() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedSuggestionId, setSelectedSuggestionId] = useState<number | null>(null);
  const [filePath, setFilePath] = useState("");
  const [currentCode, setCurrentCode] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Fetch all suggestions
  const { data: suggestions, isLoading } = useQuery({
    queryKey: ["/api/suggestions"],
    queryFn: () => aiService.getAllSuggestions()
  });
  
  // Mutation for generating a new suggestion
  const generateSuggestionMutation = useMutation({
    mutationFn: ({ filePath, currentCode }: { filePath: string, currentCode: string }) => 
      aiService.generateSuggestion(filePath, currentCode),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      setFilePath("");
      setCurrentCode("");
      setIsGenerating(false);
      toast({
        title: "Success",
        description: "Code suggestion generated successfully",
      });
    },
    onError: () => {
      setIsGenerating(false);
      toast({
        title: "Error",
        description: "Failed to generate code suggestion",
        variant: "destructive"
      });
    }
  });
  
  const handleGenerateSuggestion = () => {
    if (!filePath || !currentCode) {
      toast({
        title: "Missing information",
        description: "Please provide both file path and current code",
        variant: "destructive"
      });
      return;
    }
    
    setIsGenerating(true);
    generateSuggestionMutation.mutate({ filePath, currentCode });
  };
  
  const handleSuggestionSelect = (id: number) => {
    setSelectedSuggestionId(id);
  };
  
  return (
    <>
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div>
            <Card>
              <CardHeader className="border-b border-neutral-200 p-4">
                <CardTitle className="font-semibold text-base">Code Suggestions</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                {isLoading ? (
                  <div className="flex justify-center py-4">
                    <span className="mdi mdi-loading mdi-spin text-2xl text-neutral-500"></span>
                  </div>
                ) : suggestions?.length ? (
                  <div className="space-y-3">
                    {suggestions.map((suggestion) => (
                      <div 
                        key={suggestion.id}
                        className={`p-3 rounded-lg border cursor-pointer hover:bg-neutral-50 transition-colors ${
                          selectedSuggestionId === suggestion.id ? "border-primary bg-blue-50" : "border-neutral-200"
                        }`}
                        onClick={() => handleSuggestionSelect(suggestion.id)}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium text-sm">{suggestion.title}</h3>
                            <p className="text-xs text-neutral-500 mt-1">{suggestion.filePath}</p>
                          </div>
                          <div className={`text-xs px-2 py-1 rounded-full ${
                            suggestion.status === "approved" ? "bg-green-100 text-green-800" :
                            suggestion.status === "rejected" ? "bg-red-100 text-red-800" :
                            suggestion.status === "testing" ? "bg-blue-100 text-blue-800" :
                            "bg-amber-100 text-amber-800"
                          }`}>
                            {suggestion.status}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-neutral-500 text-center py-4">No suggestions available</p>
                )}
                
                <div className="mt-4">
                  <Button 
                    variant="outline"
                    className="w-full py-2 text-sm text-primary border border-primary hover:bg-blue-50"
                    onClick={() => setSelectedSuggestionId(null)}
                  >
                    Generate New Suggestion
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="lg:col-span-2">
            {selectedSuggestionId ? (
              <CodeSuggestion suggestionId={selectedSuggestionId} />
            ) : (
              <Card>
                <CardHeader className="border-b border-neutral-200 p-4">
                  <CardTitle className="font-semibold text-base">Generate New Suggestion</CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium block mb-1">File Path</label>
                      <Input
                        placeholder="e.g., src/components/button.js"
                        value={filePath}
                        onChange={(e) => setFilePath(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium block mb-1">Current Code</label>
                      <CodeEditor
                        value={currentCode}
                        onChange={setCurrentCode}
                        readOnly={false}
                        className="min-h-[300px]"
                      />
                    </div>
                    
                    <Button
                      onClick={handleGenerateSuggestion}
                      disabled={!filePath || !currentCode || isGenerating}
                      className="bg-primary text-white hover:bg-primary/90"
                    >
                      {isGenerating ? (
                        <>
                          <span className="mdi mdi-loading mdi-spin mr-2"></span>
                          Generating...
                        </>
                      ) : (
                        <>
                          <span className="mdi mdi-magic mr-2"></span>
                          Generate Suggestion
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
