import React, { useState } from "react";
import { Header } from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CodeEditor } from "@/components/ui/code-editor";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { SandboxEnvironment } from "@/components/sandbox-environment";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Sandbox() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [testCode, setTestCode] = useState("");
  const [moduleName, setModuleName] = useState("");
  const [selectedTestId, setSelectedTestId] = useState<number | null>(null);
  
  // Fetch all tests
  const { data: tests, isLoading } = useQuery({
    queryKey: ["/api/sandbox/tests"],
    queryFn: () => aiService.getAllTests()
  });
  
  // Fetch specific test details if one is selected
  const { data: selectedTest } = useQuery({
    queryKey: ["/api/sandbox/test", selectedTestId],
    queryFn: () => {
      if (selectedTestId === null) return null;
      return tests?.find(test => test.id === selectedTestId) || null;
    },
    enabled: selectedTestId !== null
  });
  
  // Mutation for creating a new test
  const createTestMutation = useMutation({
    mutationFn: (testData: any) => aiService.createSandboxTest(testData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sandbox/tests"] });
      setTestCode("");
      setModuleName("");
      toast({
        title: "Test started",
        description: "Your code is now being tested in the sandbox",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start sandbox test",
        variant: "destructive"
      });
    }
  });
  
  const handleCreateTest = () => {
    if (!moduleName || !testCode) {
      toast({
        title: "Missing information",
        description: "Please provide both module name and test code",
        variant: "destructive"
      });
      return;
    }
    
    const testId = `SBX-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000)}`;
    
    createTestMutation.mutate({
      testId,
      moduleName,
      status: "pending",
      logs: "",
      testCode: testCode
    });
  };
  
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <SandboxEnvironment />
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Sandbox Tests</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Tabs defaultValue="new">
                <TabsList className="w-full justify-start border-b rounded-none border-neutral-200">
                  <TabsTrigger value="new" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                    New Test
                  </TabsTrigger>
                  <TabsTrigger value="history" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                    Test History
                  </TabsTrigger>
                  {selectedTestId && (
                    <TabsTrigger value="details" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                      Test Details
                    </TabsTrigger>
                  )}
                </TabsList>
                
                <TabsContent value="new" className="p-4 m-0">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium block mb-1">Module Name</label>
                      <Input
                        placeholder="e.g., Data Processing Module"
                        value={moduleName}
                        onChange={(e) => setModuleName(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium block mb-1">Code to Test</label>
                      <CodeEditor
                        value={testCode}
                        onChange={setTestCode}
                        readOnly={false}
                        className="min-h-[300px]"
                      />
                    </div>
                    
                    <Button
                      onClick={handleCreateTest}
                      disabled={!moduleName || !testCode || createTestMutation.isPending}
                      className="bg-primary text-white hover:bg-primary/90"
                    >
                      {createTestMutation.isPending ? (
                        <>
                          <span className="mdi mdi-loading mdi-spin mr-2"></span>
                          Starting Test...
                        </>
                      ) : (
                        <>
                          <span className="mdi mdi-test-tube mr-2"></span>
                          Run in Sandbox
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>
                
                <TabsContent value="history" className="m-0">
                  <div className="p-4">
                    {isLoading ? (
                      <div className="flex justify-center py-4">
                        <span className="mdi mdi-loading mdi-spin text-2xl text-neutral-500"></span>
                      </div>
                    ) : tests?.length ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Test ID</TableHead>
                            <TableHead>Module</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Result</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {tests.map((test) => (
                            <TableRow key={test.id}>
                              <TableCell>{test.testId}</TableCell>
                              <TableCell>{test.moduleName}</TableCell>
                              <TableCell>
                                <span className={
                                  test.status === "completed" 
                                    ? "text-green-600" 
                                    : test.status === "running"
                                      ? "text-blue-500"
                                      : "text-amber-500"
                                }>
                                  {test.status.charAt(0).toUpperCase() + test.status.slice(1)}
                                </span>
                              </TableCell>
                              <TableCell>
                                {test.status === "completed" ? (
                                  <span className={test.result === "passed" ? "text-green-600" : "text-red-600"}>
                                    {test.result}
                                  </span>
                                ) : (
                                  <span className="text-neutral-500">-</span>
                                )}
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="link"
                                  className="p-0 h-auto text-primary"
                                  onClick={() => {
                                    setSelectedTestId(test.id);
                                    document.querySelector('[data-state="inactive"][value="details"]')?.click();
                                  }}
                                >
                                  View Details
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <p className="text-sm text-neutral-500 text-center py-4">No tests have been run yet</p>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="details" className="p-4 m-0">
                  {selectedTest ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h3 className="text-sm font-medium mb-1">Test ID</h3>
                          <p className="text-sm">{selectedTest.testId}</p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium mb-1">Module</h3>
                          <p className="text-sm">{selectedTest.moduleName}</p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium mb-1">Status</h3>
                          <p className={
                            selectedTest.status === "completed" 
                              ? "text-green-600" 
                              : selectedTest.status === "running"
                                ? "text-blue-500"
                                : "text-amber-500"
                          }>
                            {selectedTest.status.charAt(0).toUpperCase() + selectedTest.status.slice(1)}
                          </p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium mb-1">Result</h3>
                          <p className={selectedTest.result === "passed" ? "text-green-600" : "text-red-600"}>
                            {selectedTest.result || "N/A"}
                          </p>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium mb-1">Logs</h3>
                        <div className="bg-neutral-50 rounded-lg p-4 text-sm border font-mono whitespace-pre-wrap">
                          {selectedTest.logs || "No logs available"}
                        </div>
                      </div>
                      
                      <div className="flex justify-end">
                        <Button
                          variant="outline"
                          className="text-primary border-primary"
                          onClick={() => setSelectedTestId(null)}
                        >
                          Close Details
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-neutral-500 text-center py-4">No test selected</p>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
