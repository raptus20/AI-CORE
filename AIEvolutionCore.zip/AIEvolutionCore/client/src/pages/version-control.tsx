import React from "react";
import { Header } from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useQuery } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";

export default function VersionControl() {
  // Mock version control data for now
  const versionHistory = [
    {
      id: 1,
      filePath: "src/core/evaluation.js",
      version: "v3",
      timestamp: new Date("2023-06-15T12:35:00"),
      author: "AI Assistant",
      changeType: "modification"
    },
    {
      id: 2,
      filePath: "src/utils/processing.js",
      version: "v2",
      timestamp: new Date("2023-06-14T09:22:00"),
      author: "AI Assistant",
      changeType: "modification"
    },
    {
      id: 3,
      filePath: "src/core/memory.js",
      version: "v4",
      timestamp: new Date("2023-06-13T14:15:00"),
      author: "Human Admin",
      changeType: "revert"
    },
    {
      id: 4,
      filePath: "src/utils/helpers.js",
      version: "v1",
      timestamp: new Date("2023-06-12T11:10:00"),
      author: "AI Assistant",
      changeType: "addition"
    }
  ];
  
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader className="border-b border-neutral-200 p-4">
            <div className="flex justify-between items-center">
              <CardTitle className="font-semibold text-base">Version Control</CardTitle>
              <div className="flex space-x-2">
                <Button variant="outline" className="text-primary border-primary">
                  <span className="mdi mdi-filter-outline mr-1"></span>
                  Filter
                </Button>
                <Button className="bg-primary text-white hover:bg-primary/90">
                  <span className="mdi mdi-source-branch mr-1"></span>
                  View Branches
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>File Path</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Author</TableHead>
                  <TableHead>Change Type</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {versionHistory.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.filePath}</TableCell>
                    <TableCell>{item.version}</TableCell>
                    <TableCell>{item.timestamp.toLocaleString()}</TableCell>
                    <TableCell>
                      <span className={`${item.author === "AI Assistant" ? "text-primary" : "text-green-600"}`}>
                        {item.author}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        item.changeType === "modification" ? "bg-blue-100 text-blue-800" :
                        item.changeType === "addition" ? "bg-green-100 text-green-800" :
                        "bg-amber-100 text-amber-800"
                      }`}>
                        {item.changeType}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" className="h-8 px-2">
                          <span className="mdi mdi-eye"></span>
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 px-2">
                          <span className="mdi mdi-compare"></span>
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 px-2">
                          <span className="mdi mdi-restore"></span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            <div className="mt-4 flex justify-between items-center">
              <div className="text-sm text-neutral-500">
                Showing 4 of 4 versions
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" disabled>
                  <span className="mdi mdi-chevron-left"></span>
                </Button>
                <Button variant="outline" size="sm" disabled>
                  <span className="mdi mdi-chevron-right"></span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
