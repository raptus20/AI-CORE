import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Clock, Activity } from "lucide-react";

interface ActivityLogEntry {
  id: number;
  eventType: string;
  description: string;
  timestamp: string;
  metadata?: any;
}

export default function ActivityLogPage() {
  const { data: activities, isLoading } = useQuery<ActivityLogEntry[]>({
    queryKey: ["/api/activity"],
  });

  const formatTimestamp = (timestamp: string) => {
    if (!timestamp) return 'Data non disponibile';
    
    // Try different date formats
    let date = new Date(timestamp);
    
    // If invalid, try parsing as ISO string or other formats
    if (isNaN(date.getTime())) {
      // Try with additional parsing
      date = new Date(timestamp.replace(' ', 'T'));
    }
    
    // If still invalid, show the raw timestamp
    if (isNaN(date.getTime())) {
      return timestamp;
    }
    
    return date.toLocaleString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getEventTypeColor = (eventType: string) => {
    switch (eventType) {
      case 'autonomous_complete':
        return 'bg-green-100 text-green-800';
      case 'code_analysis':
        return 'bg-blue-100 text-blue-800';
      case 'user_interaction':
        return 'bg-purple-100 text-purple-800';
      case 'system_start':
        return 'bg-gray-100 text-gray-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center gap-2 mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </Link>
        </div>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Caricamento log attività...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Dashboard
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            <CardTitle>Log Completo Attività Sistema</CardTitle>
          </div>
          <CardDescription>
            Cronologia dettagliata di tutte le attività del sistema AI autonomo
          </CardDescription>
        </CardHeader>

        <CardContent>
          <ScrollArea className="h-[600px] w-full">
            {!activities || activities.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nessuna attività registrata</p>
              </div>
            ) : (
              <div className="space-y-4">
                {activities.map((activity) => (
                  <Card key={activity.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="secondary" className={getEventTypeColor(activity.eventType)}>
                              {activity.eventType}
                            </Badge>
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              {formatTimestamp(activity.timestamp)}
                            </div>
                          </div>
                          
                          <p className="text-sm font-medium mb-2">
                            {activity.description}
                          </p>
                          
                          {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                            <details className="text-xs text-muted-foreground">
                              <summary className="cursor-pointer hover:text-foreground">
                                Metadata aggiuntivi
                              </summary>
                              <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-auto">
                                {JSON.stringify(activity.metadata, null, 2)}
                              </pre>
                            </details>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}