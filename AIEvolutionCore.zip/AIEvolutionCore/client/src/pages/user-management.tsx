import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

type User = {
  id: number;
  name: string;
  email: string;
  role: string;
  status: string;
  lastActive: Date;
};

export default function UserManagement() {
  const { toast } = useToast();
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  
  // Sample user data - in real implementation this would be fetched from the API
  const [users] = useState<User[]>([
    {
      id: 1,
      name: "Admin User",
      email: "admin@example.com",
      role: "Administrator",
      status: "Active",
      lastActive: new Date(2023, 5, 15)
    },
    {
      id: 2,
      name: "John Doe",
      email: "john.doe@example.com",
      role: "Editor",
      status: "Active",
      lastActive: new Date(2023, 5, 14)
    },
    {
      id: 3,
      name: "Jane Smith",
      email: "jane.smith@example.com",
      role: "Viewer",
      status: "Inactive",
      lastActive: new Date(2023, 5, 10)
    }
  ]);
  
  const handleAddUser = () => {
    setIsAddUserOpen(false);
    toast({
      title: "User Added",
      description: "The new user has been added successfully.",
    });
  };
  
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <div className="flex justify-between items-center">
                <CardTitle className="font-semibold text-base">User Management</CardTitle>
                <Button 
                  onClick={() => setIsAddUserOpen(true)}
                  className="bg-primary text-white hover:bg-primary/90"
                >
                  <span className="mdi mdi-account-plus mr-2"></span>
                  Add User
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Active</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          user.role === "Administrator" ? "bg-purple-100 text-purple-800" :
                          user.role === "Editor" ? "bg-blue-100 text-blue-800" :
                          "bg-green-100 text-green-800"
                        }`}>
                          {user.role}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={`flex items-center ${
                          user.status === "Active" ? "text-green-600" : "text-neutral-500"
                        }`}>
                          <span className={`w-2 h-2 rounded-full mr-2 ${
                            user.status === "Active" ? "bg-green-600" : "bg-neutral-400"
                          }`}></span>
                          {user.status}
                        </span>
                      </TableCell>
                      <TableCell>{user.lastActive.toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <span className="mdi mdi-pencil"></span>
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <span className="mdi mdi-delete"></span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card className="mb-6">
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Role Permissions</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Administrator</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Manage Users</span>
                      <Switch defaultChecked disabled />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Approve Code Changes</span>
                      <Switch defaultChecked disabled />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Configure System</span>
                      <Switch defaultChecked disabled />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Editor</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Manage Users</span>
                      <Switch disabled />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Approve Code Changes</span>
                      <Switch defaultChecked disabled />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Configure System</span>
                      <Switch disabled />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Viewer</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Manage Users</span>
                      <Switch disabled />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Approve Code Changes</span>
                      <Switch disabled />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Configure System</span>
                      <Switch disabled />
                    </div>
                  </div>
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full mt-4 text-primary border-primary"
              >
                Edit Permissions
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Activity Monitor</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3 max-h-[200px] overflow-y-auto">
                <div className="text-sm border-b border-neutral-100 pb-2">
                  <p className="font-medium">Admin User</p>
                  <p className="text-neutral-500 text-xs">Approved code change</p>
                  <p className="text-neutral-400 text-xs">Today, 11:42 AM</p>
                </div>
                <div className="text-sm border-b border-neutral-100 pb-2">
                  <p className="font-medium">John Doe</p>
                  <p className="text-neutral-500 text-xs">Viewed sandbox tests</p>
                  <p className="text-neutral-400 text-xs">Yesterday, 3:15 PM</p>
                </div>
                <div className="text-sm border-b border-neutral-100 pb-2">
                  <p className="font-medium">Admin User</p>
                  <p className="text-neutral-500 text-xs">Updated safety protocols</p>
                  <p className="text-neutral-400 text-xs">Jun 14, 10:30 AM</p>
                </div>
              </div>
              
              <Button variant="link" className="w-full mt-2 text-primary">
                View All Activity
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Add User Dialog */}
      <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium block mb-1">First Name</label>
                <Input placeholder="Enter first name" />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1">Last Name</label>
                <Input placeholder="Enter last name" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium block mb-1">Email</label>
              <Input type="email" placeholder="Enter email address" />
            </div>
            <div>
              <label className="text-sm font-medium block mb-1">Role</label>
              <Select defaultValue="viewer">
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrator</SelectItem>
                  <SelectItem value="editor">Editor</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="send-invite" />
              <label htmlFor="send-invite" className="text-sm">Send email invitation</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddUserOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddUser}>
              Add User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
