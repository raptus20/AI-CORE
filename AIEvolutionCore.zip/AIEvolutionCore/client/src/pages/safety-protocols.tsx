import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

export default function SafetyProtocols() {
  const { toast } = useToast();
  const [emergencyMode, setEmergencyMode] = useState(false);
  
  const handleEmergencyModeToggle = () => {
    setEmergencyMode(!emergencyMode);
    toast({
      title: !emergencyMode ? "Emergency Mode Activated" : "Emergency Mode Deactivated",
      description: !emergencyMode 
        ? "All AI operations that modify code have been suspended." 
        : "AI operations have been restored to normal.",
      variant: !emergencyMode ? "destructive" : "default"
    });
  };
  
  const handleSaveProtocols = () => {
    toast({
      title: "Safety Protocols Updated",
      description: "Your changes to the safety protocols have been saved.",
    });
  };
  
  return (
    <div className="p-6">
      <div className="mb-6">
        <Card className={emergencyMode ? "border-red-500 bg-red-50" : ""}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className={`mdi ${emergencyMode ? "mdi-alert-circle" : "mdi-shield-check"} text-2xl ${emergencyMode ? "text-red-500" : "text-green-600"} mr-3`}></span>
                <div>
                  <h2 className="font-semibold">System Safety Status: {emergencyMode ? "Emergency Mode" : "Normal Operation"}</h2>
                  <p className="text-sm text-neutral-500">
                    {emergencyMode 
                      ? "Emergency protocols active - AI code modification abilities have been restricted" 
                      : "All safety protocols are functioning normally"}
                  </p>
                </div>
              </div>
              <Button 
                variant={emergencyMode ? "default" : "destructive"}
                onClick={handleEmergencyModeToggle}
                className={emergencyMode ? "bg-green-600 hover:bg-green-700 text-white" : ""}
              >
                {emergencyMode ? "Deactivate Emergency Mode" : "Activate Emergency Mode"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Safety Protocols Configuration</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Tabs defaultValue="access-controls">
                <TabsList className="w-full border-b rounded-none border-neutral-200 p-0 h-auto">
                  <TabsTrigger value="access-controls" className="rounded-none py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary">
                    Access Controls
                  </TabsTrigger>
                  <TabsTrigger value="execution-limits" className="rounded-none py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary">
                    Execution Limits
                  </TabsTrigger>
                  <TabsTrigger value="oversight-rules" className="rounded-none py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary">
                    Oversight Rules
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="access-controls" className="p-4 m-0">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Human Approval Required</label>
                        <p className="text-sm text-neutral-500">All code changes must be approved by a human</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Read-Only Mode for Critical Files</label>
                        <p className="text-sm text-neutral-500">Prevent AI from modifying critical system files</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">API Access Restrictions</label>
                        <p className="text-sm text-neutral-500">Limit AI's access to external APIs</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="pt-4">
                      <h3 className="font-medium text-sm mb-2">Protected Files & Directories</h3>
                      <div className="border rounded-md mb-3">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Path</TableHead>
                              <TableHead>Protection Level</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            <TableRow>
                              <TableCell className="font-medium">server/routes.ts</TableCell>
                              <TableCell>Read-Only</TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <span className="mdi mdi-pencil"></span>
                                </Button>
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">server/ai/sandbox.ts</TableCell>
                              <TableCell>Read-Only</TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <span className="mdi mdi-pencil"></span>
                                </Button>
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">shared/schema.ts</TableCell>
                              <TableCell>Restricted</TableCell>
                              <TableCell>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <span className="mdi mdi-pencil"></span>
                                </Button>
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                      <div className="flex space-x-2">
                        <Input placeholder="Add file or directory path" className="flex-1" />
                        <Button variant="outline">Add</Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="execution-limits" className="p-4 m-0">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium block mb-1">Sandbox Execution Timeout (seconds)</label>
                      <div className="flex space-x-4 items-center">
                        <Slider defaultValue={[30]} max={120} step={1} className="flex-1" />
                        <span className="text-sm w-12 text-center">30s</span>
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium block mb-1">Memory Limit</label>
                      <div className="flex space-x-4 items-center">
                        <Slider defaultValue={[256]} max={1024} step={16} className="flex-1" />
                        <span className="text-sm w-12 text-center">256MB</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Prevent Network Access in Sandbox</label>
                        <p className="text-sm text-neutral-500">Isolate sandbox from network</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Prevent File System Access</label>
                        <p className="text-sm text-neutral-500">Restrict sandbox from accessing the file system</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Auto-Terminate Dangerous Operations</label>
                        <p className="text-sm text-neutral-500">Automatically stop execution of potentially harmful code</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="oversight-rules" className="p-4 m-0">
                  <div className="space-y-4">
                    <Accordion type="single" collapsible className="border rounded-md">
                      <AccordionItem value="item-1" className="border-b">
                        <AccordionTrigger className="px-4">Approved Operations</AccordionTrigger>
                        <AccordionContent className="px-4">
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Optimizing algorithmic efficiency</li>
                            <li>Refactoring code for readability</li>
                            <li>Adding documentation or comments</li>
                            <li>Fixing non-critical bugs</li>
                            <li>Improving error handling</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>
                      <AccordionItem value="item-2" className="border-b">
                        <AccordionTrigger className="px-4">Restricted Operations</AccordionTrigger>
                        <AccordionContent className="px-4">
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Modifying authentication mechanisms</li>
                            <li>Changing system configuration files</li>
                            <li>Altering database schemas</li>
                            <li>Installing new dependencies</li>
                            <li>Changing API endpoints or contracts</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>
                      <AccordionItem value="item-3">
                        <AccordionTrigger className="px-4">Prohibited Operations</AccordionTrigger>
                        <AccordionContent className="px-4">
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Modifying safety protocols</li>
                            <li>Altering permission systems</li>
                            <li>Changing logging or monitoring systems</li>
                            <li>Modifying version control mechanisms</li>
                            <li>Creating or modifying user accounts</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Enforce Code Review for All Changes</label>
                        <p className="text-sm text-neutral-500">Require human review before implementation</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Automatic Safety Validation</label>
                        <p className="text-sm text-neutral-500">Check code changes against safety rules before submission</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="font-medium text-sm">Send Alerts on Suspicious Activity</label>
                        <p className="text-sm text-neutral-500">Notify administrators of potentially harmful actions</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card className="mb-6">
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Safety Audit Log</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3 max-h-[250px] overflow-y-auto">
                <div className="p-2 border-l-4 border-green-500 bg-green-50 rounded">
                  <p className="text-sm">Safety protocol updated: Memory limits</p>
                  <p className="text-xs text-neutral-500">Today, 10:23 AM</p>
                </div>
                <div className="p-2 border-l-4 border-amber-500 bg-amber-50 rounded">
                  <p className="text-sm">Warning: Multiple failed sandbox executions</p>
                  <p className="text-xs text-neutral-500">Yesterday, 3:45 PM</p>
                </div>
                <div className="p-2 border-l-4 border-red-500 bg-red-50 rounded">
                  <p className="text-sm">Emergency mode activated temporarily</p>
                  <p className="text-xs text-neutral-500">Jun 12, 11:32 AM</p>
                </div>
                <div className="p-2 border-l-4 border-blue-500 bg-blue-50 rounded">
                  <p className="text-sm">Protected file list updated</p>
                  <p className="text-xs text-neutral-500">Jun 10, 09:15 AM</p>
                </div>
              </div>
              <Button variant="link" className="w-full mt-2 text-primary">
                View Full Audit Log
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-base">Actions</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full text-primary border-primary"
                  onClick={handleSaveProtocols}
                >
                  <span className="mdi mdi-content-save mr-2"></span>
                  Save Protocol Changes
                </Button>
                <Button variant="outline" className="w-full">
                  <span className="mdi mdi-refresh mr-2"></span>
                  Reset to Defaults
                </Button>
                <Button variant="outline" className="w-full text-amber-600 border-amber-200 hover:bg-amber-50">
                  <span className="mdi mdi-lock-reset mr-2"></span>
                  Force Safety Check
                </Button>
                <Button variant="outline" className="w-full text-red-600 border-red-200 hover:bg-red-50">
                  <span className="mdi mdi-power mr-2"></span>
                  System Lockdown
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
