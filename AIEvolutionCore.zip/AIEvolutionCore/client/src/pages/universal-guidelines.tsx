import React from 'react';
import { UniversalGuidelinesDashboard } from '@/components/universal-guidelines-dashboard';

export default function UniversalGuidelinesPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Linee Guida Universali</h1>
        <p className="text-gray-600">
          Principi guida che indirizzano il comportamento del sistema senza limitarlo
        </p>
      </div>
      
      <UniversalGuidelinesDashboard />
    </div>
  );
}