import { CodeSuggestion, SandboxTest, ActivityLog, SystemMetrics } from "@shared/schema";
import { apiRequest } from "./queryClient";

export const aiService = {
  // Code Suggestions
  async getAllSuggestions(): Promise<CodeSuggestion[]> {
    const res = await fetch("/api/suggestions");
    if (!res.ok) {
      throw new Error("Failed to fetch suggestions");
    }
    return res.json();
  },

  async getSuggestion(id: number): Promise<CodeSuggestion> {
    const res = await fetch(`/api/suggestions/${id}`);
    if (!res.ok) {
      throw new Error("Failed to fetch suggestion");
    }
    return res.json();
  },

  async createSuggestion(suggestionData: Partial<CodeSuggestion>): Promise<CodeSuggestion> {
    const res = await apiRequest("POST", "/api/suggestions", suggestionData);
    return res.json();
  },

  async generateSuggestion(filePath: string, currentCode: string): Promise<CodeSuggestion> {
    const res = await apiRequest("POST", "/api/suggestions/generate", { filePath, currentCode });
    return res.json();
  },

  async updateSuggestionStatus(id: number, status: string): Promise<CodeSuggestion> {
    const response = await fetch(`/api/suggestions/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });

    if (!response.ok) {
      throw new Error("Failed to update suggestion status");
    }

    return response.json();
  },

  // Sandbox Testing
  async getAllTests(): Promise<SandboxTest[]> {
    const res = await fetch("/api/sandbox/tests");
    if (!res.ok) {
      throw new Error("Failed to fetch sandbox tests");
    }
    return res.json();
  },

  async createSandboxTest(testData: Partial<SandboxTest>): Promise<SandboxTest> {
    const res = await apiRequest("POST", "/api/sandbox/tests", testData);
    return res.json();
  },

  async runSuggestionInSandbox(suggestionId: number): Promise<SandboxTest> {
    const res = await apiRequest("POST", `/api/sandbox/run-suggestion/${suggestionId}`, {});
    return res.json();
  },

  // Activity Logs
  async getActivityLogs(limit?: number): Promise<ActivityLog[]> {
    const url = limit ? `/api/activity?limit=${limit}` : "/api/activity";
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error("Failed to fetch activity logs");
    }
    return res.json();
  },

  // System Metrics
  async getSystemMetrics(): Promise<SystemMetrics> {
    const res = await fetch("/api/system/metrics");
    if (!res.ok) {
      throw new Error("Failed to fetch system metrics");
    }
    return res.json();
  },

  async updateSystemMetrics(metricsData: Partial<SystemMetrics>): Promise<SystemMetrics> {
    const res = await apiRequest("POST", "/api/system/metrics", metricsData);
    return res.json();
  }
};