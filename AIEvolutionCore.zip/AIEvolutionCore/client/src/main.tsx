import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { ThemeProvider } from "@/components/theme-provider";

// Add Material Design Icons CSS
const mdiLink = document.createElement("link");
mdiLink.rel = "stylesheet";
mdiLink.href = "https://cdn.jsdelivr.net/npm/@mdi/font@6.5.95/css/materialdesignicons.min.css";
document.head.appendChild(mdiLink);

// Add Segoe UI Font
const fontLink = document.createElement("link");
fontLink.rel = "stylesheet";
fontLink.href = "https://fonts.googleapis.com/css2?family=Segoe+UI:wght@300;400;500;600;700&display=swap";
document.head.appendChild(fontLink);

// Add title and meta description
const title = document.createElement("title");
title.textContent = "AI Self-Improvement Framework";
document.head.appendChild(title);

const metaDescription = document.createElement("meta");
metaDescription.name = "description";
metaDescription.content = "A web application that enables an AI to suggest and implement improvements to its own codebase with human oversight";
document.head.appendChild(metaDescription);

createRoot(document.getElementById("root")!).render(
  <ThemeProvider defaultTheme="light" storageKey="ui-theme">
    <App />
  </ThemeProvider>
);
