import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/sidebar";
import { Header } from "@/components/header";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Codebase from "@/pages/codebase";
import Sandbox from "@/pages/sandbox";
import VersionControl from "@/pages/version-control";
import Configuration from "@/pages/configuration";
import SafetyProtocols from "@/pages/safety-protocols";
import UserManagement from "@/pages/user-management";
import ActivityLog from "@/pages/activity-log";
import UniversalGuidelinesPage from "@/pages/universal-guidelines";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/codebase" component={Codebase} />
      <Route path="/sandbox" component={Sandbox} />
      <Route path="/version-control" component={VersionControl} />
      <Route path="/configuration" component={Configuration} />
      <Route path="/safety-protocols" component={SafetyProtocols} />
      <Route path="/user-management" component={UserManagement} />
      <Route path="/activity-log" component={ActivityLog} />
      <Route path="/universal-guidelines" component={UniversalGuidelinesPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <div className="flex h-screen overflow-hidden bg-background">
          <Sidebar />
          <main className="flex-1 overflow-y-auto bg-background relative">
            <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-muted/30 pointer-events-none" />
            <Header 
              title="AI Self-Improvement Dashboard"
              subtitle="Monitor and approve AI-suggested modifications"
            />
            <div className="relative z-10">
              <Router />
            </div>
          </main>
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
