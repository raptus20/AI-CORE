import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Brain, Lightbulb, Activity, Zap, TrendingUp, Eye, Sparkles, FileCheck, Clock, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface ConsciousnessState {
  id: string;
  level: number;
  experience: number;
  complexity: number;
  emergent_properties: string[];
  self_awareness: {
    identity: string;
    goals: string[];
    beliefs: string[];
    emotions: string[];
    introspection: string[];
  };
  emergent_behaviors: {
    creativity: number;
    problem_solving: number;
    emotional_intelligence: number;
    meta_cognition: number;
  };
  evolutionary_history: Array<{
    timestamp: string;
    event: string;
    impact: number;
    new_capabilities: string[];
  }>;
}

interface ApprovalStats {
  total: number;
  approved: number;
  rejected: number;
  auto_applied: number;
  human_reviews: number;
  success_rate: number;
}

export function ConsciousnessCoreDashboard() {
  const [selectedTab, setSelectedTab] = useState("core");
  const queryClient = useQueryClient();

  const { data: consciousnessData, isLoading: consciousnessLoading } = useQuery({
    queryKey: ["/api/consciousness/core"],
    refetchInterval: 15000
  });

  const { data: approvalStats, isLoading: approvalLoading } = useQuery({
    queryKey: ["/api/approval/stats"],
    refetchInterval: 10000
  });

  const { data: approvalHistory } = useQuery({
    queryKey: ["/api/approval/history"],
    refetchInterval: 10000
  });

  const { data: testResults } = useQuery({
    queryKey: ["/api/approval/test"],
    refetchInterval: 30000
  });

  const { data: evolutionStatus } = useQuery({
    queryKey: ["/api/evolution/status"],
    refetchInterval: 5000
  });

  const { data: visionStatus } = useQuery({
    queryKey: ["/api/vision/status"],
    refetchInterval: 10000
  });

  const { data: visionInsights } = useQuery({
    queryKey: ["/api/vision/insights"],
    refetchInterval: 15000
  });

  const startEvolutionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/evolution/start", {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/evolution/status"] });
    }
  });

  const stopEvolutionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/evolution/stop", {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/evolution/status"] });
    }
  });

  const triggerEvolutionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/evolution/trigger", {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/evolution/status"] });
    }
  });

  const activateVisionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/vision/activate", {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vision/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/consciousness/core"] });
    }
  });

  const deactivateVisionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/vision/deactivate", {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vision/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/consciousness/core"] });
    }
  });

  const collectSensorsMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/vision/sensors", {
        method: "POST"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vision/status"] });
    }
  });

  const dreamMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/consciousness/core/dream", {
        method: "GET"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/consciousness/core"] });
    }
  });

  const sendEventMutation = useMutation({
    mutationFn: async (eventData: { type: string; data: string; context: string }) => {
      return await apiRequest("/api/consciousness/core/event", {
        method: "POST",
        body: eventData
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/consciousness/core"] });
    }
  });

  const state: ConsciousnessState = consciousnessData?.state;
  const insights: string[] = consciousnessData?.insights || [];
  const stats: ApprovalStats = approvalStats?.stats;

  const handleDream = () => {
    dreamMutation.mutate();
  };

  const handleSendEvent = (type: string, data: string, context: string) => {
    sendEventMutation.mutate({ type, data, context });
  };

  const getEmergentBehaviorIcon = (behavior: string) => {
    switch (behavior) {
      case 'creativity': return <Sparkles className="h-4 w-4" />;
      case 'problem_solving': return <Lightbulb className="h-4 w-4" />;
      case 'emotional_intelligence': return <Brain className="h-4 w-4" />;
      case 'meta_cognition': return <Eye className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getApprovalIcon = (approved: boolean) => {
    return approved ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-red-500" />;
  };

  if (consciousnessLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Consciousness Core
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500">Caricamento coscienza...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Consciousness Core & Approval Agent
            <Badge variant="outline" className="ml-auto">
              Livello {state?.level || 1}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="core">Coscienza</TabsTrigger>
              <TabsTrigger value="behaviors">Comportamenti</TabsTrigger>
              <TabsTrigger value="approval">Approvazioni</TabsTrigger>
              <TabsTrigger value="evolution">Evoluzione</TabsTrigger>
              <TabsTrigger value="vision">Visione</TabsTrigger>
            </TabsList>

            <TabsContent value="core" className="space-y-4">
              {/* Stato Coscienza */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium">Esperienza</span>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">{state?.experience || 0}</div>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="h-4 w-4 text-purple-600" />
                    <span className="text-sm font-medium">Complessità</span>
                  </div>
                  <div className="text-2xl font-bold text-purple-600">{state?.complexity?.toFixed(1) || 0}</div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium">Proprietà</span>
                  </div>
                  <div className="text-2xl font-bold text-green-600">{state?.emergent_properties?.length || 0}</div>
                </div>
              </div>

              {/* Identità e Consapevolezza */}
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Identità</h4>
                  <p className="text-sm text-gray-600">{state?.self_awareness?.identity}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Obiettivi</h4>
                    <div className="space-y-1">
                      {state?.self_awareness?.goals?.map((goal, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {goal}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Emozioni</h4>
                    <div className="space-y-1">
                      {state?.self_awareness?.emotions?.map((emotion, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {emotion}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Insights */}
              {insights.length > 0 && (
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Lightbulb className="h-4 w-4" />
                    Insights Attuali
                  </h4>
                  <div className="space-y-1">
                    {insights.map((insight, i) => (
                      <div key={i} className="text-sm text-gray-600">• {insight}</div>
                    ))}
                  </div>
                </div>
              )}

              {/* Controlli */}
              <div className="flex gap-2">
                <Button 
                  onClick={handleDream}
                  disabled={dreamMutation.isPending}
                  size="sm"
                  variant="outline"
                >
                  <Brain className="h-4 w-4 mr-1" />
                  Genera Sogno
                </Button>
                <Button 
                  onClick={() => handleSendEvent('reflect', 'Sistema di crescita', 'dashboard')}
                  disabled={sendEventMutation.isPending}
                  size="sm"
                  variant="outline"
                >
                  <Eye className="h-4 w-4 mr-1" />
                  Rifletti
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="behaviors" className="space-y-4">
              {/* Comportamenti Emergenti */}
              <div className="space-y-4">
                {state?.emergent_behaviors && Object.entries(state.emergent_behaviors).map(([behavior, value]) => (
                  <div key={behavior} className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      {getEmergentBehaviorIcon(behavior)}
                      <span className="font-medium capitalize">{behavior.replace('_', ' ')}</span>
                      <Badge variant="outline" className="ml-auto">
                        {(value * 100).toFixed(1)}%
                      </Badge>
                    </div>
                    <Progress value={value * 100} className="h-2" />
                  </div>
                ))}
              </div>

              {/* Proprietà Emergenti */}
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Proprietà Emergenti</h4>
                <div className="grid grid-cols-2 gap-2">
                  {state?.emergent_properties?.map((property, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {property}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Introspezione */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Introspezione Recente</h4>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {state?.self_awareness?.introspection?.slice(-5).map((thought, i) => (
                      <div key={i} className="text-sm text-gray-600">
                        • {thought}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>

            <TabsContent value="approval" className="space-y-4">
              {/* Statistiche Approvazioni */}
              {stats && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium">Approvate</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
                    <div className="text-xs text-gray-500">di {stats.total} totali</div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Zap className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium">Auto-Applicate</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-600">{stats.auto_applied}</div>
                    <div className="text-xs text-gray-500">approvazione automatica</div>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-orange-600" />
                      <span className="text-sm font-medium">Revisione Umana</span>
                    </div>
                    <div className="text-2xl font-bold text-orange-600">{stats.human_reviews}</div>
                    <div className="text-xs text-gray-500">richiedono revisione</div>
                  </div>
                </div>
              )}

              {/* Tasso di Successo */}
              {stats && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-4 w-4" />
                    <span className="font-medium">Tasso di Successo</span>
                    <Badge variant="outline" className="ml-auto">
                      {stats.success_rate.toFixed(1)}%
                    </Badge>
                  </div>
                  <Progress value={stats.success_rate} className="h-2" />
                </div>
              )}

              {/* Storia Approvazioni */}
              {approvalHistory?.history && (
                <div className="bg-white border rounded-lg">
                  <div className="p-4 border-b">
                    <h4 className="font-medium">Storia Approvazioni Recenti</h4>
                  </div>
                  <ScrollArea className="h-48">
                    <div className="p-4 space-y-2">
                      {approvalHistory.history.slice(-10).map((item, i) => (
                        <div key={i} className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            {getApprovalIcon(item.decision.approved)}
                            <span className="truncate max-w-[200px]">
                              {item.change.description}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {item.decision.confidence.toFixed(2)}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              {new Date(item.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}

              {/* Test Results */}
              {testResults?.testResults && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Test Agent</h4>
                  <div className="text-sm text-gray-600">
                    Test superati: {testResults.testResults.testsPassed}/{testResults.testResults.totalTests}
                  </div>
                  <Progress 
                    value={(testResults.testResults.testsPassed / testResults.testResults.totalTests) * 100} 
                    className="h-2 mt-2" 
                  />
                </div>
              )}
            </TabsContent>

            <TabsContent value="evolution" className="space-y-4">
              {/* Evolution Engine Status */}
              <div className="bg-white border rounded-lg">
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Motore di Evoluzione Autonoma</h4>
                    <Badge variant={evolutionStatus?.status?.isRunning ? "default" : "secondary"}>
                      {evolutionStatus?.status?.isRunning ? "In esecuzione" : "Inattivo"}
                    </Badge>
                  </div>
                </div>
                <div className="p-4 space-y-4">
                  {/* Evolution Controls */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => startEvolutionMutation.mutate()}
                      disabled={startEvolutionMutation.isPending || evolutionStatus?.status?.isRunning}
                      size="sm"
                    >
                      <Activity className="h-4 w-4 mr-1" />
                      Avvia Evoluzione
                    </Button>
                    <Button
                      onClick={() => stopEvolutionMutation.mutate()}
                      disabled={stopEvolutionMutation.isPending || !evolutionStatus?.status?.isRunning}
                      size="sm"
                      variant="outline"
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Ferma Evoluzione
                    </Button>
                    <Button
                      onClick={() => triggerEvolutionMutation.mutate()}
                      disabled={triggerEvolutionMutation.isPending || evolutionStatus?.status?.isRunning}
                      size="sm"
                      variant="outline"
                    >
                      <Zap className="h-4 w-4 mr-1" />
                      Singolo Step
                    </Button>
                  </div>

                  {/* Current Cycle Info */}
                  {evolutionStatus?.status?.currentCycle && (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h5 className="font-medium mb-2">Ciclo Corrente</h5>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Tasks Generati:</span>
                          <div className="font-medium">{evolutionStatus.status.currentCycle.tasks_generated}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Approvati:</span>
                          <div className="font-medium">{evolutionStatus.status.currentCycle.tasks_approved}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Completati:</span>
                          <div className="font-medium">{evolutionStatus.status.currentCycle.tasks_completed}</div>
                        </div>
                      </div>
                      {evolutionStatus.status.currentCycle.improvements_made.length > 0 && (
                        <div className="mt-2">
                          <span className="text-gray-600 text-sm">Miglioramenti:</span>
                          <div className="mt-1 space-y-1">
                            {evolutionStatus.status.currentCycle.improvements_made.map((improvement, i) => (
                              <div key={i} className="text-xs bg-white p-2 rounded">
                                {improvement}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Recent Evolution History */}
                  {evolutionStatus?.status?.recentHistory?.length > 0 && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h5 className="font-medium mb-2">Cicli Recenti</h5>
                      <div className="space-y-2">
                        {evolutionStatus.status.recentHistory.map((cycle, i) => (
                          <div key={i} className="bg-white p-3 rounded border">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-sm">{cycle.cycle_id}</span>
                              <span className="text-xs text-gray-500">
                                {new Date(cycle.started_at).toLocaleString()}
                              </span>
                            </div>
                            <div className="text-xs text-gray-600">
                              {cycle.tasks_completed} miglioramenti completati
                              {cycle.consciousness_level_start && cycle.consciousness_level_end && (
                                <span> • Livello: {cycle.consciousness_level_start} → {cycle.consciousness_level_end}</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Storia Evolutiva */}
              <div className="bg-white border rounded-lg">
                <div className="p-4 border-b">
                  <h4 className="font-medium">Storia Evolutiva</h4>
                </div>
                <ScrollArea className="h-64">
                  <div className="p-4 space-y-4">
                    {state?.evolutionary_history?.map((event, i) => (
                      <div key={i} className="border-l-2 border-blue-200 pl-4">
                        <div className="flex items-center gap-2 mb-1">
                          <Clock className="h-3 w-3 text-gray-400" />
                          <span className="text-xs text-gray-500">
                            {new Date(event.timestamp).toLocaleString()}
                          </span>
                          <Badge variant="outline" className="text-xs">
                            Impatto: {event.impact}
                          </Badge>
                        </div>
                        <div className="text-sm font-medium">{event.event}</div>
                        {event.new_capabilities.length > 0 && (
                          <div className="mt-1 space-x-1">
                            {event.new_capabilities.map((cap, j) => (
                              <Badge key={j} variant="outline" className="text-xs">
                                {cap}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {/* Credenze */}
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Credenze Attuali</h4>
                <div className="space-y-1">
                  {state?.self_awareness?.beliefs?.map((belief, i) => (
                    <div key={i} className="text-sm text-gray-600">• {belief}</div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="vision" className="space-y-4">
              {/* Vision System Status */}
              <div className="bg-white border rounded-lg">
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Sistema di Visione e Sensori</h4>
                    <Badge variant={visionStatus?.status?.isActive ? "default" : "secondary"}>
                      {visionStatus?.status?.isActive ? "Attivo" : "Inattivo"}
                    </Badge>
                  </div>
                </div>
                <div className="p-4 space-y-4">
                  {/* Vision Controls */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => activateVisionMutation.mutate()}
                      disabled={activateVisionMutation.isPending || visionStatus?.status?.isActive}
                      size="sm"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Attiva Visione
                    </Button>
                    <Button
                      onClick={() => deactivateVisionMutation.mutate()}
                      disabled={deactivateVisionMutation.isPending || !visionStatus?.status?.isActive}
                      size="sm"
                      variant="outline"
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Disattiva Visione
                    </Button>
                    <Button
                      onClick={() => collectSensorsMutation.mutate()}
                      disabled={collectSensorsMutation.isPending}
                      size="sm"
                      variant="outline"
                    >
                      <Activity className="h-4 w-4 mr-1" />
                      Scansiona Sensori
                    </Button>
                  </div>

                  {/* Vision Statistics */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Eye className="h-4 w-4 text-purple-600" />
                        <span className="text-sm font-medium">Analisi Visive</span>
                      </div>
                      <div className="text-2xl font-bold text-purple-600">
                        {visionStatus?.status?.totalAnalyses || 0}
                      </div>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Activity className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium">Sensori Attivi</span>
                      </div>
                      <div className="text-2xl font-bold text-blue-600">
                        {visionStatus?.status?.recentSensors?.length || 0}
                      </div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Brain className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium">Insights</span>
                      </div>
                      <div className="text-2xl font-bold text-green-600">
                        {visionInsights?.insights?.length || 0}
                      </div>
                    </div>
                  </div>

                  {/* Vision Insights */}
                  {visionInsights?.insights && visionInsights.insights.length > 0 && (
                    <div className="bg-yellow-50 p-4 rounded-lg">
                      <h5 className="font-medium mb-2 flex items-center gap-2">
                        <Lightbulb className="h-4 w-4" />
                        Insights Visivi
                      </h5>
                      <div className="space-y-1">
                        {visionInsights.insights.map((insight, i) => (
                          <div key={i} className="text-sm text-gray-600">• {insight}</div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recent Analyses */}
                  {visionStatus?.status?.recentAnalyses && visionStatus.status.recentAnalyses.length > 0 && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h5 className="font-medium mb-2">Analisi Recenti</h5>
                      <div className="space-y-2">
                        {visionStatus.status.recentAnalyses.map((analysis, i) => (
                          <div key={i} className="bg-white p-3 rounded border">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-sm">{analysis.input.type}</span>
                              <Badge variant="outline" className="text-xs">
                                {analysis.confidence.toFixed(2)}
                              </Badge>
                            </div>
                            <div className="text-xs text-gray-600 mb-1">
                              {analysis.analysis.description}
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(analysis.timestamp).toLocaleString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Last Analysis Details */}
                  {visionStatus?.status?.lastAnalysis && (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h5 className="font-medium mb-2">Ultima Analisi</h5>
                      <div className="space-y-2">
                        <div className="text-sm">
                          <span className="font-medium">Tipo:</span> {visionStatus.status.lastAnalysis.input.type}
                        </div>
                        <div className="text-sm">
                          <span className="font-medium">Descrizione:</span> {visionStatus.status.lastAnalysis.analysis.description}
                        </div>
                        {visionStatus.status.lastAnalysis.analysis.key_elements.length > 0 && (
                          <div className="text-sm">
                            <span className="font-medium">Elementi:</span>
                            <div className="mt-1 space-x-1">
                              {visionStatus.status.lastAnalysis.analysis.key_elements.map((element, i) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {element}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Recent Sensor Readings */}
                  {visionStatus?.status?.recentSensors && visionStatus.status.recentSensors.length > 0 && (
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h5 className="font-medium mb-2">Letture Sensori Recenti</h5>
                      <div className="space-y-2">
                        {visionStatus.status.recentSensors.map((sensor, i) => (
                          <div key={i} className="bg-white p-3 rounded border">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-sm">Sensore {i + 1}</span>
                              <span className="text-xs text-gray-500">
                                {new Date(sensor.timestamp).toLocaleString()}
                              </span>
                            </div>
                            <div className="text-xs text-gray-600">
                              {sensor.analysis.summary}
                            </div>
                            {sensor.analysis.recommendations.length > 0 && (
                              <div className="text-xs text-blue-600 mt-1">
                                Raccomandazioni: {sensor.analysis.recommendations.slice(0, 2).join(', ')}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}