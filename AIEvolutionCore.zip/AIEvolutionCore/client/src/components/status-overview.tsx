import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { formatDistanceToNow } from "date-fns";

export function StatusOverview() {
  const queryClient = useQueryClient();
  
  const { data: suggestions, isLoading: suggestionsLoading } = useQuery({
    queryKey: ["/api/suggestions"],
    select: (data) => data.filter((s: any) => s.status === "pending")
  });
  
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/system/metrics"]
  });
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-between items-center">
            <h3 className="text-muted-foreground font-medium">AI Status</h3>
            <span className="flex items-center text-green-600">
              <span className="mdi mdi-check-circle"></span>
              <span className="ml-1 text-sm">Active</span>
            </span>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-semibold">v0.9.2</div>
            <p className="text-muted-foreground mt-1">Last update: {metricsLoading ? "Loading..." : formatDistanceToNow(new Date(metrics?.createdAt), { addSuffix: true })}</p>
          </div>
          <div className="mt-4 flex items-center">
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-primary rounded-full h-2" style={{ width: "75%" }}></div>
            </div>
            <span className="ml-2 text-sm text-muted-foreground">75%</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-between items-center">
            <h3 className="text-muted-foreground font-medium">Pending Suggestions</h3>
            <span className="bg-amber-100 text-amber-800 text-xs font-medium px-2.5 py-0.5 rounded">
              Needs Review
            </span>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-semibold">
              {suggestionsLoading ? "..." : suggestions?.length || 0}
            </div>
            <p className="text-muted-foreground mt-1">Code modifications</p>
          </div>
          <div className="mt-4">
            <button 
              className="text-primary hover:text-primary/80 text-sm font-medium flex items-center"
              onClick={() => window.location.href = "/codebase"}
            >
              <span className="mdi mdi-eye mr-1"></span>
              Review All Suggestions
            </button>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-between items-center">
            <h3 className="text-muted-foreground font-medium">Self-Evaluation Score</h3>
            <span className="mdi mdi-information-outline text-muted-foreground"></span>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-semibold">8.7/10</div>
            <p className="text-muted-foreground mt-1">Last 30 days performance</p>
          </div>
          <div className="mt-4">
            <div className="text-sm text-green-600 flex items-center">
              <span className="mdi mdi-trending-up mr-1"></span>
              <span>+1.2 since last month</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
