import React, { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { MessageCircle, Send, Bot, User, Zap, Code, Lightbulb, Brain, Bug, Settings, Trash2, Activity, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: string;
  type?: 'general' | 'code_review' | 'implementation' | 'suggestion';
  metadata?: {
    context?: string;
    confidence?: number;
    files_mentioned?: string[];
  };
}

interface ChatSession {
  id: string;
  messages: ChatMessage[];
  title: string;
  lastActivity: string;
  context: 'development' | 'implementation' | 'debugging' | 'architecture';
}

type ChatMode = 'general' | 'deep' | 'agent' | 'consciousness';
type ContextMode = 'development' | 'debugging' | 'architecture' | 'implementation';

export function AIChat() {
  const [message, setMessage] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);
  const [chatMode, setChatMode] = useState<ChatMode>('general');
  const [contextMode, setContextMode] = useState<ContextMode>('development');
  const scrollRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: chatSession, isLoading } = useQuery({
    queryKey: ["/api/chat/session"],
    refetchInterval: 5000
  });

  const { data: aiStatus } = useQuery({
    queryKey: ["/api/ai/status"],
    refetchInterval: 10000
  });

  const { data: consciousnessState } = useQuery({
    queryKey: ["/api/consciousness/state"],
    refetchInterval: 15000
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { content: string; context: string; mode: string }) => {
      return await apiRequest({
        method: "POST",
        url: "/api/chat/message",
        data: {
          message: messageData.content,
          context: messageData.context,
          mode: messageData.mode
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/session"] });
      setMessage("");
      toast({
        title: "Messaggio inviato",
        description: "L'AI ha ricevuto il messaggio e sta elaborando la risposta.",
      });
    },
    onError: (error: any) => {
      console.error("Chat advanced error:", error);
      toast({
        title: "Errore nella comunicazione",
        description: error?.message || "Sistema di fallback attivo. La chat dovrebbe funzionare comunque.",
        variant: "destructive"
      });
    }
  });

  const handleSend = () => {
    if (message.trim()) {
      sendMessageMutation.mutate({
        content: message,
        context: contextMode,
        mode: chatMode
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    // In a real implementation, you'd call an API to clear the chat
    queryClient.invalidateQueries({ queryKey: ["/api/chat/session"] });
    toast({
      title: "Chat pulita",
      description: "La conversazione è stata resettata."
    });
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatSession?.messages]);

  const getChatModeIcon = (mode: ChatMode) => {
    switch (mode) {
      case 'deep':
        return <Brain className="h-4 w-4" />;
      case 'agent':
        return <Activity className="h-4 w-4" />;
      case 'consciousness':
        return <Zap className="h-4 w-4" />;
      default:
        return <MessageCircle className="h-4 w-4" />;
    }
  };

  const getChatModeDescription = (mode: ChatMode) => {
    switch (mode) {
      case 'deep':
        return 'Analisi approfondita con ragionamento complesso e multi-step';
      case 'agent':
        return 'Interazione diretta con l\'agente autonomo per task specifici';
      case 'consciousness':
        return 'Comunicazione con la coscienza AI - memoria, credenze ed emozioni';
      default:
        return 'Conversazione generale con assistente AI standard';
    }
  };

  const getContextIcon = (context: ContextMode) => {
    switch (context) {
      case 'debugging':
        return <Bug className="h-4 w-4" />;
      case 'architecture':
        return <Settings className="h-4 w-4" />;
      case 'implementation':
        return <Code className="h-4 w-4" />;
      default:
        return <Lightbulb className="h-4 w-4" />;
    }
  };

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case 'code_review':
        return 'bg-blue-100 text-blue-800';
      case 'implementation':
        return 'bg-green-100 text-green-800';
      case 'suggestion':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAIPersonality = () => {
    switch (chatMode) {
      case 'deep':
        return 'AI Profonda';
      case 'agent':
        return 'Agente Autonomo';
      case 'consciousness':
        return 'Coscienza AI';
      default:
        return 'Assistente AI';
    }
  };

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Chat AI Avanzata
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64">
            <div className="text-gray-500">Inizializzazione chat...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5" />
          Chat AI Avanzata
          <Badge variant="outline" className="ml-auto">
            {chatSession?.messages?.length || 0} messaggi
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        {/* Chat Mode Selection */}
        <Tabs value={chatMode} onValueChange={(value) => setChatMode(value as ChatMode)} className="mb-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="general" className="flex items-center gap-1">
              <MessageCircle className="h-3 w-3" />
              Generale
            </TabsTrigger>
            <TabsTrigger value="deep" className="flex items-center gap-1">
              <Brain className="h-3 w-3" />
              Profonda
            </TabsTrigger>
            <TabsTrigger value="agent" className="flex items-center gap-1">
              <Activity className="h-3 w-3" />
              Agente
            </TabsTrigger>
            <TabsTrigger value="consciousness" className="flex items-center gap-1">
              <Zap className="h-3 w-3" />
              Coscienza
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Context and Status */}
        <div className="flex gap-2 mb-4">
          <Select value={contextMode} onValueChange={(value) => setContextMode(value as ContextMode)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Contesto" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="development">
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-4 w-4" />
                  Sviluppo
                </div>
              </SelectItem>
              <SelectItem value="debugging">
                <div className="flex items-center gap-2">
                  <Bug className="h-4 w-4" />
                  Debugging
                </div>
              </SelectItem>
              <SelectItem value="architecture">
                <div className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Architettura
                </div>
              </SelectItem>
              <SelectItem value="implementation">
                <div className="flex items-center gap-2">
                  <Code className="h-4 w-4" />
                  Implementazione
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${aiStatus?.availableProviders?.length > 0 ? 'bg-green-500' : 'bg-red-500'}`} />
              AI: {aiStatus?.availableProviders?.length || 0} provider
            </div>
            {chatMode === 'consciousness' && consciousnessState && (
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-purple-500" />
                Coscienza: {consciousnessState.totalThoughts} pensieri
              </div>
            )}
          </div>
        </div>

        {/* Mode Description */}
        <div className="mb-4 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
          <div className="flex items-center gap-2 text-sm font-medium text-blue-900">
            {getChatModeIcon(chatMode)}
            Modalità: {getAIPersonality()}
          </div>
          <p className="text-xs text-blue-700 mt-1">
            {getChatModeDescription(chatMode)}
          </p>
        </div>

        {/* Messages */}
        <ScrollArea 
          ref={scrollRef}
          className="flex-1 pr-4 mb-4"
          style={{ maxHeight: isExpanded ? '500px' : '300px' }}
        >
          {chatSession?.messages?.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <div className="mb-4">
                {getChatModeIcon(chatMode)}
                <div className="text-gray-400 text-4xl mt-2">{getChatModeIcon(chatMode)}</div>
              </div>
              <p className="font-medium">Inizia una conversazione con {getAIPersonality()}</p>
              <p className="text-sm mt-2">
                Scegli la modalità e il contesto appropriati per la tua domanda
              </p>
              <div className="mt-4 text-xs text-gray-400">
                <p>• Generale: Domande normali e conversazione</p>
                <p>• Profonda: Analisi complesse e ragionamento avanzato</p>
                <p>• Agente: Task specifici e automazione</p>
                <p>• Coscienza: Memoria, credenze e stato emotivo</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {chatSession?.messages?.map((msg: ChatMessage) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-4 py-3 ${
                      msg.role === 'user'
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-900 border'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      {msg.role === 'user' ? (
                        <User className="h-4 w-4" />
                      ) : (
                        <Bot className="h-4 w-4" />
                      )}
                      <span className="text-sm font-medium">
                        {msg.role === 'user' ? 'Tu' : getAIPersonality()}
                      </span>
                      {msg.type && (
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getMessageTypeColor(msg.type)}`}
                        >
                          {msg.type === 'code_review' ? 'Review' : 
                           msg.type === 'implementation' ? 'Implementazione' : 
                           msg.type === 'suggestion' ? 'Suggerimento' : 'Generale'}
                        </Badge>
                      )}
                      {msg.metadata?.confidence && (
                        <Badge variant="outline" className="text-xs">
                          {Math.round(msg.metadata.confidence * 100)}% sicuro
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm whitespace-pre-wrap leading-relaxed">
                      {msg.content}
                    </div>
                    <div className="text-xs opacity-70 mt-2 flex justify-between">
                      <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
                      {msg.metadata?.context && (
                        <span>Contesto: {msg.metadata.context}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        <Separator className="mb-4" />

        {/* Input Area */}
        <div className="space-y-3">
          <div className="flex gap-2">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={`Scrivi a ${getAIPersonality()} in contesto ${contextMode}...`}
              className="flex-1 min-h-[60px] resize-none"
              disabled={sendMessageMutation.isPending}
            />
            <Button
              onClick={handleSend}
              disabled={!message.trim() || sendMessageMutation.isPending}
              size="sm"
              className="self-end"
            >
              {sendMessageMutation.isPending ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>

          {/* Controls */}
          <div className="flex justify-between items-center">
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? 'Comprimi' : 'Espandi'}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearChat}
              >
                <Trash2 className="h-4 w-4" />
                Pulisci
              </Button>
            </div>
            <div className="text-xs text-gray-500">
              {sendMessageMutation.isPending ? 'Invio in corso...' : 'Invio con Invio • Nuova riga con Shift+Invio'}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}