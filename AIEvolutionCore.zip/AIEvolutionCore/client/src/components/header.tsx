import React from "react";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export function Header({ title, subtitle }: HeaderProps) {
  return (
    <header className="bg-card/80 backdrop-blur-md border-b border-border/40 p-4 flex justify-between items-center sticky top-0 z-20 holographic">
      <div>
        <h1 className="text-xl font-semibold text-primary neon-text animate-glow-pulse">{title}</h1>
        {subtitle && <p className="text-muted-foreground text-sm mt-1 animate-pulse">{subtitle}</p>}
      </div>
      <div className="flex items-center space-x-4">
        <button className="p-2 rounded-full hover:bg-accent/20 border-glow transition-all duration-300 animate-float">
          <span className="mdi mdi-bell-outline text-accent text-xl"></span>
        </button>
        <button className="p-2 rounded-full hover:bg-accent/20 border-glow transition-all duration-300 animate-float">
          <span className="mdi mdi-help-circle-outline text-accent text-xl"></span>
        </button>
      </div>
    </header>
  );
}
