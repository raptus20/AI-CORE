import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, Activity, RotateCcw } from "lucide-react";

interface AIProviderStats {
  totalRequests: number;
  successfulRequests: number;
  successRate: string;
  availableProviders: string[];
  totalProviders: number;
  providerUsage: Record<string, { requests: number; errors: number }>;
}

export function AIProviderStatus() {
  const { data: stats, isLoading } = useQuery<AIProviderStats>({
    queryKey: ['/api/ai/status'],
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  if (isLoading || !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            AI Provider Status
          </CardTitle>
          <CardDescription>Loading provider statistics...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const successRate = parseFloat(stats.successRate.replace('%', ''));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          AI Provider Status
        </CardTitle>
        <CardDescription>
          Multi-provider AI system with automatic failover
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold">{stats.totalRequests}</div>
            <div className="text-sm text-gray-600">Total Requests</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.successfulRequests}</div>
            <div className="text-sm text-gray-600">Successful</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{stats.successRate}</div>
            <div className="text-sm text-gray-600">Success Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{stats.availableProviders.length}</div>
            <div className="text-sm text-gray-600">Active Providers</div>
          </div>
        </div>

        {/* Success Rate Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Success Rate</span>
            <span>{stats.successRate}</span>
          </div>
          <Progress value={successRate} className="h-2" />
        </div>

        {/* Provider Status */}
        <div className="space-y-3">
          <h4 className="font-medium flex items-center gap-2">
            <RotateCcw className="h-4 w-4" />
            Provider Status
          </h4>
          <div className="space-y-2">
            {stats.availableProviders.map((provider) => {
              const usage = stats.providerUsage[provider] || { requests: 0, errors: 0 };
              const providerSuccess = usage.requests > 0 
                ? ((usage.requests - usage.errors) / usage.requests * 100).toFixed(1) + '%'
                : 'N/A';
              
              return (
                <div key={provider} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="font-medium">{provider}</span>
                    <Badge variant="outline" className="text-xs">
                      Active
                    </Badge>
                  </div>
                  <div className="text-right text-sm text-gray-600">
                    <div>{usage.requests} requests</div>
                    <div>{providerSuccess} success</div>
                  </div>
                </div>
              );
            })}
            
            {/* Show offline providers */}
            {Array.from(new Set(['DeepSeek', 'OpenAI', 'Claude', 'Groq']))
              .filter(provider => !stats.availableProviders.includes(provider))
              .map((provider) => (
                <div key={provider} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg opacity-50">
                  <div className="flex items-center gap-2">
                    <XCircle className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">{provider}</span>
                    <Badge variant="secondary" className="text-xs">
                      Offline
                    </Badge>
                  </div>
                  <div className="text-right text-sm text-gray-500">
                    <div>No API key</div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Key Rotation Info */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <h5 className="font-medium text-blue-900 mb-1">Intelligent Key Rotation</h5>
          <p className="text-sm text-blue-700">
            The system automatically rotates between multiple API keys when rate limits are reached, 
            ensuring maximum uptime and quota utilization.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}