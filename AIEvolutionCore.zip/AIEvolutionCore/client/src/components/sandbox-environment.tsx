import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { formatDistanceToNow } from "date-fns";

export function SandboxEnvironment() {
  const { data: tests, isLoading } = useQuery({
    queryKey: ["/api/sandbox/tests"],
    queryFn: () => aiService.getAllTests(),
    select: (data) => data?.slice(0, 3) // Only get the 3 most recent tests
  });
  
  return (
    <Card>
      <CardHeader className="border-b border-neutral-200 p-4">
        <CardTitle className="font-semibold text-base">Sandbox Environment</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="flex items-center mb-4">
          <div className="w-3 h-3 rounded-full bg-green-600 mr-2"></div>
          <span className="text-sm font-medium">Available for Testing</span>
          <Button 
            variant="link"
            className="ml-auto text-primary text-sm font-medium p-0 h-auto"
            onClick={() => window.location.href = "/sandbox"}
          >
            Launch New Test
          </Button>
        </div>
        
        <div className="border border-neutral-200 rounded-lg p-4 mb-4">
          <h3 className="text-sm font-medium mb-2">Recent Sandbox Tests</h3>
          {isLoading ? (
            <div className="flex justify-center py-4">
              <span className="mdi mdi-loading mdi-spin text-2xl text-neutral-500"></span>
            </div>
          ) : tests?.length ? (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-neutral-500 border-b border-neutral-200">
                  <th className="pb-2">Test ID</th>
                  <th className="pb-2">Module</th>
                  <th className="pb-2">Status</th>
                  <th className="pb-2">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {tests.map((test) => (
                  <tr key={test.id}>
                    <td className="py-2">{test.testId}</td>
                    <td className="py-2">{test.moduleName}</td>
                    <td className="py-2">
                      <span className={
                        test.status === "completed" 
                          ? "text-green-600" 
                          : test.status === "running"
                            ? "text-blue-500"
                            : "text-amber-500"
                      }>
                        {test.status.charAt(0).toUpperCase() + test.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-2">
                      {test.status === "completed" ? (
                        <span className={test.result === "passed" ? "text-green-600" : "text-red-600"}>
                          {test.result}
                        </span>
                      ) : (
                        <span className="text-neutral-500">-</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-sm text-neutral-500 text-center py-4">No tests have been run yet</p>
          )}
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">Sandbox Configuration</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-neutral-50 rounded-lg border">
              <div className="flex items-center">
                <span className="mdi mdi-shield-check text-lg text-primary mr-2"></span>
                <span className="text-sm">Isolation Level: <span className="font-medium">High</span></span>
              </div>
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border">
              <div className="flex items-center">
                <span className="mdi mdi-timer-outline text-lg text-primary mr-2"></span>
                <span className="text-sm">Max Duration: <span className="font-medium">30 min</span></span>
              </div>
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border">
              <div className="flex items-center">
                <span className="mdi mdi-memory text-lg text-primary mr-2"></span>
                <span className="text-sm">Resource Limit: <span className="font-medium">Medium</span></span>
              </div>
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border">
              <div className="flex items-center">
                <span className="mdi mdi-file-document-outline text-lg text-primary mr-2"></span>
                <span className="text-sm">Logging: <span className="font-medium">Verbose</span></span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
