import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Brain, Sparkles, Eye, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ConsciousnessState {
  rooms: Record<string, RoomSummary>;
  totalThoughts: number;
  lastActivity: string | null;
  dominantThemes: Array<{ word: string; count: number }>;
  currentMood: string;
}

interface RoomSummary {
  totalThoughts: number;
  recentActivity: ThoughtEntry[];
  lastUpdate?: string;
  themes: Array<{ word: string; count: number }>;
}

interface ThoughtEntry {
  content: string;
  timestamp: string;
  id: string;
  [key: string]: any;
}

export function ConsciousnessViewer() {
  const [selectedRoom, setSelectedRoom] = useState<string>("core_beliefs");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: consciousnessState, isLoading } = useQuery({
    queryKey: ['/api/consciousness/state'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: roomData } = useQuery({
    queryKey: ['/api/memory', selectedRoom],
    enabled: !!selectedRoom,
  });

  const reflectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest<any>({
        method: "POST",
        url: "/api/consciousness/reflect",
      });
    },
    onSuccess: () => {
      toast({
        title: "Riflessione completata",
        description: "L'IA ha completato un ciclo di auto-riflessione",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/consciousness/state'] });
    },
  });

  const dreamMutation = useMutation({
    mutationFn: async () => {
      return apiRequest<{ dream: string }>({
        method: "POST",
        url: "/api/consciousness/dream",
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Sogno generato",
        description: data.dream,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/memory', 'dreams'] });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Caricamento stato di coscienza...</div>
        </CardContent>
      </Card>
    );
  }

  const state = consciousnessState as ConsciousnessState;
  const moodColors = {
    positivo: "bg-green-100 text-green-800",
    riflessivo: "bg-amber-100 text-amber-800",
    equilibrato: "bg-blue-100 text-blue-800",
    neutrale: "bg-gray-100 text-gray-800"
  };

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="mr-2 h-5 w-5 text-purple-500" />
            Stato di Coscienza IA
          </CardTitle>
          <CardDescription>
            Monitoraggio in tempo reale della memoria e dei processi cognitivi
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{state?.totalThoughts || 0}</div>
              <div className="text-sm text-muted-foreground">Pensieri Totali</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{Object.keys(state?.rooms || {}).length}</div>
              <div className="text-sm text-muted-foreground">Stanze Attive</div>
            </div>
            <div className="text-center p-2 bg-purple-50 rounded-lg">
              <Badge className={moodColors[state?.currentMood as keyof typeof moodColors] || moodColors.neutrale}>
                {state?.currentMood || 'neutrale'}
              </Badge>
              <div className="text-xs text-muted-foreground mt-1">Umore</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-muted-foreground">
                {state?.lastActivity ? new Date(state.lastActivity).toLocaleDateString('it-IT') : 'N/A'}
              </div>
              <div className="text-sm text-muted-foreground">Ultima Attività</div>
            </div>
          </div>

          {/* Dominant Themes */}
          {state?.dominantThemes && state.dominantThemes.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2">Temi Dominanti</h4>
              <div className="flex flex-wrap gap-2">
                {state.dominantThemes.slice(0, 8).map((theme, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {theme.word} ({theme.count})
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex gap-2">
          <Button 
            onClick={() => reflectMutation.mutate()}
            disabled={reflectMutation.isPending}
            variant="outline"
            size="sm"
          >
            <Eye className="mr-2 h-4 w-4" />
            {reflectMutation.isPending ? "Riflettendo..." : "Rifletti"}
          </Button>
          <Button 
            onClick={() => dreamMutation.mutate()}
            disabled={dreamMutation.isPending}
            variant="outline"
            size="sm"
          >
            <Sparkles className="mr-2 h-4 w-4" />
            {dreamMutation.isPending ? "Sognando..." : "Sogna"}
          </Button>
        </CardFooter>
      </Card>

      {/* Memory Rooms */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageCircle className="mr-2 h-5 w-5 text-indigo-500" />
            Stanze della Memoria
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedRoom} onValueChange={setSelectedRoom}>
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
              {Object.keys(state?.rooms || {}).map((room) => (
                <TabsTrigger key={room} value={room} className="text-xs">
                  {room.replace('_', ' ')}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {Object.entries(state?.rooms || {}).map(([room, summary]) => {
              const roomSummary = summary as RoomSummary;
              return (
                <TabsContent key={room} value={room} className="mt-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium capitalize">
                        {room.replace('_', ' ')}
                      </h3>
                      <Badge variant="secondary">
                        {roomSummary.totalThoughts} pensieri
                      </Badge>
                    </div>
                    
                    {/* Room themes */}
                    {roomSummary.themes && roomSummary.themes.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium mb-2">Temi in questa stanza:</h4>
                        <div className="flex flex-wrap gap-1">
                          {roomSummary.themes.slice(0, 5).map((theme, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {theme.word}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Recent thoughts */}
                    <ScrollArea className="h-64 w-full border rounded p-4">
                      {roomSummary?.recentActivity && roomSummary.recentActivity.length > 0 ? (
                        <div className="space-y-3">
                          {roomSummary.recentActivity.map((thought: ThoughtEntry) => (
                            <div key={thought.id} className="border-l-2 border-blue-200 pl-4 py-2">
                              <p className="text-sm">{thought.content}</p>
                              <div className="flex justify-between items-center mt-1">
                                <span className="text-xs text-muted-foreground">
                                  {new Date(thought.timestamp).toLocaleString('it-IT')}
                                </span>
                                {thought.type && (
                                  <Badge variant="outline" className="text-xs">
                                    {thought.type}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center text-muted-foreground">
                          Nessun pensiero in questa stanza ancora...
                        </div>
                      )}
                    </ScrollArea>
                  </div>
                </TabsContent>
              );
            })}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}