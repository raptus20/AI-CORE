import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";

export function SystemHealth() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/system/metrics"],
    queryFn: () => aiService.getSystemMetrics(),
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="border-b border-neutral-200 p-4">
          <CardTitle className="font-semibold text-base">System Health</CardTitle>
        </CardHeader>
        <CardContent className="p-4 flex justify-center items-center h-40">
          <span className="mdi mdi-loading mdi-spin text-2xl text-neutral-500"></span>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="border-b border-neutral-200 p-4">
        <CardTitle className="font-semibold text-base">System Health</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Memory Usage</span>
            <span className="text-sm text-neutral-500">{metrics?.memoryUsage || 0}%</span>
          </div>
          <Progress value={metrics?.memoryUsage || 0} className="bg-neutral-200 h-2" />
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">CPU Load</span>
            <span className="text-sm text-neutral-500">{metrics?.cpuLoad || 0}%</span>
          </div>
          <Progress value={metrics?.cpuLoad || 0} className="bg-neutral-200 h-2" />
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Storage</span>
            <span className="text-sm text-neutral-500">{metrics?.storage || 0}%</span>
          </div>
          <Progress 
            value={metrics?.storage || 0} 
            className="bg-neutral-200 h-2"
            indicatorClassName={metrics?.storage && metrics.storage > 80 ? "bg-amber-500" : undefined}
          />
        </div>
        
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Safety Protocols</span>
            <span className="text-sm text-green-600">{metrics?.safetyProtocols ? "Active" : "Inactive"}</span>
          </div>
          <Progress 
            value={metrics?.safetyProtocols ? 100 : 0} 
            className="bg-neutral-200 h-2"
            indicatorClassName="bg-green-600"
          />
        </div>
      </CardContent>
    </Card>
  );
}
