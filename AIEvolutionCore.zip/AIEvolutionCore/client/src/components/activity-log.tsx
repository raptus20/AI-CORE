import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { formatDistanceToNow } from "date-fns";

interface ActivityIconProps {
  eventType: string;
}

function ActivityIcon({ eventType }: ActivityIconProps) {
  let icon: string;
  let bgColor: string;
  
  switch(eventType) {
    case "suggestion":
      icon = "mdi-cog";
      bgColor = "bg-blue-100 text-primary";
      break;
    case "approval":
      icon = "mdi-check";
      bgColor = "bg-green-100 text-green-600";
      break;
    case "test":
    case "test_completed":
      icon = "mdi-test-tube";
      bgColor = "bg-purple-100 text-purple-600";
      break;
    case "rejection":
      icon = "mdi-close";
      bgColor = "bg-red-100 text-red-600";
      break;
    default:
      icon = "mdi-alert";
      bgColor = "bg-amber-100 text-amber-700";
  }
  
  return (
    <div className="mr-3 flex-shrink-0">
      <div className={`w-8 h-8 rounded-full ${bgColor} flex items-center justify-center`}>
        <span className={`mdi ${icon}`}></span>
      </div>
    </div>
  );
}

interface ActivityLogProps {
  limit?: number;
}

export function ActivityLog({ limit = 5 }: ActivityLogProps) {
  const { data: logs, isLoading } = useQuery({
    queryKey: ["/api/activity", limit],
    queryFn: () => aiService.getActivityLogs(limit),
  });
  
  return (
    <Card>
      <CardHeader className="border-b border-neutral-200 p-4">
        <CardTitle className="font-semibold text-base">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="overflow-y-auto max-h-96">
          {isLoading ? (
            <div className="flex justify-center py-4">
              <span className="mdi mdi-loading mdi-spin text-2xl text-neutral-500"></span>
            </div>
          ) : logs?.length ? (
            logs.map((log) => (
              <div className="flex mb-4" key={log.id}>
                <ActivityIcon eventType={log.eventType} />
                <div>
                  <p className="text-sm">{log.description}</p>
                  <p className="text-xs text-neutral-500 mt-1">
                    {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-neutral-500 text-center py-4">No activity logged yet</p>
          )}
        </div>
        
        <div className="mt-4">
          <Button 
            variant="outline" 
            className="w-full py-2 text-sm text-primary bg-blue-50 hover:bg-blue-100 transition-colors"
            onClick={() => window.location.href = "/activity-log"}
          >
            View Full Activity Log
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
