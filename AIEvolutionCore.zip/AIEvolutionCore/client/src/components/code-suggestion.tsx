import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { CodeEditor } from "@/components/ui/code-editor";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { ApprovalModal } from "@/components/approval-modal";
import { useToast } from "@/hooks/use-toast";

interface CodeSuggestionProps {
  suggestionId?: number;
}

export function CodeSuggestion({ suggestionId }: CodeSuggestionProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isApprovalModalOpen, setIsApprovalModalOpen] = useState(false);
  
  // Fetch suggestions - either a specific one or the latest one
  const { data: suggestion, isLoading } = useQuery({
    queryKey: [suggestionId ? `/api/suggestions/${suggestionId}` : "/api/suggestions"],
    queryFn: async () => {
      if (suggestionId) {
        return aiService.getSuggestion(suggestionId);
      } else {
        const suggestions = await aiService.getAllSuggestions();
        return suggestions[0]; // Get the latest suggestion
      }
    }
  });

  // Mutation for updating suggestion status
  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number, status: string }) => 
      aiService.updateSuggestionStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      if (suggestionId) {
        queryClient.invalidateQueries({ queryKey: [`/api/suggestions/${suggestionId}`] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/activity"] });
      toast({
        title: "Success",
        description: "Suggestion status updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update suggestion status",
        variant: "destructive"
      });
    }
  });

  // Mutation for sandbox testing
  const sandboxTestMutation = useMutation({
    mutationFn: (id: number) => aiService.runSuggestionInSandbox(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      if (suggestionId) {
        queryClient.invalidateQueries({ queryKey: [`/api/suggestions/${suggestionId}`] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/sandbox/tests"] });
      toast({
        title: "Test started",
        description: "Code is now being tested in the sandbox",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start sandbox test",
        variant: "destructive"
      });
    }
  });

  const handleApprove = (id: number) => {
    setIsApprovalModalOpen(true);
  };

  const confirmApproval = (id: number) => {
    updateStatusMutation.mutate({ id, status: "approved" });
    setIsApprovalModalOpen(false);
  };

  const handleReject = (id: number) => {
    updateStatusMutation.mutate({ id, status: "rejected" });
  };

  const handleTestInSandbox = (id: number) => {
    sandboxTestMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="border-b border-neutral-200 p-4">
          <CardTitle className="font-semibold text-base">Loading Suggestion...</CardTitle>
        </CardHeader>
        <CardContent className="p-4 flex justify-center items-center h-64">
          <span className="mdi mdi-loading mdi-spin text-3xl text-neutral-500"></span>
        </CardContent>
      </Card>
    );
  }

  if (!suggestion) {
    return (
      <Card>
        <CardHeader className="border-b border-neutral-200 p-4">
          <CardTitle className="font-semibold text-base">No Suggestions Available</CardTitle>
        </CardHeader>
        <CardContent className="p-4 flex justify-center items-center h-64">
          <p className="text-neutral-500">There are no code suggestions available at this time.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="border-b border-neutral-200 p-4">
          <CardTitle className="font-semibold text-base">
            {suggestionId ? "Code Suggestion Details" : "Latest Code Suggestion"}
          </CardTitle>
        </CardHeader>
        
        <Tabs defaultValue="suggestion">
          <div className="border-b border-neutral-200">
            <TabsList className="border-0">
              <TabsTrigger value="suggestion" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Suggestion
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Analysis
              </TabsTrigger>
              <TabsTrigger value="impact" className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none">
                Impact Assessment
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="suggestion" className="p-4 m-0">
            <div className="mb-4">
              <h3 className="font-medium">{suggestion.title}</h3>
              <p className="text-neutral-500 text-sm mt-1">
                Modified: <span className="text-primary font-medium">{suggestion.filePath}</span>
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              <div>
                <div className="text-sm font-medium mb-1">Current Code</div>
                <CodeEditor
                  language="javascript"
                  value={suggestion.currentCode}
                  readOnly
                />
              </div>
              
              <div>
                <div className="text-sm font-medium mb-1">Suggested Change</div>
                <CodeEditor
                  language="javascript"
                  value={suggestion.suggestedCode}
                  readOnly
                />
              </div>
            </div>
            
            <div className="mb-4">
              <div className="text-sm font-medium mb-2">AI's Reasoning</div>
              <div className="bg-neutral-50 rounded-lg p-4 text-sm border">
                <p>{suggestion.reasoning}</p>
              </div>
            </div>
            
            <div>
              <div className="text-sm font-medium mb-2">Expected Improvement</div>
              {suggestion.expectedImprovement && suggestion.expectedImprovement.accuracy !== undefined && (
                <div className="flex items-center mb-2">
                  <div className="w-1/4 text-sm">Accuracy: </div>
                  <div className="w-2/4">
                    <Progress value={suggestion.expectedImprovement.accuracy} className="bg-neutral-200 h-2" />
                  </div>
                  <div className="w-1/4 text-sm text-green-600 font-medium pl-4">
                    +{suggestion.expectedImprovement.accuracy}%
                  </div>
                </div>
              )}
              {suggestion.expectedImprovement && suggestion.expectedImprovement.performance !== undefined && (
                <div className="flex items-center">
                  <div className="w-1/4 text-sm">Performance: </div>
                  <div className="w-2/4">
                    <Progress 
                      value={Math.abs(suggestion.expectedImprovement.performance)} 
                      className={`h-2 ${suggestion.expectedImprovement.performance < 0 ? "bg-amber-200" : "bg-neutral-200"}`}
                      style={{
                        "--tw-bg-opacity": 1,
                        backgroundColor: suggestion.expectedImprovement.performance < 0 ? "rgb(253 230 138 / var(--tw-bg-opacity))" : "rgb(229 231 235 / var(--tw-bg-opacity))"
                      } as React.CSSProperties}
                    >
                      <div 
                        className="h-full w-full flex-1 bg-primary transition-all" 
                        style={{ 
                          width: `${Math.abs(suggestion.expectedImprovement.performance)}%`,
                          backgroundColor: suggestion.expectedImprovement.performance < 0 ? "rgb(245 158 11 / var(--tw-bg-opacity))" : "rgb(22 163 74 / var(--tw-bg-opacity))"
                        }}
                      />
                    </Progress>
                  </div>
                  <div className={`w-1/4 text-sm font-medium pl-4 ${suggestion.expectedImprovement.performance < 0 ? "text-amber-500" : "text-green-600"}`}>
                    {suggestion.expectedImprovement.performance > 0 ? "+" : ""}{suggestion.expectedImprovement.performance}%
                  </div>
                </div>
              )}
            </div>
            
            <div className="mt-6 flex flex-wrap gap-4">
              <Button
                onClick={() => handleApprove(suggestion.id)}
                disabled={updateStatusMutation.isPending || suggestion.status === "approved" || suggestion.status === "testing"}
                className="bg-primary text-white hover:bg-primary/90 flex items-center"
              >
                <span className="mdi mdi-check mr-1"></span>
                Approve
              </Button>
              <Button
                variant="outline"
                onClick={() => handleReject(suggestion.id)}
                disabled={updateStatusMutation.isPending || suggestion.status === "rejected" || suggestion.status === "testing"}
                className="bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-100 flex items-center"
              >
                <span className="mdi mdi-close mr-1"></span>
                Reject
              </Button>
              <Button
                variant="outline"
                onClick={() => handleTestInSandbox(suggestion.id)}
                disabled={sandboxTestMutation.isPending || suggestion.status === "testing"}
                className="bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-100 flex items-center"
              >
                <span className="mdi mdi-test-tube mr-1"></span>
                {suggestion.status === "testing" ? "Testing..." : "Test in Sandbox"}
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="analysis" className="p-4 m-0">
            <div className="bg-neutral-50 p-4 rounded-lg border">
              <h3 className="font-medium mb-2">Code Analysis</h3>
              <p className="text-sm mb-4">
                This section provides a detailed analysis of the suggested code changes, including:
              </p>
              <ul className="list-disc pl-5 text-sm space-y-2">
                <li>Complexity reduction: <span className="font-medium text-green-600">-15%</span></li>
                <li>Maintainability improvement: <span className="font-medium text-green-600">+25%</span></li>
                <li>Error handling improvement: <span className="font-medium text-green-600">+40%</span></li>
              </ul>
            </div>
          </TabsContent>
          
          <TabsContent value="impact" className="p-4 m-0">
            <div className="bg-neutral-50 p-4 rounded-lg border">
              <h3 className="font-medium mb-2">System Impact Assessment</h3>
              <p className="text-sm mb-4">
                Implementing this code change is expected to have the following impact on the system:
              </p>
              <ul className="list-disc pl-5 text-sm space-y-2">
                <li>Resource usage: <span className="font-medium text-amber-500">+2%</span> (Memory)</li>
                <li>Response time: <span className="font-medium text-green-600">-5%</span> (Faster)</li>
                <li>Security implications: <span className="font-medium text-neutral-600">None</span></li>
              </ul>
            </div>
          </TabsContent>
        </Tabs>
      </Card>
      
      <ApprovalModal
        isOpen={isApprovalModalOpen}
        onClose={() => setIsApprovalModalOpen(false)}
        onConfirm={() => confirmApproval(suggestion.id)}
        suggestion={suggestion}
      />
    </>
  );
}
