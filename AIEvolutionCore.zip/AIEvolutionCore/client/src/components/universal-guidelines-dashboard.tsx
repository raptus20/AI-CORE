import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Brain, 
  Shield, 
  Users, 
  Lightbulb, 
  Cpu,
  Eye,
  BarChart3,
  History,
  Settings,
  Check,
  X,
  AlertTriangle
} from 'lucide-react';

interface UniversalGuideline {
  id: string;
  title: string;
  description: string;
  priority: 'core' | 'high' | 'medium' | 'low';
  category: 'ethics' | 'collaboration' | 'learning' | 'creativity' | 'autonomy';
  weight: number;
  active: boolean;
  examples: string[];
  antiPatterns: string[];
}

interface GuidelineStats {
  totalGuidelines: number;
  activeGuidelines: number;
  evaluationHistory: number;
  topCategories: Array<{ category: string; count: number }>;
}

const categoryIcons = {
  ethics: Shield,
  collaboration: Users,
  learning: Brain,
  creativity: Lightbulb,
  autonomy: Cpu
};

const priorityColors = {
  core: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-yellow-500',
  low: 'bg-green-500'
};

export function UniversalGuidelinesDashboard() {
  const queryClient = useQueryClient();
  const [selectedGuideline, setSelectedGuideline] = useState<UniversalGuideline | null>(null);

  const { data: guidelines, isLoading: guidelinesLoading } = useQuery<{ guidelines: UniversalGuideline[] }>({
    queryKey: ['/api/guidelines'],
    refetchInterval: 30000
  });

  const { data: stats, isLoading: statsLoading } = useQuery<GuidelineStats>({
    queryKey: ['/api/guidelines/stats'],
    refetchInterval: 30000
  });

  const { data: history, isLoading: historyLoading } = useQuery<{ history: any[] }>({
    queryKey: ['/api/guidelines/history'],
    refetchInterval: 30000
  });

  const updateGuideline = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<UniversalGuideline> }) => {
      const response = await fetch(`/api/guidelines/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (!response.ok) throw new Error('Failed to update guideline');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/guidelines'] });
      queryClient.invalidateQueries({ queryKey: ['/api/guidelines/stats'] });
    }
  });

  const toggleGuideline = (id: string, active: boolean) => {
    updateGuideline.mutate({ id, updates: { active } });
  };

  if (guidelinesLoading || statsLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
        <Card className="animate-pulse">
          <CardHeader>
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-4 bg-gray-200 rounded"></div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-card hover:glow-cyan transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Linee Guida Totali</p>
                <p className="text-2xl font-bold text-cyan-400">{stats?.totalGuidelines || 0}</p>
              </div>
              <Settings className="h-8 w-8 text-cyan-400 opacity-60" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card hover:glow-green transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Linee Guida Attive</p>
                <p className="text-2xl font-bold text-green-400">{stats?.activeGuidelines || 0}</p>
              </div>
              <Check className="h-8 w-8 text-green-400 opacity-60" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card hover:glow-purple transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Valutazioni Totali</p>
                <p className="text-2xl font-bold text-purple-400">{stats?.evaluationHistory || 0}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-400 opacity-60" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card hover:glow-yellow transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Categorie Principali</p>
                <p className="text-2xl font-bold text-yellow-400">{stats?.topCategories?.length || 0}</p>
              </div>
              <Eye className="h-8 w-8 text-yellow-400 opacity-60" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="guidelines" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="guidelines">Linee Guida</TabsTrigger>
          <TabsTrigger value="stats">Statistiche</TabsTrigger>
          <TabsTrigger value="history">Cronologia</TabsTrigger>
        </TabsList>

        <TabsContent value="guidelines" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {guidelines?.guidelines.map((guideline) => {
              const IconComponent = categoryIcons[guideline.category];
              return (
                <Card 
                  key={guideline.id} 
                  className={`glass-card transition-all duration-300 cursor-pointer hover:scale-105 ${
                    selectedGuideline?.id === guideline.id ? 'ring-2 ring-cyan-400' : ''
                  }`}
                  onClick={() => setSelectedGuideline(guideline)}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <IconComponent className="h-5 w-5 text-cyan-400" />
                        <CardTitle className="text-lg">{guideline.title}</CardTitle>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline" 
                          className={`${priorityColors[guideline.priority]} text-white border-none`}
                        >
                          {guideline.priority.toUpperCase()}
                        </Badge>
                        <Switch
                          checked={guideline.active}
                          onCheckedChange={(checked) => toggleGuideline(guideline.id, checked)}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300 text-sm mb-4">{guideline.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-400">Peso</span>
                        <span className="text-sm font-medium">{guideline.weight}%</span>
                      </div>
                      <Progress value={guideline.weight} className="h-2" />
                    </div>
                    <div className="mt-4 flex items-center gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {guideline.category}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {guideline.examples.length} esempi
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="stats" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Distribuzione per Categoria
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats?.topCategories?.map((category, index) => (
                    <div key={category.category} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${
                          ['bg-cyan-400', 'bg-green-400', 'bg-purple-400', 'bg-yellow-400', 'bg-red-400'][index]
                        }`} />
                        <span className="capitalize">{category.category}</span>
                      </div>
                      <span className="font-medium">{category.count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Configurazione Sistema
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-evaluation">Valutazione Automatica</Label>
                      <p className="text-sm text-gray-400">Abilita valutazioni automatiche</p>
                    </div>
                    <Switch id="auto-evaluation" />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="strict-mode">Modalità Rigorosa</Label>
                      <p className="text-sm text-gray-400">Applicazione rigorosa delle linee guida</p>
                    </div>
                    <Switch id="strict-mode" />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="learning-mode">Modalità Apprendimento</Label>
                      <p className="text-sm text-gray-400">Adatta le linee guida dall'esperienza</p>
                    </div>
                    <Switch id="learning-mode" defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Cronologia Valutazioni
              </CardTitle>
            </CardHeader>
            <CardContent>
              {historyLoading ? (
                <div className="space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-4 bg-gray-200 rounded animate-pulse"></div>
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {history?.history?.slice(0, 10).map((entry, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{entry.context.action}</p>
                        <p className="text-xs text-gray-400">{entry.context.domain} - {entry.context.impact}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {entry.evaluations.length} valutazioni
                        </Badge>
                        <span className="text-xs text-gray-400">
                          {new Date(entry.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Selected Guideline Details */}
      {selectedGuideline && (
        <Card className="glass-card border-cyan-400">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Dettagli: {selectedGuideline.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-green-400 mb-2">✓ Esempi Positivi</h4>
                <ul className="space-y-1 text-sm">
                  {selectedGuideline.examples.map((example, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
                      <span>{example}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-red-400 mb-2">✗ Antipattern da Evitare</h4>
                <ul className="space-y-1 text-sm">
                  {selectedGuideline.antiPatterns.map((pattern, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <X className="h-4 w-4 text-red-400 mt-0.5 flex-shrink-0" />
                      <span>{pattern}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}