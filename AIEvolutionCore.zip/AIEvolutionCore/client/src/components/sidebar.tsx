import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface SidebarLinkProps {
  href: string;
  icon: string;
  children: React.ReactNode;
  currentPath: string;
}

function SidebarLink({ href, icon, children, currentPath }: SidebarLinkProps) {
  const isActive = currentPath === href;
  
  return (
    <Link href={href}>
      <div
        className={cn(
          "flex items-center px-4 py-2 text-muted-foreground hover:bg-accent cursor-pointer transition-all duration-200 border-glow rounded-lg mx-2 my-1",
          isActive && "text-primary bg-primary/10 border-l-4 border-primary"
        )}
      >
        <span className={`mdi ${icon} mr-3 ${isActive ? 'text-primary' : 'text-accent'}`}></span>
        {children}
      </div>
    </Link>
  );
}

export function Sidebar() {
  const [location] = useLocation();
  
  return (
    <aside className="w-64 bg-card border-r border-border z-10 flex flex-col h-full">
      <div className="p-4 border-b border-border flex items-center">
        <span className="mdi mdi-robot text-primary text-2xl mr-2"></span>
        <h1 className="font-semibold text-lg text-primary">AI Self-Improvement</h1>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4">
        <div className="px-4 mb-2 text-muted-foreground text-sm font-medium">MAIN</div>
        <SidebarLink href="/" icon="mdi-view-dashboard" currentPath={location}>
          Dashboard
        </SidebarLink>
        <SidebarLink href="/codebase" icon="mdi-code-braces" currentPath={location}>
          Codebase
        </SidebarLink>
        <SidebarLink href="/sandbox" icon="mdi-test-tube" currentPath={location}>
          Sandbox
        </SidebarLink>
        <SidebarLink href="/version-control" icon="mdi-source-branch" currentPath={location}>
          Version Control
        </SidebarLink>
        
        <div className="px-4 mt-6 mb-2 text-neutral-500 text-sm font-medium">SETTINGS</div>
        <SidebarLink href="/configuration" icon="mdi-cog" currentPath={location}>
          Configuration
        </SidebarLink>
        <SidebarLink href="/safety-protocols" icon="mdi-security" currentPath={location}>
          Safety Protocols
        </SidebarLink>
        <SidebarLink href="/user-management" icon="mdi-account-cog" currentPath={location}>
          User Management
        </SidebarLink>
        <SidebarLink href="/universal-guidelines" icon="mdi-compass" currentPath={location}>
          Universal Guidelines
        </SidebarLink>
      </nav>
      
      <div className="p-4 border-t border-border">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
            <span className="mdi mdi-account"></span>
          </div>
          <div className="ml-3">
            <div className="text-sm font-medium">Admin User</div>
            <div className="text-xs text-muted-foreground">Human Overseer</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
