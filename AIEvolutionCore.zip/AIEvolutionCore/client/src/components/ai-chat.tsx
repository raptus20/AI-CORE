import React, { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { MessageCircle, Send, Bot, User, Zap, Code, Lightbulb, Brain, Bug, Settings, Trash2, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: string;
  type?: 'general' | 'code_review' | 'implementation' | 'suggestion';
  metadata?: {
    context?: string;
    confidence?: number;
    files_mentioned?: string[];
  };
}

interface ChatSession {
  id: string;
  messages: ChatMessage[];
  title: string;
  lastActivity: string;
  context: 'development' | 'implementation' | 'debugging' | 'architecture';
}

export function AIChat() {
  const [input, setInput] = useState("");
  const [chatContext, setChatContext] = useState<'development' | 'implementation' | 'debugging' | 'architecture'>('development');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch chat history
  const { data: chatSession, isLoading } = useQuery<ChatSession>({
    queryKey: ['/api/chat/session'],
    refetchInterval: 5000
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { message: string; context: string }) => {
      // Ensure data is properly structured
      const safeData = {
        message: (data?.message || "").trim(),
        context: data?.context || "general"
      };
      
      if (!safeData.message) {
        throw new Error("Messaggio vuoto");
      }
      
      return apiRequest({
        method: 'POST',
        url: '/api/chat/message',
        data: safeData
      });
    },
    onMutate: () => {
      setIsTyping(true);
    },
    onSuccess: () => {
      setInput("");
      queryClient.invalidateQueries({ queryKey: ['/api/chat/session'] });
      toast({
        title: "Messaggio inviato",
        description: "L'AI sta elaborando la tua richiesta..."
      });
    },
    onError: (error: any) => {
      console.error("Chat error details:", {
        error,
        message: error?.message,
        stack: error?.stack,
        name: error?.name,
        cause: error?.cause
      });
      toast({
        variant: "destructive",
        title: "Errore invio messaggio",
        description: error?.message || error?.toString() || "Errore sconosciuto nella chat"
      });
    },
    onSettled: () => {
      setIsTyping(false);
    }
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const messageText = (input || "").trim();
    if (!messageText) return;

    sendMessageMutation.mutate({
      message: messageText,
      context: chatContext || "general"
    });
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (chatSession?.messages && chatSession.messages.length > 0) {
      scrollToBottom();
    }
  }, [chatSession?.messages]);

  useEffect(() => {
    if (sendMessageMutation.isSuccess) {
      setTimeout(scrollToBottom, 100);
    }
  }, [sendMessageMutation.isSuccess]);

  const getContextIcon = (context: string) => {
    switch (context) {
      case 'implementation': return <Code className="h-4 w-4" />;
      case 'debugging': return <Zap className="h-4 w-4" />;
      case 'architecture': return <Lightbulb className="h-4 w-4" />;
      default: return <MessageCircle className="h-4 w-4" />;
    }
  };

  const getMessageTypeColor = (type?: string) => {
    switch (type) {
      case 'code_review': return 'bg-blue-100 text-blue-800';
      case 'implementation': return 'bg-green-100 text-green-800';
      case 'suggestion': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="h-[500px] flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Chat con AI Developer
          </CardTitle>
          <div className="flex items-center gap-2">
            <select
              value={chatContext}
              onChange={(e) => setChatContext(e.target.value as any)}
              className="text-sm border rounded px-2 py-1"
            >
              <option value="development">Sviluppo</option>
              <option value="implementation">Implementazione</option>
              <option value="debugging">Debug</option>
              <option value="architecture">Architettura</option>
            </select>
            {getContextIcon(chatContext)}
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          Discuti implementazioni, chiedi suggerimenti e collabora con l'AI sullo sviluppo
        </p>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col space-y-4">
        {/* Messages Area */}
        <ScrollArea className="flex-1 h-[400px] w-full border rounded p-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-muted-foreground">Caricamento chat...</div>
            </div>
          ) : (
            <div className="space-y-4">
            {(!chatSession?.messages || chatSession.messages.length === 0) ? (
              <div className="text-center text-muted-foreground py-8">
                <MessageCircle className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>Inizia una conversazione con l'AI Developer</p>
                <p className="text-sm mt-2">Chiedi aiuto, discuti implementazioni o fai domande tecniche</p>
              </div>
            ) : (
              (chatSession?.messages || []).map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start gap-3 ${
                      message.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {message.role === 'assistant' && (
                      <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                        <Bot className="h-4 w-4 text-white" />
                      </div>
                    )}
                    
                    <div
                      className={`max-w-[80%] rounded-lg p-3 overflow-hidden ${
                        message.role === 'user'
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {message.type && (
                          <Badge className={`text-xs ${getMessageTypeColor(message.type)}`}>
                            {message.type}
                          </Badge>
                        )}
                        <span className="text-xs opacity-70">
                          {new Date(message.timestamp).toLocaleTimeString('it-IT')}
                        </span>
                      </div>
                      
                      <div className="whitespace-pre-wrap text-sm leading-relaxed break-words">
                        {message.content}
                      </div>
                      
                      {message.metadata?.confidence && (
                        <div className="mt-2 text-xs opacity-70">
                          Confidence: {Math.round(message.metadata.confidence * 100)}%
                        </div>
                      )}
                      
                      {message.metadata?.files_mentioned && message.metadata.files_mentioned.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {message.metadata.files_mentioned.map((file, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {file}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>

                    {message.role === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                        <User className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                ))
              )}
              
              {isTyping && (
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Scroll anchor */}
              <div ref={messagesEndRef} className="h-1" />
            </div>
          )}
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t bg-white p-4">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Discuti ${chatContext} con l'AI...`}
              disabled={sendMessageMutation.isPending}
              className="flex-1"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(e);
                }
              }}
            />
            <Button 
              type="submit" 
              disabled={!input.trim() || sendMessageMutation.isPending}
              size="icon"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
          
          <div className="text-xs text-muted-foreground mt-2">
            Contesto: <strong>{chatContext}</strong> • 
            Premi Invio per inviare, Shift+Invio per nuova linea
          </div>
        </div>
      </CardContent>
    </Card>
  );
}