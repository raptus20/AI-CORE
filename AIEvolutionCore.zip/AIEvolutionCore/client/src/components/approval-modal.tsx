import React from "react";
import { CodeSuggestion } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface ApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  suggestion?: CodeSuggestion;
}

export function ApprovalModal({ 
  isOpen, 
  onClose, 
  onConfirm, 
  suggestion 
}: ApprovalModalProps) {
  if (!suggestion) return null;
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Confirm Code Implementation</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="mb-4">You are about to approve changes to <span className="font-medium">{suggestion.filePath}</span>. This will:</p>
          <ul className="list-disc pl-5 mb-4 text-sm">
            <li className="mb-2">Modify the code according to the suggested changes</li>
            <li className="mb-2">Add additional functionality or optimizations</li>
            <li>Deploy the new code to the live system</li>
          </ul>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800 mb-4">
            <div className="flex">
              <span className="mdi mdi-alert-circle text-lg mr-2"></span>
              <span>All code changes are logged and can be reverted if needed.</span>
            </div>
          </div>
        </div>
        <DialogFooter className="flex justify-end space-x-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="px-4 py-2 border border-neutral-200 rounded-md hover:bg-neutral-100"
          >
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
          >
            Confirm Implementation
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
