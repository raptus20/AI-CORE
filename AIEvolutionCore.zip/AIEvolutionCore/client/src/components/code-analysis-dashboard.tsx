import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from "@/lib/queryClient";
import { 
  Code, 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  Activity,
  Eye,
  GitBranch,
  Clock,
  Zap
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CodeMetrics {
  totalFiles: number;
  totalLines: number;
  codeQuality: number;
  testCoverage: number;
  maintainabilityIndex: number;
  complexityScore: number;
  lastAnalysis: string;
}

interface FileAnalysis {
  path: string;
  lines: number;
  quality: number;
  issues: Issue[];
  lastModified: string;
  complexity: 'low' | 'medium' | 'high';
  suggestions: string[];
}

interface Issue {
  type: 'warning' | 'error' | 'info' | 'suggestion';
  message: string;
  line?: number;
  severity: number;
  category: 'performance' | 'security' | 'maintainability' | 'style';
}

interface AnalysisReport {
  metrics: CodeMetrics;
  files: FileAnalysis[];
  trends: {
    qualityTrend: number;
    complexityTrend: number;
    issuesTrend: number;
  };
  recommendations: string[];
  timestamp: string;
}

export function CodeAnalysisDashboard() {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [analysisMode, setAnalysisMode] = useState<'quick' | 'deep' | 'continuous'>('quick');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch current analysis report
  const { data: report, isLoading } = useQuery<AnalysisReport>({
    queryKey: ['/api/analysis/report'],
    refetchInterval: 30000 // Auto-refresh every 30 seconds
  });

  // Trigger new analysis
  const analysisMutation = useMutation({
    mutationFn: async (mode: string) => {
      return apiRequest('/api/analysis/trigger', {
        method: 'POST',
        body: JSON.stringify({ mode })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/analysis/report'] });
      toast({
        title: "Analisi avviata",
        description: "Il sistema sta analizzando il codice..."
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Errore analisi",
        description: error.message || "Impossibile avviare l'analisi"
      });
    }
  });

  const getQualityColor = (quality: number) => {
    if (quality >= 85) return "text-green-600";
    if (quality >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getComplexityBadge = (complexity: string) => {
    const colors = {
      low: "bg-green-100 text-green-800",
      medium: "bg-yellow-100 text-yellow-800", 
      high: "bg-red-100 text-red-800"
    };
    return colors[complexity as keyof typeof colors];
  };

  const getIssueIcon = (type: string) => {
    switch (type) {
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'suggestion': return <Zap className="h-4 w-4 text-blue-500" />;
      default: return <Eye className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Code Analysis Dashboard</h2>
          <p className="text-muted-foreground">
            Monitoraggio intelligente della qualità del codice in tempo reale
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={analysisMode}
            onChange={(e) => setAnalysisMode(e.target.value as any)}
            className="text-sm border rounded px-3 py-2"
          >
            <option value="quick">Analisi Rapida</option>
            <option value="deep">Analisi Profonda</option>
            <option value="continuous">Monitoraggio Continuo</option>
          </select>
          <Button 
            onClick={() => analysisMutation.mutate(analysisMode)}
            disabled={analysisMutation.isPending}
            className="flex items-center gap-2"
          >
            <Activity className="h-4 w-4" />
            {analysisMutation.isPending ? 'Analizzando...' : 'Avvia Analisi'}
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Activity className="h-8 w-8 animate-spin mx-auto mb-2" />
            <p>Caricamento analisi...</p>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Metrics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">File Totali</p>
                    <p className="text-2xl font-bold">{report?.metrics.totalFiles || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Code className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">Linee di Codice</p>
                    <p className="text-2xl font-bold">{report?.metrics.totalLines?.toLocaleString() || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-purple-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">Qualità Codice</p>
                    <p className={`text-2xl font-bold ${getQualityColor(report?.metrics.codeQuality || 0)}`}>
                      {report?.metrics.codeQuality || 0}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-orange-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">Manutenibilità</p>
                    <p className={`text-2xl font-bold ${getQualityColor(report?.metrics.maintainabilityIndex || 0)}`}>
                      {report?.metrics.maintainabilityIndex || 0}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analysis */}
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Panoramica</TabsTrigger>
              <TabsTrigger value="files">File Analysis</TabsTrigger>
              <TabsTrigger value="issues">Problemi</TabsTrigger>
              <TabsTrigger value="recommendations">Raccomandazioni</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Trend di Qualità
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Qualità Codice</span>
                          <span className={getQualityColor(report?.metrics.codeQuality || 0)}>
                            {report?.metrics.codeQuality || 0}%
                          </span>
                        </div>
                        <Progress value={report?.metrics.codeQuality || 0} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Complessità</span>
                          <span className={getQualityColor(100 - (report?.metrics.complexityScore || 0))}>
                            {100 - (report?.metrics.complexityScore || 0)}%
                          </span>
                        </div>
                        <Progress value={100 - (report?.metrics.complexityScore || 0)} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Manutenibilità</span>
                          <span className={getQualityColor(report?.metrics.maintainabilityIndex || 0)}>
                            {report?.metrics.maintainabilityIndex || 0}%
                          </span>
                        </div>
                        <Progress value={report?.metrics.maintainabilityIndex || 0} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Ultima Analisi
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        {report?.timestamp ? new Date(report.timestamp).toLocaleString('it-IT') : 'Mai eseguita'}
                      </p>
                      <Separator />
                      <div className="space-y-1">
                        <p className="text-sm"><strong>File analizzati:</strong> {report?.files.length || 0}</p>
                        <p className="text-sm"><strong>Raccomandazioni:</strong> {report?.recommendations?.length || 0}</p>
                        <p className="text-sm"><strong>Modalità:</strong> {analysisMode}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="files" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Analisi per File</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      {report?.files.map((file, index) => (
                        <div
                          key={index}
                          className={`p-3 border rounded cursor-pointer transition-colors ${
                            selectedFile === file.path ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'
                          }`}
                          onClick={() => setSelectedFile(selectedFile === file.path ? null : file.path)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <FileText className="h-4 w-4" />
                              <span className="font-medium text-sm">{file.path}</span>
                              <Badge className={getComplexityBadge(file.complexity)}>
                                {file.complexity}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`text-sm font-medium ${getQualityColor(file.quality)}`}>
                                {file.quality}%
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {file.lines} righe
                              </span>
                            </div>
                          </div>
                          
                          {selectedFile === file.path && (
                            <div className="mt-3 pt-3 border-t space-y-2">
                              {file.issues.length > 0 && (
                                <div>
                                  <p className="text-sm font-medium mb-1">Problemi trovati:</p>
                                  <div className="space-y-1">
                                    {file.issues.slice(0, 3).map((issue, idx) => (
                                      <div key={idx} className="flex items-center gap-2 text-sm">
                                        {getIssueIcon(issue.type)}
                                        <span>{issue.message}</span>
                                        {issue.line && (
                                          <Badge variant="outline" className="text-xs">
                                            Riga {issue.line}
                                          </Badge>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              {file.suggestions.length > 0 && (
                                <div>
                                  <p className="text-sm font-medium mb-1">Suggerimenti:</p>
                                  <div className="space-y-1">
                                    {file.suggestions.slice(0, 2).map((suggestion, idx) => (
                                      <p key={idx} className="text-sm text-muted-foreground">
                                        • {suggestion}
                                      </p>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="issues" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Problemi Rilevati</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    {report?.files.flatMap(file => 
                      file.issues.map((issue, idx) => (
                        <div key={`${file.path}-${idx}`} className="p-3 border rounded mb-2">
                          <div className="flex items-start gap-2">
                            {getIssueIcon(issue.type)}
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-sm">{file.path}</span>
                                {issue.line && (
                                  <Badge variant="outline" className="text-xs">
                                    Riga {issue.line}
                                  </Badge>
                                )}
                                <Badge className={
                                  issue.type === 'error' ? 'bg-red-100 text-red-800' :
                                  issue.type === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-blue-100 text-blue-800'
                                }>
                                  {issue.type}
                                </Badge>
                              </div>
                              <p className="text-sm">{issue.message}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                Categoria: {issue.category} • Severità: {issue.severity}/10
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="recommendations" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Raccomandazioni AI</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {report?.recommendations?.map((rec, index) => (
                      <div key={index} className="p-3 bg-blue-50 border-l-4 border-blue-400 rounded">
                        <div className="flex items-start gap-2">
                          <Zap className="h-4 w-4 text-blue-600 mt-0.5" />
                          <p className="text-sm">{rec}</p>
                        </div>
                      </div>
                    )) || (
                      <p className="text-muted-foreground text-center py-8">
                        Esegui un'analisi per ricevere raccomandazioni personalizzate
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}