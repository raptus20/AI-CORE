import React, { useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface CodeEditorProps extends React.HTMLAttributes<HTMLPreElement> {
  language?: string;
  value: string;
  readOnly?: boolean;
  onChange?: (value: string) => void;
}

export function CodeEditor({
  language = "javascript",
  value,
  readOnly = true,
  onChange,
  className,
  ...props
}: CodeEditorProps) {
  const preRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    if (preRef.current) {
      preRef.current.textContent = value;
    }
  }, [value]);

  const handleInput = (e: React.FormEvent<HTMLPreElement>) => {
    if (readOnly) return;
    if (onChange) {
      onChange(e.currentTarget.textContent || "");
    }
  };

  return (
    <div className="rounded-lg border bg-neutral-50 text-sm w-full overflow-hidden">
      <div className="bg-neutral-100 px-4 py-2 text-xs font-medium text-neutral-500 border-b">
        {language.toUpperCase()}
      </div>
      <pre
        ref={preRef}
        className={cn(
          "font-mono p-4 text-sm text-neutral-800 overflow-auto max-h-[300px]",
          readOnly ? "opacity-90" : "outline-none",
          className
        )}
        contentEditable={!readOnly}
        suppressContentEditableWarning={!readOnly}
        onInput={handleInput}
        {...props}
      >
        {value}
      </pre>
    </div>
  );
}
