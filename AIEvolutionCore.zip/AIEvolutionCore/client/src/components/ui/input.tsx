// src/components/ui/input.tsx

import React from "react";

// Classe utilità (opzionale), altrimenti rimuovi "cn(...)"
function cn(...classes: string[]) {
  return classes.join(" ");
}

const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type = "text", ...props }, ref) => {
    return (
      <input
        type={type}
        ref={ref}
        className={cn(
          "flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
          className || ""
        )}
        {...props}
      />
    );
  }
);

Input.displayName = "Input";

export { Input }; // <-- ESPORTAZIONE CORRETTA