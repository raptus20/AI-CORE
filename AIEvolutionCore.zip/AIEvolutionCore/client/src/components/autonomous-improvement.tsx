import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Brain, Zap } from "lucide-react";
import { CodeSuggestion } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function AutonomousImprovement() {
  const [isRunning, setIsRunning] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  interface AutoImprovementResponse {
    message: string;
    suggestionCount: number;
    suggestions: CodeSuggestion[];
  }

  const triggerAutonomous = useMutation({
    mutationFn: async () => {
      return apiRequest<AutoImprovementResponse>({
        method: "POST",
        url: "/api/autonomous/improve",
      });
    },
    onMutate: () => {
      setIsRunning(true);
    },
    onSuccess: (data) => {
      toast({
        title: "Autonomous improvement complete",
        description: `Generated ${data?.suggestionCount || 0} suggestions for the codebase.`,
        variant: "default",
      });
      
      // Invalidate the suggestions cache
      queryClient.invalidateQueries({ queryKey: ['/api/suggestions'] });
      
      // Invalidate activity logs
      queryClient.invalidateQueries({ queryKey: ['/api/activity'] });
    },
    onError: (error) => {
      toast({
        title: "Autonomous improvement failed",
        description: "There was an error running the autonomous improvement process.",
        variant: "destructive",
      });
      console.error("Error triggering autonomous improvement:", error);
    },
    onSettled: () => {
      setIsRunning(false);
    }
  });

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-xl font-bold">
          <Brain className="mr-2 h-5 w-5 text-indigo-500" />
          AI Autonomy System
        </CardTitle>
        <CardDescription>
          Allow the AI to autonomously analyze and improve its own codebase
        </CardDescription>
      </CardHeader>
      <CardContent className="text-sm">
        <div className="space-y-4">
          <div className="flex items-start space-x-4">
            <div className="min-w-0 flex-1">
              <p className="text-sm text-muted-foreground mb-2">
                The autonomous improvement system uses advanced AI to scan the codebase, identify areas for enhancement, and generate optimized code suggestions.
              </p>
              <div className="flex flex-wrap gap-2 mt-3">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  Self-Improving
                </Badge>
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  Code Analysis
                </Badge>
                <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                  Performance Optimization
                </Badge>
              </div>
            </div>
          </div>
          <div className="rounded-md bg-blue-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Zap className="h-5 w-5 text-blue-400" aria-hidden="true" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">Safety Protocols</h3>
                <div className="mt-2 text-sm text-blue-700">
                  <ul className="list-disc space-y-1 pl-5">
                    <li>All suggestions require human approval before implementation</li>
                    <li>Changes are tested in a sandbox environment</li>
                    <li>Version control ensures all modifications can be rolled back</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button 
          onClick={() => triggerAutonomous.mutate()}
          className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white"
          disabled={isRunning || triggerAutonomous.isPending}
        >
          {(isRunning || triggerAutonomous.isPending) ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              AI Analyzing Codebase...
            </>
          ) : (
            <>
              <Brain className="mr-2 h-4 w-4" />
              Trigger Autonomous Improvement
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}