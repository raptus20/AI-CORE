import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
});

// Code suggestions table
export const codeSuggestions = pgTable("code_suggestions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  filePath: text("file_path").notNull(),
  currentCode: text("current_code").notNull(),
  suggestedCode: text("suggested_code").notNull(),
  reasoning: text("reasoning").notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, rejected, testing
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  expectedImprovement: jsonb("expected_improvement").notNull(),
});

export const insertCodeSuggestionSchema = createInsertSchema(codeSuggestions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Sandbox tests table
export const sandboxTests = pgTable("sandbox_tests", {
  id: serial("id").primaryKey(),
  testId: text("test_id").notNull().unique(),
  suggestionId: integer("suggestion_id").references(() => codeSuggestions.id),
  moduleName: text("module_name").notNull(),
  testCode: text("test_code"), // The actual code to test
  status: text("status").notNull().default("pending"), // pending, running, completed
  result: text("result"), // passed, failed
  logs: text("logs"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSandboxTestSchema = createInsertSchema(sandboxTests).omit({
  id: true,
  createdAt: true,
});

// Activity log table
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(), // suggestion, approval, rejection, test
  description: text("description").notNull(),
  relatedEntityId: integer("related_entity_id"),
  relatedEntityType: text("related_entity_type"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

// System health metrics
export const systemMetrics = pgTable("system_metrics", {
  id: serial("id").primaryKey(),
  memoryUsage: integer("memory_usage").notNull(),
  cpuLoad: integer("cpu_load").notNull(),
  storage: integer("storage").notNull(),
  safetyProtocols: boolean("safety_protocols").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSystemMetricsSchema = createInsertSchema(systemMetrics).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCodeSuggestion = z.infer<typeof insertCodeSuggestionSchema>;
export type CodeSuggestion = typeof codeSuggestions.$inferSelect;

export type InsertSandboxTest = z.infer<typeof insertSandboxTestSchema>;
export type SandboxTest = typeof sandboxTests.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

export type InsertSystemMetrics = z.infer<typeof insertSystemMetricsSchema>;
export type SystemMetrics = typeof systemMetrics.$inferSelect;

// Chat system schema
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull(),
  content: text("content").notNull(),
  role: varchar("role", { length: 20 }).notNull(), // 'user' | 'assistant'
  messageType: varchar("message_type", { length: 50 }).default("general"), // 'general' | 'code_review' | 'implementation' | 'suggestion'
  context: varchar("context", { length: 50 }).default("development"), // 'development' | 'implementation' | 'debugging' | 'architecture'
  metadata: json("metadata"), // confidence, files_mentioned, etc.
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const chatSessions = pgTable("chat_sessions", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  context: varchar("context", { length: 50 }).notNull(),
  lastActivity: timestamp("last_activity").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).omit({
  id: true,
  createdAt: true,
  lastActivity: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
export type ChatSession = typeof chatSessions.$inferSelect;
