import * as fs from 'fs';
import * as path from 'path';
import { storage } from '../storage';

class VersionControl {
  private backupDir: string;
  
  constructor() {
    // Create a backups directory in the project root
    this.backupDir = path.resolve(process.cwd(), 'backups');
    
    // Ensure the directory exists
    if (!fs.existsSync(this.backupDir)) {
      fs.mkdirSync(this.backupDir, { recursive: true });
    }
  }
  
  /**
   * Apply changes to a file with versioning
   */
  async applyChanges(filePath: string, originalCode: string, newCode: string): Promise<boolean> {
    try {
      const fullPath = path.resolve(process.cwd(), filePath);
      
      // Check if file exists
      if (!fs.existsSync(fullPath)) {
        console.error(`File does not exist: ${fullPath}`);
        return false;
      }
      
      // Create a backup before making changes
      const backupFilePath = this.createBackup(filePath, originalCode);
      
      // Write the new code to the file
      fs.writeFileSync(fullPath, newCode, 'utf8');
      
      // Log the change
      await storage.createActivityLog({
        eventType: 'code_change',
        description: `Applied changes to file: ${filePath}`,
        relatedEntityType: 'file',
        relatedEntityId: null
      });
      
      console.log(`Successfully applied changes to ${filePath}. Backup created at ${backupFilePath}`);
      return true;
    } catch (error) {
      console.error('Error applying changes:', error);
      return false;
    }
  }
  
  /**
   * Create a backup of a file
   */
  private createBackup(filePath: string, content: string): string {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = path.basename(filePath);
    const backupFileName = `${fileName}.${timestamp}.bak`;
    const backupFilePath = path.join(this.backupDir, backupFileName);
    
    fs.writeFileSync(backupFilePath, content, 'utf8');
    
    return backupFilePath;
  }
  
  /**
   * Restore a file from backup
   */
  async restoreFromBackup(filePath: string, backupTimestamp: string): Promise<boolean> {
    try {
      const fileName = path.basename(filePath);
      const backupFileName = `${fileName}.${backupTimestamp}.bak`;
      const backupFilePath = path.join(this.backupDir, backupFileName);
      
      // Check if backup exists
      if (!fs.existsSync(backupFilePath)) {
        console.error(`Backup does not exist: ${backupFilePath}`);
        return false;
      }
      
      // Read the backup content
      const backupContent = fs.readFileSync(backupFilePath, 'utf8');
      
      // Write the backup content to the original file
      const fullPath = path.resolve(process.cwd(), filePath);
      fs.writeFileSync(fullPath, backupContent, 'utf8');
      
      // Log the restoration
      await storage.createActivityLog({
        eventType: 'code_restore',
        description: `Restored file from backup: ${filePath}`,
        relatedEntityType: 'file',
        relatedEntityId: null
      });
      
      console.log(`Successfully restored ${filePath} from backup ${backupFileName}`);
      return true;
    } catch (error) {
      console.error('Error restoring from backup:', error);
      return false;
    }
  }
  
  /**
   * List all backups for a file
   */
  listBackups(filePath: string): string[] {
    const fileName = path.basename(filePath);
    const backups = fs.readdirSync(this.backupDir)
      .filter(file => file.startsWith(`${fileName}.`) && file.endsWith('.bak'));
    
    return backups.map(backup => {
      const timestamp = backup.substring(fileName.length + 1, backup.length - 4);
      return timestamp;
    });
  }
}

// Create and export a singleton instance
export const versionControl = new VersionControl();
