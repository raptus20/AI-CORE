import { SandboxTest } from "@shared/schema";
import { storage } from "../storage";
import * as vm from "vm";

class SandboxEnvironment {
  /**
   * Run a test in the sandbox environment
   */
  async runTest(test: SandboxTest): Promise<void> {
    // Mark test as running
    await storage.updateSandboxTest(test.id, { status: "running" });
    
    try {
      // Get the code to test
      let code = "";
      let logs = "";
      
      if (test.suggestionId) {
        const suggestion = await storage.getCodeSuggestion(test.suggestionId);
        if (!suggestion) {
          throw new Error("Suggestion not found");
        }
        code = suggestion.suggestedCode;
      } else if (test.testCode) {
        // Use the test code directly
        code = test.testCode;
      } else {
        throw new Error("No code to test");
      }
      
      // Execute the code in a sandbox
      const result = await this.executeCodeInSandbox(code);
      logs = result.logs;
      
      // Update the test with results
      await storage.updateSandboxTest(test.id, {
        status: "completed",
        result: result.success ? "passed" : "failed",
        logs
      });
      
      // If test is associated with a suggestion and passed, mark it ready for review
      if (test.suggestionId && result.success) {
        const suggestion = await storage.getCodeSuggestion(test.suggestionId);
        if (suggestion && suggestion.status === "testing") {
          await storage.updateCodeSuggestionStatus(test.suggestionId, "pending");
        }
      }
    } catch (error) {
      console.error("Error running sandbox test:", error);
      
      // Update the test as failed with error logs
      await storage.updateSandboxTest(test.id, {
        status: "completed",
        result: "failed",
        logs: `Error: ${error instanceof Error ? error.message : String(error)}`
      });
    }
  }
  
  /**
   * Execute code in a sandboxed environment
   */
  private async executeCodeInSandbox(code: string): Promise<{ success: boolean; logs: string }> {
    return new Promise((resolve) => {
      const logs: string[] = [];
      
      // Create a simple console mock that captures logs
      const consoleMock = {
        log: (...args: any[]) => {
          logs.push(args.map(arg => String(arg)).join(" "));
        },
        error: (...args: any[]) => {
          logs.push(`ERROR: ${args.map(arg => String(arg)).join(" ")}`);
        },
        warn: (...args: any[]) => {
          logs.push(`WARN: ${args.map(arg => String(arg)).join(" ")}`);
        }
      };
      
      // Create a context for the VM
      const context = {
        console: consoleMock,
        setTimeout: (cb: Function, ms: number) => setTimeout(cb, ms),
        clearTimeout: (id: NodeJS.Timeout) => clearTimeout(id)
      };
      
      try {
        // Wrap the code in a function to catch any exceptions
        const wrappedCode = `
          (function() {
            try {
              ${code}
              return { success: true };
            } catch (error) {
              console.error("Execution error:", error.message);
              return { success: false, error: error.message };
            }
          })();
        `;
        
        // Execute the code in a VM context
        const script = new vm.Script(wrappedCode);
        
        const vmContext = vm.createContext(context);
        // Set a timeout for execution
        let timeoutId: NodeJS.Timeout | null = setTimeout(() => {
          timeoutId = null;
          logs.push('SANDBOX ERROR: Script execution timed out after 5000ms');
          resolve({
            success: false,
            logs: logs.join('\n')
          });
        }, 5000);
        
        try {
          const result = script.runInContext(vmContext);
          
          if (timeoutId) {
            clearTimeout(timeoutId);
            timeoutId = null;
            
            resolve({
              success: result?.success === true,
              logs: logs.join('\n')
            });
          }
        } catch (error) {
          logs.push(`SANDBOX ERROR: ${error instanceof Error ? error.message : String(error)}`);
          resolve({
            success: false,
            logs: logs.join('\n')
          });
        }
      } catch (error) {
        logs.push(`SANDBOX ERROR: ${error instanceof Error ? error.message : String(error)}`);
        resolve({
          success: false,
          logs: logs.join('\n')
        });
      }
    });
  }
}

// Create and export a singleton instance
export const sandboxEnvironment = new SandboxEnvironment();
