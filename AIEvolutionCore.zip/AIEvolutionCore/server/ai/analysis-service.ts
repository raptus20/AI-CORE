
import { multiProviderAIService } from "./multi-provider-service";
import fs from "fs";
import path from "path";

interface FileAnalysis {
  path: string;
  quality: number;
  complexity: number;
  issues: string[];
  suggestions: string[];
  metrics: {
    lines: number;
    functions: number;
    complexity: number;
    maintainability: number;
  };
}

interface AnalysisReport {
  metrics: {
    overallQuality: number;
    totalFiles: number;
    totalIssues: number;
    suggestions: number;
  };
  files: FileAnalysis[];
  timestamp: string;
}

export class AnalysisService {
  private analysisCache = new Map<string, {result: FileAnalysis, timestamp: number}>();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  constructor() {
    console.log("Analysis service initialized with multi-provider AI support");
  }

  async performAnalysis(mode: 'quick' | 'deep' | 'continuous'): Promise<AnalysisReport> {
    const files = this.getProjectFiles();
    const fileAnalyses = await Promise.all(files.map(async filePath => {
      const cacheKey = `${filePath}:${mode}`;
      const cached = this.analysisCache.get(cacheKey);
      
      if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
        return cached.result;
      }
      
      const result = await this.analyzeFile(filePath, mode);
      this.analysisCache.set(cacheKey, {result, timestamp: Date.now()});
      return result;
    }));
    
    const metrics = this.calculateMetrics(fileAnalyses);
    return {
      metrics,
      files: fileAnalyses,
      timestamp: new Date().toISOString()
    };
  }

  private async analyzeFile(filePath: string, mode: string): Promise<FileAnalysis> {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      
      const prompt = this.buildAnalysisPrompt(content, mode);
      
      try {
        // Use multi-provider AI service with automatic fallback
        const response = await multiProviderAIService.generateResponse(prompt, {
          temperature: 0.1,
          maxTokens: 1000
        });

        const result = this.parseAnalysisResponse(response, filePath);
        return result;
      } catch (error) {
        console.error(`API error for ${filePath}:`, error);
        
        // Fallback to static analysis
        return this.performStaticAnalysis(filePath, content);
      }
    } catch (error) {
      console.error(`Error analyzing file ${filePath}:`, error);
      return this.createErrorAnalysis(filePath);
    }
  }

  private buildAnalysisPrompt(content: string, mode: string): string {
    return `Analyze this code file (mode: ${mode}) and provide a JSON response with:
    {
      "quality": number (0-100),
      "complexity": number (0-100),
      "issues": string[],
      "suggestions": string[],
      "metrics": {
        "lines": number,
        "functions": number,
        "complexity": number,
        "maintainability": number (0-100)
      }
    }
    
    Code:
    ${content.slice(0, 3000)}`;
  }

  private parseAnalysisResponse(response: string, filePath: string): FileAnalysis {
    try {
      const parsed = JSON.parse(response);
      return {
        path: filePath,
        quality: parsed.quality || 85,
        complexity: parsed.complexity || 50,
        issues: parsed.issues || [],
        suggestions: parsed.suggestions || [],
        metrics: {
          lines: parsed.metrics?.lines || 0,
          functions: parsed.metrics?.functions || 0,
          complexity: parsed.metrics?.complexity || 50,
          maintainability: parsed.metrics?.maintainability || 85
        }
      };
    } catch (error) {
      console.error(`Error parsing analysis response for ${filePath}:`, error);
      return this.performStaticAnalysis(filePath, '');
    }
  }

  private performStaticAnalysis(filePath: string, content: string): FileAnalysis {
    // Advanced static analysis without external APIs
    const lines = content.split('\n').length;
    const functions = this.countFunctions(content);
    const complexity = this.calculateComplexity(content);
    const issues = this.detectIssues(content, filePath);
    const suggestions = this.generateSuggestions(content, filePath);
    
    const quality = this.calculateQuality(issues, complexity, lines);
    const maintainability = this.calculateMaintainability(complexity, lines, functions);

    return {
      path: filePath,
      quality,
      complexity,
      issues,
      suggestions,
      metrics: {
        lines,
        functions,
        complexity,
        maintainability
      }
    };
  }

  private countFunctions(content: string): number {
    const functionRegex = /(?:function\s+\w+|const\s+\w+\s*=\s*(?:async\s+)?\(|(?:async\s+)?function\s*\(|export\s+(?:async\s+)?function)/g;
    return (content.match(functionRegex) || []).length;
  }

  private calculateComplexity(content: string): number {
    // Cyclomatic complexity approximation
    const complexityKeywords = ['if', 'else', 'for', 'while', 'switch', 'case', 'catch'];
    const operatorKeywords = ['&&', '||'];
    let complexity = 1; // Base complexity
    
    // Count word boundary keywords
    for (const keyword of complexityKeywords) {
      if (keyword) {
        const regex = new RegExp(`\\b${keyword}\\b`, 'g');
        const matches = content.match(regex);
        if (matches) {
          complexity += matches.length;
        }
      }
    }
    
    // Count operators (escaped for regex)
    for (const operator of operatorKeywords) {
      const escapedOperator = operator.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(escapedOperator, 'g');
      const matches = content.match(regex);
      if (matches) {
        complexity += matches.length;
      }
    }
    
    // Count ternary operators
    const ternaryMatches = content.match(/\?/g);
    if (ternaryMatches) {
      complexity += ternaryMatches.length;
    }
    
    return Math.min(complexity, 100);
  }

  private detectIssues(content: string, filePath: string): string[] {
    const issues: string[] = [];
    
    // Check for long functions
    const functionBlocks = content.split(/(?:function\s+\w+|const\s+\w+\s*=\s*(?:async\s+)?\()/);
    if (functionBlocks.some(block => block.split('\n').length > 50)) {
      issues.push("Funzioni troppo lunghe (>50 righe)");
    }
    
    // Check for missing error handling
    if (content.includes('async') && !content.includes('try') && !content.includes('catch')) {
      issues.push("Manca gestione errori per funzioni async");
    }
    
    // Check for hardcoded values
    if (content.match(/['"][^'"]*(?:localhost|127\.0\.0\.1|password|secret)[^'"]*['"]/i)) {
      issues.push("Possibili valori hardcoded sensibili");
    }
    
    // Check for console.log in production files
    if (content.includes('console.log') && !filePath.includes('test')) {
      issues.push("Console.log presente in codice production");
    }
    
    return issues;
  }

  private generateSuggestions(content: string, filePath: string): string[] {
    const suggestions: string[] = [];
    
    // TypeScript suggestions
    if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
      if (!content.includes('interface') && !content.includes('type') && content.length > 100) {
        suggestions.push("Considera l'aggiunta di tipi TypeScript");
      }
    }
    
    // React suggestions
    if (filePath.endsWith('.tsx') || filePath.endsWith('.jsx')) {
      if (!content.includes('useCallback') && content.includes('function')) {
        suggestions.push("Considera useCallback per ottimizzare le performance");
      }
      if (!content.includes('memo') && content.includes('export')) {
        suggestions.push("Considera React.memo per componenti che non cambiano spesso");
      }
    }
    
    // General suggestions
    if (content.length > 500 && !content.includes('//')) {
      suggestions.push("Aggiungi commenti per migliorare la leggibilità");
    }
    
    return suggestions;
  }

  private calculateQuality(issues: string[], complexity: number, lines: number): number {
    let quality = 100;
    
    // Penalize for issues
    quality -= issues.length * 10;
    
    // Penalize for high complexity
    if (complexity > 20) quality -= (complexity - 20) * 2;
    
    // Penalize for very long files
    if (lines > 300) quality -= (lines - 300) * 0.1;
    
    return Math.max(Math.min(quality, 100), 0);
  }

  private calculateMaintainability(complexity: number, lines: number, functions: number): number {
    let maintainability = 100;
    
    // Factor in complexity
    maintainability -= complexity * 0.5;
    
    // Factor in file size
    if (lines > 200) maintainability -= (lines - 200) * 0.2;
    
    // Factor in function density
    const functionDensity = functions / (lines || 1) * 100;
    if (functionDensity < 2) maintainability -= 10; // Too few functions
    if (functionDensity > 20) maintainability -= 10; // Too many functions
    
    return Math.max(Math.min(maintainability, 100), 0);
  }

  private createErrorAnalysis(filePath: string): FileAnalysis {
    return {
      path: filePath,
      quality: 0,
      complexity: 0,
      issues: ["Unable to analyze file"],
      suggestions: ["Check file accessibility and format"],
      metrics: {
        lines: 0,
        functions: 0,
        complexity: 0,
        maintainability: 0
      }
    };
  }

  private getProjectFiles(): string[] {
    const files: string[] = [];
    const ignoredPaths = ['node_modules', '.git', 'dist', 'build', '.next'];
    
    const scanDirectory = (dir: string) => {
      try {
        const entries = fs.readdirSync(dir);
        for (const entry of entries) {
          const fullPath = path.join(dir, entry);
          const stat = fs.statSync(fullPath);
          
          if (stat.isDirectory() && !ignoredPaths.includes(entry)) {
            scanDirectory(fullPath);
          } else if (stat.isFile() && this.isCodeFile(entry)) {
            files.push(fullPath);
          }
        }
      } catch (error) {
        console.error(`Error scanning directory ${dir}:`, error);
      }
    };

    scanDirectory(process.cwd());
    return files.slice(0, 50); // Limit to 50 files for performance
  }

  private isCodeFile(filename: string): boolean {
    const codeExtensions = ['.js', '.ts', '.tsx', '.jsx', '.vue', '.py', '.java', '.cpp', '.c', '.php'];
    return codeExtensions.some(ext => filename.endsWith(ext));
  }

  private calculateMetrics(analyses: FileAnalysis[]) {
    if (analyses.length === 0) {
      return {
        overallQuality: 0,
        totalFiles: 0,
        totalIssues: 0,
        suggestions: 0
      };
    }

    const totalQuality = analyses.reduce((sum, analysis) => sum + analysis.quality, 0);
    const totalIssues = analyses.reduce((sum, analysis) => sum + analysis.issues.length, 0);
    const totalSuggestions = analyses.reduce((sum, analysis) => sum + analysis.suggestions.length, 0);

    return {
      overallQuality: Math.round(totalQuality / analyses.length),
      totalFiles: analyses.length,
      totalIssues,
      suggestions: totalSuggestions
    };
  }
}

export const analysisService = new AnalysisService();
