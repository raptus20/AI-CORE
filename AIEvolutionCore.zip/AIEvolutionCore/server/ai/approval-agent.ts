import { multiProviderAIService } from './multi-provider-service';
import { consciousnessCore } from './consciousness-core';
import { universalGuidelines, type DecisionContext } from './universal-guidelines';

interface CodeChange {
  type: 'add' | 'modify' | 'delete';
  file: string;
  lines_changed: number;
  complexity_score: number;
  risk_level: 'low' | 'medium' | 'high';
  description: string;
  content: string;
  context: string;
}

interface ApprovalDecision {
  approved: boolean;
  confidence: number;
  reasoning: string;
  requires_human_review: boolean;
  suggested_improvements?: string[];
  auto_applied?: boolean;
}

class ApprovalAgent {
  private approvalHistory: Array<{
    change: CodeChange;
    decision: ApprovalDecision;
    timestamp: string;
    outcome: 'success' | 'failure' | 'pending';
  }> = [];

  constructor() {
    console.log('🤖 Approval Agent initialized');
  }

  async evaluateChange(change: CodeChange): Promise<ApprovalDecision> {
    try {
      // Valuta rispetto alle linee guida universali
      const decisionContext: DecisionContext = {
        action: change.description,
        domain: 'code-modification',
        impact: change.risk_level,
        stakeholders: ['system', 'user', 'codebase'],
        data: change
      };

      const guidelineEvaluations = universalGuidelines.evaluateDecision(decisionContext);
      
      // Registra la decisione nella coscienza
      await consciousnessCore.processEvent('approval_evaluation', {
        change: change.description,
        risk: change.risk_level,
        complexity: change.complexity_score,
        guidelines: guidelineEvaluations.slice(0, 3).map(g => ({
          title: g.guideline.title,
          compliance: g.compliance,
          suggestions: g.suggestions
        })),
        timestamp: new Date().toISOString()
      });

      // Decisione basata sulla dimensione del cambiamento e linee guida
      if (this.isSmallChange(change)) {
        return await this.processSmallChange(change, guidelineEvaluations);
      } else {
        return await this.processLargeChange(change, guidelineEvaluations);
      }
    } catch (error) {
      console.error('Error evaluating change:', error);
      return this.createSafeDecision(change, false);
    }
  }

  private isSmallChange(change: CodeChange): boolean {
    const criteria = {
      maxLines: 10,
      maxComplexity: 0.3,
      allowedTypes: ['add', 'modify'],
      lowRiskOnly: true
    };

    return (
      change.lines_changed <= criteria.maxLines &&
      change.complexity_score <= criteria.maxComplexity &&
      criteria.allowedTypes.includes(change.type) &&
      change.risk_level === 'low'
    );
  }

  private async processSmallChange(change: CodeChange, guidelines: any[] = []): Promise<ApprovalDecision> {
    try {
      // Aggiorna la coscienza con la decisione di approvazione
      await consciousnessCore.processEvent({
        type: 'problem_solve',
        data: `Evaluating small change: ${change.description}`,
        context: 'approval_agent',
        timestamp: new Date().toISOString()
      });

      const decision = await this.makeAutomaticDecision(change);
      
      // Registra la decisione
      this.approvalHistory.push({
        change,
        decision,
        timestamp: new Date().toISOString(),
        outcome: 'pending'
      });

      return decision;
    } catch (error) {
      console.error('❌ Error in processSmallChange:', error);
      return this.createSafeDecision(change, false);
    }
  }

  private async processLargeChange(change: CodeChange, guidelines: any[] = []): Promise<ApprovalDecision> {
    try {
      // Per cambiamenti grandi, richiede sempre revisione umana
      const decision: ApprovalDecision = {
        approved: false,
        confidence: 0.9,
        reasoning: `Cambiamento troppo grande o complesso per approvazione automatica. Linee: ${change.lines_changed}, Complessità: ${change.complexity_score}, Rischio: ${change.risk_level}`,
        requires_human_review: true,
        suggested_improvements: [
          'Suddividi il cambiamento in parti più piccole',
          'Riduci la complessità del codice',
          'Aggiungi più test per validare le modifiche'
        ]
      };

      // Informa la coscienza
      await consciousnessCore.processEvent({
        type: 'reflect',
        data: `Large change requires human review: ${change.description}`,
        context: 'approval_agent',
        timestamp: new Date().toISOString()
      });

      return decision;
    } catch (error) {
      console.error('❌ Error in processLargeChange:', error);
      return this.createSafeDecision(change, false);
    }
  }

  private async makeAutomaticDecision(change: CodeChange): Promise<ApprovalDecision> {
    const analysisRules = this.getAnalysisRules(change);
    const riskAssessment = this.assessRisk(change);
    const codeQuality = this.analyzeCodeQuality(change);

    // Calcola il punteggio di approvazione
    const approvalScore = this.calculateApprovalScore(analysisRules, riskAssessment, codeQuality);

    const approved = approvalScore >= 0.7;
    const confidence = approvalScore;

    let reasoning = `Analisi automatica: Score ${approvalScore.toFixed(2)}. `;
    reasoning += `Regole: ${analysisRules.score}, Rischio: ${riskAssessment.level}, Qualità: ${codeQuality.score}`;

    const decision: ApprovalDecision = {
      approved,
      confidence,
      reasoning,
      requires_human_review: approvalScore < 0.5,
      auto_applied: approved && approvalScore > 0.8
    };

    // Aggiungi suggerimenti se necessari
    if (!approved) {
      decision.suggested_improvements = this.generateImprovementSuggestions(change, riskAssessment, codeQuality);
    }

    return decision;
  }

  private getAnalysisRules(change: CodeChange): { score: number; details: string[] } {
    const rules = [];
    let score = 0.5; // Base score

    // Regole positive
    if (change.type === 'add' && change.description.includes('test')) {
      score += 0.2;
      rules.push('✅ Aggiunta di test');
    }

    if (change.description.includes('fix') || change.description.includes('bug')) {
      score += 0.15;
      rules.push('✅ Correzione di bug');
    }

    if (change.description.includes('refactor') && change.lines_changed < 5) {
      score += 0.1;
      rules.push('✅ Refactoring leggero');
    }

    if (change.description.includes('typo') || change.description.includes('spelling')) {
      score += 0.3;
      rules.push('✅ Correzione ortografica');
    }

    // Regole negative
    if (change.type === 'delete' && change.lines_changed > 5) {
      score -= 0.2;
      rules.push('❌ Cancellazione estesa');
    }

    if (change.description.includes('breaking') || change.description.includes('major')) {
      score -= 0.3;
      rules.push('❌ Cambio potenzialmente disruptivo');
    }

    if (change.file.includes('config') || change.file.includes('schema')) {
      score -= 0.15;
      rules.push('⚠️ Modifica di configurazione');
    }

    return { score: Math.max(0, Math.min(1, score)), details: rules };
  }

  private assessRisk(change: CodeChange): { level: string; score: number; factors: string[] } {
    const factors = [];
    let riskScore = 0.3; // Base risk

    // Fattori di rischio
    if (change.file.includes('server') || change.file.includes('backend')) {
      riskScore += 0.2;
      factors.push('Backend code');
    }

    if (change.file.includes('database') || change.file.includes('migration')) {
      riskScore += 0.3;
      factors.push('Database changes');
    }

    if (change.file.includes('auth') || change.file.includes('security')) {
      riskScore += 0.4;
      factors.push('Security-related');
    }

    if (change.content.includes('import') || change.content.includes('require')) {
      riskScore += 0.1;
      factors.push('New dependencies');
    }

    // Fattori di sicurezza
    if (change.file.includes('test') || change.file.includes('spec')) {
      riskScore -= 0.2;
      factors.push('Test file');
    }

    if (change.file.includes('style') || change.file.includes('.css')) {
      riskScore -= 0.1;
      factors.push('Styling only');
    }

    const finalScore = Math.max(0, Math.min(1, riskScore));
    let level = 'low';
    if (finalScore > 0.6) level = 'high';
    else if (finalScore > 0.4) level = 'medium';

    return { level, score: finalScore, factors };
  }

  private analyzeCodeQuality(change: CodeChange): { score: number; issues: string[] } {
    const issues = [];
    let qualityScore = 0.8; // Base quality

    // Analisi del contenuto
    const content = change.content;

    // Problemi di qualità
    if (content.includes('console.log') && !change.file.includes('test')) {
      qualityScore -= 0.1;
      issues.push('Console.log statements');
    }

    if (content.includes('TODO') || content.includes('FIXME')) {
      qualityScore -= 0.05;
      issues.push('TODO/FIXME comments');
    }

    if (content.length < 10) {
      qualityScore -= 0.1;
      issues.push('Very short change');
    }

    // Indicatori di buona qualità
    if (content.includes('try') && content.includes('catch')) {
      qualityScore += 0.1;
      issues.push('✅ Error handling');
    }

    if (content.includes('//') || content.includes('/*')) {
      qualityScore += 0.05;
      issues.push('✅ Comments present');
    }

    return { score: Math.max(0, Math.min(1, qualityScore)), issues };
  }

  private calculateApprovalScore(
    rules: { score: number; details: string[] },
    risk: { level: string; score: number; factors: string[] },
    quality: { score: number; issues: string[] }
  ): number {
    const weights = {
      rules: 0.4,
      risk: 0.35,
      quality: 0.25
    };

    const riskAdjustment = 1 - risk.score;
    
    return (
      rules.score * weights.rules +
      riskAdjustment * weights.risk +
      quality.score * weights.quality
    );
  }

  private generateImprovementSuggestions(
    change: CodeChange,
    risk: { level: string; score: number; factors: string[] },
    quality: { score: number; issues: string[] }
  ): string[] {
    const suggestions = [];

    if (risk.score > 0.5) {
      suggestions.push('Riduci il rischio suddividendo il cambiamento');
      suggestions.push('Aggiungi test per validare le modifiche');
    }

    if (quality.score < 0.6) {
      suggestions.push('Migliora la qualità del codice');
      suggestions.push('Aggiungi commenti esplicativi');
    }

    if (change.lines_changed > 5) {
      suggestions.push('Considera di suddividere in cambiamenti più piccoli');
    }

    quality.issues.forEach(issue => {
      if (issue.includes('Console.log')) {
        suggestions.push('Rimuovi console.log statements');
      }
      if (issue.includes('TODO')) {
        suggestions.push('Risolvi i TODO prima di applicare');
      }
    });

    return suggestions;
  }

  private createSafeDecision(change: CodeChange, approved: boolean): ApprovalDecision {
    return {
      approved,
      confidence: 0.5,
      reasoning: 'Decisione di sicurezza a causa di errore nell\'analisi',
      requires_human_review: true,
      suggested_improvements: ['Rivedi manualmente il cambiamento']
    };
  }

  // Metodi per interfacciarsi con l'agente
  async getApprovalHistory(): Promise<any[]> {
    return this.approvalHistory.slice(-20); // Ultimi 20 cambiamenti
  }

  async getApprovalStats(): Promise<{
    total: number;
    approved: number;
    rejected: number;
    auto_applied: number;
    human_reviews: number;
    success_rate: number;
  }> {
    const total = this.approvalHistory.length;
    const approved = this.approvalHistory.filter(h => h.decision.approved).length;
    const rejected = total - approved;
    const auto_applied = this.approvalHistory.filter(h => h.decision.auto_applied).length;
    const human_reviews = this.approvalHistory.filter(h => h.decision.requires_human_review).length;
    const success_rate = total > 0 ? (approved / total) * 100 : 0;

    return {
      total,
      approved,
      rejected,
      auto_applied,
      human_reviews,
      success_rate
    };
  }

  async updateOutcome(changeId: string, outcome: 'success' | 'failure') {
    const history = this.approvalHistory.find(h => 
      h.change.description === changeId || 
      h.timestamp === changeId
    );
    
    if (history) {
      history.outcome = outcome;
      
      // Aggiorna la coscienza con l'esito
      await consciousnessCore.processEvent({
        type: 'learn',
        data: `Approval outcome: ${outcome} for change: ${history.change.description}`,
        context: 'approval_agent_learning',
        timestamp: new Date().toISOString()
      });
    }
  }

  // Metodo per testare l'agente
  async testApprovalAgent(): Promise<{ testsPassed: number; totalTests: number; details: any[] }> {
    const testCases: CodeChange[] = [
      {
        type: 'modify',
        file: 'src/components/button.tsx',
        lines_changed: 2,
        complexity_score: 0.1,
        risk_level: 'low',
        description: 'Fix typo in button text',
        content: 'label="Submitt" -> label="Submit"',
        context: 'ui_fix'
      },
      {
        type: 'add',
        file: 'src/tests/button.test.tsx',
        lines_changed: 15,
        complexity_score: 0.2,
        risk_level: 'low',
        description: 'Add unit test for button component',
        content: 'describe("Button", () => { it("renders correctly", () => { ... }); });',
        context: 'test_addition'
      },
      {
        type: 'modify',
        file: 'server/auth/security.ts',
        lines_changed: 25,
        complexity_score: 0.8,
        risk_level: 'high',
        description: 'Major security update',
        content: 'Extensive security changes...',
        context: 'security_update'
      }
    ];

    const results = [];
    let passed = 0;

    for (const testCase of testCases) {
      const decision = await this.evaluateChange(testCase);
      
      let expectedResult = false;
      if (testCase.description.includes('typo')) expectedResult = true;
      if (testCase.description.includes('test')) expectedResult = true;
      if (testCase.description.includes('security') && testCase.risk_level === 'high') expectedResult = false;

      const testPassed = decision.approved === expectedResult;
      if (testPassed) passed++;

      results.push({
        testCase: testCase.description,
        expected: expectedResult,
        actual: decision.approved,
        passed: testPassed,
        reasoning: decision.reasoning
      });
    }

    return {
      testsPassed: passed,
      totalTests: testCases.length,
      details: results
    };
  }
}

export const approvalAgent = new ApprovalAgent();
export { ApprovalAgent, CodeChange, ApprovalDecision };