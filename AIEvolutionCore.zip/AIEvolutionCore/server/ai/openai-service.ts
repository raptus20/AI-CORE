import { InsertCodeSuggestion } from "@shared/schema";
import * as fs from 'fs';
import * as path from 'path';
import { autonomousSuggestionGenerator } from "./autonomous-suggestions";
import { multiProviderAIService } from "./multi-provider-service";

class OpenAIService {
  private readonly excludedDirs = [
    'node_modules', 
    '.git', 
    'dist', 
    'build',
    'backups'
  ];
  private readonly excludedFiles = [
    '.env',
    'package-lock.json',
    '.DS_Store'
  ];
  private readonly acceptedExtensions = [
    '.ts', 
    '.tsx', 
    '.js', 
    '.jsx', 
    '.json', 
    '.css', 
    '.html'
  ];

  constructor() {
    console.log("Initialized OpenAI service with multi-provider AI support");
  }
  
  /**
   * Scans the codebase and autonomously finds files that could be improved
   */
  async scanCodebase(): Promise<{ filePath: string; content: string }[]> {
    const projectRoot = process.cwd();
    const files = this.findAllFiles(projectRoot);
    
    // Limit to 10 files to prevent overloading
    return files.slice(0, 10);
  }
  
  /**
   * Find all files in the codebase that match our criteria
   */
  private findAllFiles(dir: string): { filePath: string; content: string }[] {
    let results: { filePath: string; content: string }[] = [];
    
    try {
      const files = fs.readdirSync(dir);
      
      for (const file of files) {
        const fullPath = path.join(dir, file);
        const relativePath = path.relative(process.cwd(), fullPath);
        
        // Skip excluded directories
        if (this.excludedDirs.some(excluded => fullPath.includes(`/${excluded}/`)) ||
            this.excludedDirs.includes(file)) {
          continue;
        }
        
        // Skip excluded files
        if (this.excludedFiles.includes(file)) {
          continue;
        }
        
        if (fs.statSync(fullPath).isDirectory()) {
          // Recursively scan subdirectories
          results = results.concat(this.findAllFiles(fullPath));
        } else {
          // Check file extension
          const ext = path.extname(file);
          if (this.acceptedExtensions.includes(ext)) {
            try {
              const content = fs.readFileSync(fullPath, 'utf8');
              // Only include files under 10KB to avoid large files
              if (content.length < 10240) {
                results.push({
                  filePath: relativePath,
                  content
                });
              }
            } catch (err) {
              console.error(`Error reading file ${fullPath}:`, err);
            }
          }
        }
      }
    } catch (err) {
      console.error(`Error scanning directory ${dir}:`, err);
    }
    
    return results;
  }

  /**
   * Analyzes a file to determine if it could benefit from improvements
   */
  async analyzeFileForImprovements(filePath: string, content: string): Promise<{
    shouldImprove: boolean;
    reason: string;
    priority: number; // 1-10, with 10 being highest priority
  }> {
    try {
      const prompt = `
        You are an AI code analysis system. Analyze the following file to determine if it would benefit from improvements:
        
        File path: ${filePath}
        
        File content:
        \`\`\`
        ${content}
        \`\`\`
        
        Evaluate this code for potential improvements in terms of:
        1. Performance optimizations
        2. Code readability and maintainability
        3. Error handling
        4. Security concerns
        5. Best practices
        
        Respond with JSON in the format:
        {
          "shouldImprove": true/false,
          "reason": "Brief explanation of why this file should or should not be improved",
          "priority": number from 1-10 (10 being highest priority)
        }
        
        Only suggest improvements for files that would genuinely benefit from them. 
        Prioritize substantive improvements over minor style changes.
      `;

      const response = await multiProviderAIService.generateResponse(prompt, {
        temperature: 0.3,
        maxTokens: 500
      });

      // Parse the JSON response
      const jsonMatch = response.match(/\{[^}]+\}/);
      if (jsonMatch) {
        const result = JSON.parse(jsonMatch[0]);
        return {
          shouldImprove: result.shouldImprove || false,
          reason: result.reason || "No analysis provided",
          priority: result.priority || 1
        };
      }

      return {
        shouldImprove: false,
        reason: "Could not parse analysis result",
        priority: 1
      };
    } catch (error) {
      console.error(`Error analyzing file ${filePath}:`, error);
      return {
        shouldImprove: false,
        reason: "Analysis failed",
        priority: 1
      };
    }
  }

  /**
   * Autonomously identifies files that need improvement and generates suggestions
   */
  async autonomousImprovement(): Promise<InsertCodeSuggestion[]> {
    try {
      const files = await this.scanCodebase();
      const improvements: InsertCodeSuggestion[] = [];
      
      for (const file of files) {
        const analysis = await this.analyzeFileForImprovements(file.filePath, file.content);
        
        if (analysis.shouldImprove && analysis.priority >= 7) {
          const suggestion = await this.generateCodeSuggestion(file.content, {
            context: `File: ${file.filePath}\nAnalysis: ${analysis.reason}`,
            priority: analysis.priority
          });
          
          if (suggestion) {
            improvements.push(suggestion);
          }
        }
      }
      
      return improvements;
    } catch (error) {
      console.error("Error in autonomous improvement:", error);
      // Fall back to autonomous suggestions if AI fails
      return await autonomousSuggestionGenerator.generateSuggestions();
    }
  }

  /**
   * Generate a code suggestion using AI
   */
  async generateCodeSuggestion(
    code: string,
    context: {
      context?: string;
      priority?: number;
    } = {}
  ): Promise<InsertCodeSuggestion | null> {
    try {
      const prompt = `
        You are an expert code improvement assistant. Analyze the following code and provide a specific, actionable improvement suggestion.
        
        ${context.context ? `Context: ${context.context}` : ''}
        
        Code to analyze:
        \`\`\`
        ${code}
        \`\`\`
        
        Provide a JSON response with the following structure:
        {
          "title": "Brief title of the improvement",
          "description": "Detailed description of the improvement",
          "originalCode": "The original code snippet to replace",
          "improvedCode": "The improved code snippet",
          "reasoning": "Why this improvement is beneficial",
          "tags": ["relevant", "tags"],
          "impact": "high/medium/low"
        }
        
        Focus on substantial improvements like:
        - Performance optimizations
        - Better error handling
        - Security improvements
        - Code readability and maintainability
        - Best practices adherence
      `;

      const response = await multiProviderAIService.generateResponse(prompt, {
        temperature: 0.4,
        maxTokens: 1000
      });

      // Parse the JSON response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const result = JSON.parse(jsonMatch[0]);
        
        return {
          title: result.title || "Code Improvement",
          description: result.description || "Suggested code improvement",
          originalCode: result.originalCode || "",
          improvedCode: result.improvedCode || "",
          reasoning: result.reasoning || "No reasoning provided",
          tags: result.tags || ["improvement"],
          impact: result.impact || "medium",
          status: "pending"
        };
      }

      return null;
    } catch (error) {
      console.error("Error generating code suggestion:", error);
      return null;
    }
  }

  /**
   * Analyze code to evaluate if it meets quality standards
   */
  async analyzeCode(code: string): Promise<{
    quality: number;
    suggestions: string[];
    issues: string[];
  }> {
    try {
      const prompt = `
        Analyze this code for quality, best practices, and potential issues:
        
        \`\`\`
        ${code}
        \`\`\`
        
        Provide a JSON response with:
        {
          "quality": number from 1-100,
          "suggestions": ["improvement suggestions"],
          "issues": ["identified issues"]
        }
      `;

      const response = await multiProviderAIService.generateResponse(prompt, {
        temperature: 0.3,
        maxTokens: 800
      });

      // Parse the JSON response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const result = JSON.parse(jsonMatch[0]);
        return {
          quality: result.quality || 70,
          suggestions: result.suggestions || [],
          issues: result.issues || []
        };
      }

      return {
        quality: 70,
        suggestions: ["Could not analyze code"],
        issues: ["Analysis failed"]
      };
    } catch (error) {
      console.error("Error analyzing code:", error);
      return {
        quality: 50,
        suggestions: ["Analysis failed"],
        issues: ["Could not analyze code"]
      };
    }
  }
}

export const openAIService = new OpenAIService();
