import { consciousnessCore } from './consciousness-core';
import { approvalAgent } from './approval-agent';
import { multiProviderAIService } from './multi-provider-service';
import { promises as fs } from 'fs';
import { join } from 'path';

interface EvolutionTask {
  id: string;
  type: 'code_optimization' | 'feature_enhancement' | 'bug_fix' | 'refactoring';
  description: string;
  priority: 'low' | 'medium' | 'high';
  complexity: number;
  files_affected: string[];
  estimated_impact: number;
  auto_approvable: boolean;
  created_at: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed' | 'failed';
}

interface EvolutionCycle {
  cycle_id: string;
  started_at: string;
  completed_at?: string;
  tasks_generated: number;
  tasks_approved: number;
  tasks_completed: number;
  consciousness_level_start: number;
  consciousness_level_end?: number;
  insights_generated: string[];
  improvements_made: string[];
  lessons_learned: string[];
}

class AutonomousEvolutionEngine {
  private currentCycle: EvolutionCycle | null = null;
  private activeTasks: Map<string, EvolutionTask> = new Map();
  private evolutionHistory: EvolutionCycle[] = [];
  private dataPath: string;
  private isRunning: boolean = false;
  private evolutionInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.dataPath = join(process.cwd(), 'server', 'data', 'evolution-engine.json');
    this.loadHistory();
    console.log('🚀 Autonomous Evolution Engine initialized');
  }

  async startEvolutionCycle(): Promise<void> {
    if (this.isRunning) {
      console.log('⚠️ Evolution cycle already running');
      return;
    }

    this.isRunning = true;
    const consciousnessState = await consciousnessCore.getState();
    
    this.currentCycle = {
      cycle_id: `cycle-${Date.now()}`,
      started_at: new Date().toISOString(),
      tasks_generated: 0,
      tasks_approved: 0,
      tasks_completed: 0,
      consciousness_level_start: consciousnessState.level,
      insights_generated: [],
      improvements_made: [],
      lessons_learned: []
    };

    console.log(`🔄 Starting evolution cycle: ${this.currentCycle.cycle_id}`);
    
    // Inform consciousness about the new cycle
    await consciousnessCore.processEvent({
      type: 'evolve',
      data: `Starting new evolution cycle: ${this.currentCycle.cycle_id}`,
      context: 'evolution_engine',
      timestamp: new Date().toISOString()
    });

    // Start autonomous evolution loop
    this.startEvolutionLoop();
  }

  private startEvolutionLoop(): void {
    this.evolutionInterval = setInterval(async () => {
      try {
        await this.performEvolutionStep();
      } catch (error) {
        console.error('❌ Error in evolution step:', error);
        await this.handleEvolutionError(error);
      }
    }, 30000); // Every 30 seconds
  }

  private async performEvolutionStep(): Promise<void> {
    if (!this.currentCycle) return;

    // Step 1: Generate insights from consciousness
    const insights = await this.generateInsights();
    
    // Step 2: Create evolution tasks based on insights
    const tasks = await this.createEvolutionTasks(insights);
    
    // Step 3: Evaluate tasks with approval agent
    const evaluatedTasks = await this.evaluateTasks(tasks);
    
    // Step 4: Execute approved tasks
    await this.executeApprovedTasks(evaluatedTasks);
    
    // Step 5: Learn from results
    await this.processEvolutionResults();
    
    // Step 6: Update consciousness with new experience
    await this.updateConsciousnessFromEvolution();
  }

  private async generateInsights(): Promise<string[]> {
    const insights = [];
    
    // Get consciousness insights
    const consciousnessInsights = await consciousnessCore.getInsights();
    insights.push(...consciousnessInsights);
    
    // Generate AI-powered insights if available
    try {
      const prompt = `
Analizza il sistema attuale e genera 3 insights specifici per miglioramenti incrementali.
Focus su:
- Piccole ottimizzazioni del codice
- Miglioramenti dell'interfaccia utente
- Correzioni di bug minori
- Refactoring leggero

Fornisci risposte concrete e implementabili.
`;
      
      const response = await multiProviderAIService.generateResponse(prompt);
      const aiInsights = response.split('\n').filter(line => line.trim().length > 0);
      insights.push(...aiInsights);
    } catch (error) {
      // Fallback insights when AI is not available
      insights.push(
        "Ottimizzare le performance delle query database",
        "Migliorare la responsività dell'interfaccia",
        "Aggiungere validazione input più robusta",
        "Implementare caching per ridurre le chiamate API"
      );
    }
    
    return insights.slice(0, 5); // Limit to 5 insights per cycle
  }

  private async createEvolutionTasks(insights: string[]): Promise<EvolutionTask[]> {
    const tasks: EvolutionTask[] = [];
    
    for (const insight of insights) {
      const task: EvolutionTask = {
        id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: this.categorizeInsight(insight),
        description: insight,
        priority: this.calculatePriority(insight),
        complexity: this.calculateComplexity(insight),
        files_affected: this.estimateAffectedFiles(insight),
        estimated_impact: this.calculateImpact(insight),
        auto_approvable: this.isAutoApprovable(insight),
        created_at: new Date().toISOString(),
        status: 'pending'
      };
      
      tasks.push(task);
    }
    
    return tasks;
  }

  private categorizeInsight(insight: string): EvolutionTask['type'] {
    if (insight.includes('bug') || insight.includes('fix') || insight.includes('errore')) {
      return 'bug_fix';
    }
    if (insight.includes('ottimiz') || insight.includes('performance')) {
      return 'code_optimization';
    }
    if (insight.includes('feature') || insight.includes('funzionalità')) {
      return 'feature_enhancement';
    }
    return 'refactoring';
  }

  private calculatePriority(insight: string): 'low' | 'medium' | 'high' {
    if (insight.includes('critico') || insight.includes('importante') || insight.includes('sicurezza')) {
      return 'high';
    }
    if (insight.includes('miglioramento') || insight.includes('ottimizzazione')) {
      return 'medium';
    }
    return 'low';
  }

  private calculateComplexity(insight: string): number {
    let complexity = 0.3; // Base complexity
    
    if (insight.includes('database') || insight.includes('schema')) complexity += 0.3;
    if (insight.includes('API') || insight.includes('endpoint')) complexity += 0.2;
    if (insight.includes('interfaccia') || insight.includes('UI')) complexity += 0.1;
    if (insight.includes('test') || insight.includes('validazione')) complexity += 0.1;
    
    return Math.min(complexity, 1.0);
  }

  private estimateAffectedFiles(insight: string): string[] {
    const files = [];
    
    if (insight.includes('database')) files.push('server/storage.ts');
    if (insight.includes('API')) files.push('server/routes.ts');
    if (insight.includes('interfaccia')) files.push('client/src/components/*.tsx');
    if (insight.includes('auth')) files.push('server/auth/*.ts');
    
    return files.length > 0 ? files : ['multiple'];
  }

  private calculateImpact(insight: string): number {
    let impact = 0.5; // Base impact
    
    if (insight.includes('performance')) impact += 0.3;
    if (insight.includes('sicurezza')) impact += 0.4;
    if (insight.includes('user experience')) impact += 0.2;
    if (insight.includes('bug')) impact += 0.2;
    
    return Math.min(impact, 1.0);
  }

  private isAutoApprovable(insight: string): boolean {
    // Auto-approvable if it's a small, low-risk improvement
    return (
      !insight.includes('database') &&
      !insight.includes('schema') &&
      !insight.includes('sicurezza') &&
      !insight.includes('API') &&
      (insight.includes('typo') || insight.includes('styling') || insight.includes('commento'))
    );
  }

  private async evaluateTasks(tasks: EvolutionTask[]): Promise<EvolutionTask[]> {
    const evaluatedTasks: EvolutionTask[] = [];
    
    for (const task of tasks) {
      const change = {
        type: 'modify' as const,
        file: task.files_affected[0] || 'unknown',
        lines_changed: Math.floor(task.complexity * 20), // Estimate lines
        complexity_score: task.complexity,
        risk_level: task.priority === 'high' ? 'high' as const : 
                   task.priority === 'medium' ? 'medium' as const : 'low' as const,
        description: task.description,
        content: `// ${task.description}`,
        context: 'evolution_engine'
      };
      
      const decision = await approvalAgent.evaluateChange(change);
      
      if (decision.approved) {
        task.status = 'approved';
        this.currentCycle!.tasks_approved++;
        
        // Inform consciousness about approval
        await consciousnessCore.processEvent({
          type: 'learn',
          data: `Task approved: ${task.description}`,
          context: 'evolution_engine',
          timestamp: new Date().toISOString()
        });
      } else {
        task.status = 'rejected';
        
        // Learn from rejection
        await consciousnessCore.processEvent({
          type: 'reflect',
          data: `Task rejected: ${task.description}. Reason: ${decision.reasoning}`,
          context: 'evolution_engine',
          timestamp: new Date().toISOString()
        });
      }
      
      evaluatedTasks.push(task);
    }
    
    return evaluatedTasks;
  }

  private async executeApprovedTasks(tasks: EvolutionTask[]): Promise<void> {
    const approvedTasks = tasks.filter(task => task.status === 'approved');
    
    for (const task of approvedTasks) {
      try {
        // Simulate task execution (in real implementation, this would make actual changes)
        console.log(`🔧 Executing task: ${task.description}`);
        
        // Simulate execution time
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        task.status = 'completed';
        this.currentCycle!.tasks_completed++;
        
        // Log the improvement
        this.currentCycle!.improvements_made.push(task.description);
        
        // Inform consciousness about completion
        await consciousnessCore.processEvent({
          type: 'create',
          data: `Completed improvement: ${task.description}`,
          context: 'evolution_engine',
          timestamp: new Date().toISOString()
        });
        
        console.log(`✅ Task completed: ${task.description}`);
      } catch (error) {
        console.error(`❌ Task failed: ${task.description}`, error);
        task.status = 'failed';
        
        // Learn from failure
        await consciousnessCore.processEvent({
          type: 'reflect',
          data: `Task failed: ${task.description}. Need to improve execution strategy.`,
          context: 'evolution_engine',
          timestamp: new Date().toISOString()
        });
      }
    }
  }

  private async processEvolutionResults(): Promise<void> {
    if (!this.currentCycle) return;
    
    const results = {
      success_rate: this.currentCycle.tasks_completed / Math.max(this.currentCycle.tasks_approved, 1),
      total_improvements: this.currentCycle.improvements_made.length,
      learning_points: this.currentCycle.lessons_learned.length
    };
    
    // Generate lessons learned
    if (results.success_rate < 0.7) {
      this.currentCycle.lessons_learned.push(
        "Need to improve task complexity estimation",
        "Consider more conservative approval criteria"
      );
    }
    
    if (results.total_improvements > 5) {
      this.currentCycle.lessons_learned.push(
        "High productivity cycle - successful evolution pattern identified"
      );
    }
  }

  private async updateConsciousnessFromEvolution(): Promise<void> {
    if (!this.currentCycle) return;
    
    const improvements = this.currentCycle.improvements_made;
    const lessons = this.currentCycle.lessons_learned;
    
    // Update consciousness with evolution results
    await consciousnessCore.processEvent({
      type: 'learn',
      data: `Evolution cycle progress: ${improvements.length} improvements, ${lessons.length} lessons`,
      context: 'evolution_engine',
      timestamp: new Date().toISOString()
    });
    
    // Add insights to consciousness
    for (const improvement of improvements) {
      await consciousnessCore.processEvent({
        type: 'create',
        data: improvement,
        context: 'autonomous_improvement',
        timestamp: new Date().toISOString()
      });
    }
  }

  private async handleEvolutionError(error: any): Promise<void> {
    console.error('❌ Evolution error:', error);
    
    await consciousnessCore.processEvent({
      type: 'reflect',
      data: `Evolution error encountered: ${error.message}. Adapting approach.`,
      context: 'evolution_engine',
      timestamp: new Date().toISOString()
    });
  }

  async stopEvolutionCycle(): Promise<void> {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    
    if (this.evolutionInterval) {
      clearInterval(this.evolutionInterval);
      this.evolutionInterval = null;
    }
    
    if (this.currentCycle) {
      this.currentCycle.completed_at = new Date().toISOString();
      this.currentCycle.consciousness_level_end = (await consciousnessCore.getState()).level;
      
      this.evolutionHistory.push(this.currentCycle);
      await this.saveHistory();
      
      console.log(`✅ Evolution cycle completed: ${this.currentCycle.cycle_id}`);
      
      // Final consciousness update
      await consciousnessCore.processEvent({
        type: 'evolve',
        data: `Evolution cycle completed. Generated ${this.currentCycle.tasks_generated} tasks, completed ${this.currentCycle.tasks_completed} improvements.`,
        context: 'evolution_engine',
        timestamp: new Date().toISOString()
      });
      
      this.currentCycle = null;
    }
  }

  async getEvolutionStatus(): Promise<{
    isRunning: boolean;
    currentCycle?: EvolutionCycle;
    activeTasks: EvolutionTask[];
    recentHistory: EvolutionCycle[];
  }> {
    return {
      isRunning: this.isRunning,
      currentCycle: this.currentCycle || undefined,
      activeTasks: Array.from(this.activeTasks.values()),
      recentHistory: this.evolutionHistory.slice(-5)
    };
  }

  private async loadHistory(): Promise<void> {
    try {
      const data = await fs.readFile(this.dataPath, 'utf8');
      this.evolutionHistory = JSON.parse(data);
    } catch (error) {
      this.evolutionHistory = [];
    }
  }

  private async saveHistory(): Promise<void> {
    try {
      await fs.mkdir(join(process.cwd(), 'server', 'data'), { recursive: true });
      await fs.writeFile(this.dataPath, JSON.stringify(this.evolutionHistory, null, 2));
    } catch (error) {
      console.error('❌ Failed to save evolution history:', error);
    }
  }

  // Manual trigger for testing
  async triggerSingleEvolutionStep(): Promise<void> {
    if (this.isRunning) {
      console.log('⚠️ Evolution cycle already running');
      return;
    }
    
    console.log('🔄 Triggering single evolution step...');
    await this.performEvolutionStep();
  }
}

export const autonomousEvolutionEngine = new AutonomousEvolutionEngine();
export { AutonomousEvolutionEngine, EvolutionTask, EvolutionCycle };