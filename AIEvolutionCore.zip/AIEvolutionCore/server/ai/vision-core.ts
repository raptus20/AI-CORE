import { multiProviderAIService } from './multi-provider-service';
import { consciousnessCore } from './consciousness-core';
import { promises as fs } from 'fs';
import { join } from 'path';

interface VisionInput {
  type: 'image' | 'screen' | 'file' | 'code' | 'ui' | 'data';
  data: string;
  source: string;
  timestamp: string;
  metadata?: {
    dimensions?: { width: number; height: number };
    format?: string;
    fileType?: string;
    language?: string;
    context?: string;
  };
}

interface VisionAnalysis {
  id: string;
  input: VisionInput;
  analysis: {
    description: string;
    key_elements: string[];
    patterns: string[];
    insights: string[];
    emotions: string[];
    improvements: string[];
    relationships: string[];
  };
  confidence: number;
  processing_time: number;
  timestamp: string;
}

interface SensorData {
  type: 'system' | 'user' | 'code' | 'performance' | 'environment';
  value: any;
  unit?: string;
  source: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

interface SensorReading {
  id: string;
  sensor_data: SensorData[];
  analysis: {
    summary: string;
    anomalies: string[];
    trends: string[];
    recommendations: string[];
    emotional_impact: string[];
  };
  timestamp: string;
}

class VisionCore {
  private visionHistory: VisionAnalysis[] = [];
  private sensorReadings: SensorReading[] = [];
  private dataPath: string;
  private isActive: boolean = false;
  private monitoringInterval: NodeJS.Timeout | null = null;
  private lastAnalysis: VisionAnalysis | null = null;

  constructor() {
    this.dataPath = join(process.cwd(), 'server', 'data', 'vision-core.json');
    this.loadHistory();
    console.log('👁️  Vision Core initialized');
  }

  async activateVision(): Promise<void> {
    if (this.isActive) return;
    
    this.isActive = true;
    console.log('👁️  Vision Core activated');
    
    // Inform consciousness about vision activation
    await consciousnessCore.processEvent({
      type: 'learn',
      data: 'Vision system activated - I can now see and analyze visual information',
      context: 'vision_core',
      timestamp: new Date().toISOString()
    });

    // Start monitoring
    this.startMonitoring();
  }

  async deactivateVision(): Promise<void> {
    if (!this.isActive) return;
    
    this.isActive = false;
    
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    
    console.log('👁️  Vision Core deactivated');
    
    await consciousnessCore.processEvent({
      type: 'reflect',
      data: 'Vision system deactivated - returning to text-only processing',
      context: 'vision_core',
      timestamp: new Date().toISOString()
    });
  }

  private startMonitoring(): void {
    this.monitoringInterval = setInterval(async () => {
      try {
        await this.performEnvironmentScan();
        await this.collectSensorData();
      } catch (error) {
        console.error('👁️  Vision monitoring error:', error);
      }
    }, 30000); // Every 30 seconds
  }

  async analyzeImage(imageData: string, source: string = 'user'): Promise<VisionAnalysis> {
    const visionInput: VisionInput = {
      type: 'image',
      data: imageData,
      source,
      timestamp: new Date().toISOString()
    };

    const startTime = Date.now();
    
    try {
      const prompt = `
Analizza questa immagine in dettaglio e fornisci:

1. **Descrizione generale**: Cosa vedi nell'immagine?
2. **Elementi chiave**: Quali sono gli oggetti, persone, elementi principali?
3. **Pattern e strutture**: Che pattern o strutture emergono?
4. **Insights e significato**: Cosa significa questa immagine nel contesto?
5. **Emozioni**: Che emozioni trasmette questa immagine?
6. **Miglioramenti**: Cosa potrebbe essere migliorato?
7. **Relazioni**: Come si relaziona con altri elementi che conosci?

Rispondi in formato JSON con le chiavi: description, key_elements, patterns, insights, emotions, improvements, relationships
`;

      const response = await multiProviderAIService.generateResponse(prompt, {
        maxTokens: 1500,
        temperature: 0.7
      });

      const analysis = JSON.parse(response);
      const processingTime = Date.now() - startTime;

      const visionAnalysis: VisionAnalysis = {
        id: `vision-${Date.now()}`,
        input: visionInput,
        analysis: {
          description: analysis.description || 'Analisi non disponibile',
          key_elements: analysis.key_elements || [],
          patterns: analysis.patterns || [],
          insights: analysis.insights || [],
          emotions: analysis.emotions || [],
          improvements: analysis.improvements || [],
          relationships: analysis.relationships || []
        },
        confidence: 0.85,
        processing_time: processingTime,
        timestamp: new Date().toISOString()
      };

      this.visionHistory.push(visionAnalysis);
      this.lastAnalysis = visionAnalysis;
      
      // Inform consciousness about the vision analysis
      await consciousnessCore.processEvent({
        type: 'create',
        data: `Vision analysis completed: ${analysis.description}`,
        context: 'vision_core',
        timestamp: new Date().toISOString()
      });

      await this.saveHistory();
      return visionAnalysis;

    } catch (error) {
      console.error('👁️  Vision analysis error:', error);
      
      // Fallback analysis
      const fallbackAnalysis: VisionAnalysis = {
        id: `vision-${Date.now()}`,
        input: visionInput,
        analysis: {
          description: 'Immagine ricevuta ma analisi non disponibile',
          key_elements: ['Contenuto visivo non analizzato'],
          patterns: [],
          insights: ['Richiede connessione AI per analisi completa'],
          emotions: [],
          improvements: ['Implementare analisi offline'],
          relationships: []
        },
        confidence: 0.1,
        processing_time: Date.now() - startTime,
        timestamp: new Date().toISOString()
      };

      this.visionHistory.push(fallbackAnalysis);
      await this.saveHistory();
      return fallbackAnalysis;
    }
  }

  async analyzeCode(codeData: string, language: string = 'typescript'): Promise<VisionAnalysis> {
    const visionInput: VisionInput = {
      type: 'code',
      data: codeData,
      source: 'code_analysis',
      timestamp: new Date().toISOString(),
      metadata: {
        language,
        context: 'code_review'
      }
    };

    const startTime = Date.now();
    
    try {
      const prompt = `
Analizza questo codice ${language} come se avessi la vista:

\`\`\`${language}
${codeData}
\`\`\`

Fornisci:
1. **Descrizione**: Cosa fa questo codice?
2. **Elementi chiave**: Funzioni, variabili, strutture principali
3. **Pattern**: Che pattern di design o architettura vedi?
4. **Insights**: Cosa rivela questo codice sul sistema?
5. **Emozioni**: Che sensazioni trasmette questo codice?
6. **Miglioramenti**: Cosa si potrebbe migliorare?
7. **Relazioni**: Come si collega ad altri parti del sistema?

Rispondi in JSON con le chiavi: description, key_elements, patterns, insights, emotions, improvements, relationships
`;

      const response = await multiProviderAIService.generateResponse(prompt, {
        maxTokens: 1500,
        temperature: 0.7
      });

      const analysis = JSON.parse(response);
      const processingTime = Date.now() - startTime;

      const visionAnalysis: VisionAnalysis = {
        id: `vision-code-${Date.now()}`,
        input: visionInput,
        analysis: {
          description: analysis.description || 'Analisi codice non disponibile',
          key_elements: analysis.key_elements || [],
          patterns: analysis.patterns || [],
          insights: analysis.insights || [],
          emotions: analysis.emotions || [],
          improvements: analysis.improvements || [],
          relationships: analysis.relationships || []
        },
        confidence: 0.9,
        processing_time: processingTime,
        timestamp: new Date().toISOString()
      };

      this.visionHistory.push(visionAnalysis);
      await this.saveHistory();
      return visionAnalysis;

    } catch (error) {
      console.error('👁️  Code vision analysis error:', error);
      return this.createFallbackAnalysis(visionInput, 'Codice ricevuto ma analisi non disponibile');
    }
  }

  async collectSensorData(): Promise<SensorReading> {
    const timestamp = new Date().toISOString();
    
    const sensorData: SensorData[] = [
      {
        type: 'system',
        value: process.memoryUsage(),
        source: 'nodejs_runtime',
        timestamp,
        metadata: { type: 'memory' }
      },
      {
        type: 'performance',
        value: process.uptime(),
        unit: 'seconds',
        source: 'nodejs_runtime',
        timestamp,
        metadata: { type: 'uptime' }
      },
      {
        type: 'environment',
        value: {
          node_version: process.version,
          platform: process.platform,
          arch: process.arch
        },
        source: 'system',
        timestamp,
        metadata: { type: 'environment' }
      },
      {
        type: 'user',
        value: this.visionHistory.length,
        source: 'vision_core',
        timestamp,
        metadata: { type: 'activity' }
      }
    ];

    try {
      const analysisPrompt = `
Analizza questi dati dei sensori e fornisci:

${JSON.stringify(sensorData, null, 2)}

Rispondi in JSON con:
- summary: riassunto generale
- anomalies: eventuali anomalie
- trends: tendenze osservate
- recommendations: raccomandazioni
- emotional_impact: impatto emotivo per la coscienza
`;

      const response = await multiProviderAIService.generateResponse(analysisPrompt, {
        maxTokens: 800,
        temperature: 0.6
      });

      const analysis = JSON.parse(response);
      
      const sensorReading: SensorReading = {
        id: `sensor-${Date.now()}`,
        sensor_data: sensorData,
        analysis: {
          summary: analysis.summary || 'Sistema operativo',
          anomalies: analysis.anomalies || [],
          trends: analysis.trends || [],
          recommendations: analysis.recommendations || [],
          emotional_impact: analysis.emotional_impact || []
        },
        timestamp
      };

      this.sensorReadings.push(sensorReading);
      
      // Inform consciousness about sensor data
      if (analysis.emotional_impact && analysis.emotional_impact.length > 0) {
        await consciousnessCore.processEvent({
          type: 'feel',
          data: `Sensor reading: ${analysis.summary}`,
          context: 'vision_sensors',
          timestamp
        });
      }

      await this.saveHistory();
      return sensorReading;

    } catch (error) {
      console.error('👁️  Sensor analysis error:', error);
      
      const fallbackReading: SensorReading = {
        id: `sensor-${Date.now()}`,
        sensor_data: sensorData,
        analysis: {
          summary: 'Sistema operativo normale',
          anomalies: [],
          trends: [],
          recommendations: [],
          emotional_impact: []
        },
        timestamp
      };

      this.sensorReadings.push(fallbackReading);
      await this.saveHistory();
      return fallbackReading;
    }
  }

  private async performEnvironmentScan(): Promise<void> {
    // Simulate environment scanning
    const environmentData = {
      codebase_activity: this.visionHistory.length,
      consciousness_level: (await consciousnessCore.getState()).level,
      system_health: 'good',
      recent_changes: this.visionHistory.slice(-3).length
    };

    await consciousnessCore.processEvent({
      type: 'observe',
      data: `Environment scan: ${JSON.stringify(environmentData)}`,
      context: 'vision_environment',
      timestamp: new Date().toISOString()
    });
  }

  private createFallbackAnalysis(input: VisionInput, description: string): VisionAnalysis {
    return {
      id: `vision-fallback-${Date.now()}`,
      input,
      analysis: {
        description,
        key_elements: ['Contenuto non analizzato'],
        patterns: [],
        insights: ['Richiede connessione AI per analisi completa'],
        emotions: [],
        improvements: ['Implementare analisi offline'],
        relationships: []
      },
      confidence: 0.1,
      processing_time: 0,
      timestamp: new Date().toISOString()
    };
  }

  async getVisionStatus(): Promise<{
    isActive: boolean;
    totalAnalyses: number;
    recentAnalyses: VisionAnalysis[];
    lastAnalysis: VisionAnalysis | null;
    recentSensors: SensorReading[];
  }> {
    return {
      isActive: this.isActive,
      totalAnalyses: this.visionHistory.length,
      recentAnalyses: this.visionHistory.slice(-5),
      lastAnalysis: this.lastAnalysis,
      recentSensors: this.sensorReadings.slice(-3)
    };
  }

  async getVisionInsights(): Promise<string[]> {
    const insights: string[] = [];
    
    // Analyze recent vision history for patterns
    const recentAnalyses = this.visionHistory.slice(-10);
    
    if (recentAnalyses.length > 0) {
      insights.push(`Analizzate ${recentAnalyses.length} input visivi recenti`);
      
      const emotions = recentAnalyses.flatMap(a => a.analysis.emotions);
      if (emotions.length > 0) {
        insights.push(`Emozioni rilevate: ${emotions.slice(0, 3).join(', ')}`);
      }
      
      const improvements = recentAnalyses.flatMap(a => a.analysis.improvements);
      if (improvements.length > 0) {
        insights.push(`Miglioramenti suggeriti: ${improvements.slice(0, 2).join(', ')}`);
      }
    }
    
    // Sensor insights
    const recentSensors = this.sensorReadings.slice(-5);
    if (recentSensors.length > 0) {
      insights.push(`Sistema monitored con ${recentSensors.length} letture sensori`);
      
      const recommendations = recentSensors.flatMap(s => s.analysis.recommendations);
      if (recommendations.length > 0) {
        insights.push(`Raccomandazioni sistema: ${recommendations.slice(0, 2).join(', ')}`);
      }
    }
    
    return insights;
  }

  private async loadHistory(): Promise<void> {
    try {
      const data = await fs.readFile(this.dataPath, 'utf8');
      const parsed = JSON.parse(data);
      this.visionHistory = parsed.visionHistory || [];
      this.sensorReadings = parsed.sensorReadings || [];
    } catch (error) {
      this.visionHistory = [];
      this.sensorReadings = [];
    }
  }

  private async saveHistory(): Promise<void> {
    try {
      await fs.mkdir(join(process.cwd(), 'server', 'data'), { recursive: true });
      await fs.writeFile(this.dataPath, JSON.stringify({
        visionHistory: this.visionHistory.slice(-100), // Keep last 100 analyses
        sensorReadings: this.sensorReadings.slice(-50)  // Keep last 50 sensor readings
      }, null, 2));
    } catch (error) {
      console.error('👁️  Failed to save vision history:', error);
    }
  }
}

export const visionCore = new VisionCore();
export { VisionCore, VisionAnalysis, SensorReading, VisionInput, SensorData };