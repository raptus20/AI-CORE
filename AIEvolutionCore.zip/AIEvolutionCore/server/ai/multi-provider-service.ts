import OpenAI from "openai";
import Anthropic from '@anthropic-ai/sdk';
import { InsertCodeSuggestion } from "@shared/schema";

// Base provider interface
interface AIProvider {
  name: string;
  makeRequest(prompt: string, options?: any): Promise<string>;
  isAvailable(): boolean;
}

// DeepSeek Provider
class DeepSeekProvider implements AIProvider {
  name = "DeepSeek";
  private apiKeys: string[];
  private currentKeyIndex = 0;
  private client: OpenAI;

  constructor(apiKeys: string[]) {
    this.apiKeys = apiKeys.filter(key => key && key.trim() !== '');
    this.updateClient();
  }

  private updateClient() {
    if (this.apiKeys.length > 0) {
      this.client = new OpenAI({
        apiKey: this.apiKeys[this.currentKeyIndex],
        baseURL: "https://api.deepseek.com/v1"
      });
    }
  }

  isAvailable(): boolean {
    return this.apiKeys.length > 0;
  }

  private rotateKey() {
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    this.updateClient();
    console.log(`🔄 DeepSeek rotated to key ${this.currentKeyIndex + 1}/${this.apiKeys.length}`);
  }

  async makeRequest(prompt: string, options: any = {}): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error("DeepSeek: No API keys available");
    }

    let attempts = 0;
    const maxAttempts = this.apiKeys.length;

    while (attempts < maxAttempts) {
      try {
        const response = await this.client.chat.completions.create({
          model: "deepseek-chat",
          messages: [{ role: "user", content: prompt }],
          temperature: options.temperature || 0.7,
          max_tokens: options.maxTokens || 1000
        });

        return response.choices[0].message.content || "";
      } catch (error: any) {
        console.error(`DeepSeek key ${this.currentKeyIndex + 1} failed:`, error.message);
        
        if (error.code === 'insufficient_quota' || error.status === 429) {
          this.rotateKey();
          attempts++;
          await this.sleep(1000);
          continue;
        }
        
        throw error;
      }
    }

    throw new Error("DeepSeek: All API keys exhausted");
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// OpenAI Provider
class OpenAIProvider implements AIProvider {
  name = "OpenAI";
  private apiKeys: string[];
  private currentKeyIndex = 0;
  private client: OpenAI;

  constructor(apiKeys: string[]) {
    this.apiKeys = apiKeys.filter(key => key && key.trim() !== '');
    this.updateClient();
  }

  private updateClient() {
    if (this.apiKeys.length > 0) {
      this.client = new OpenAI({
        apiKey: this.apiKeys[this.currentKeyIndex]
      });
    }
  }

  isAvailable(): boolean {
    return this.apiKeys.length > 0;
  }

  private rotateKey() {
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    this.updateClient();
    console.log(`🔄 OpenAI rotated to key ${this.currentKeyIndex + 1}/${this.apiKeys.length}`);
  }

  async makeRequest(prompt: string, options: any = {}): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error("OpenAI: No API keys available");
    }

    let attempts = 0;
    const maxAttempts = this.apiKeys.length;

    while (attempts < maxAttempts) {
      try {
        const response = await this.client.chat.completions.create({
          model: options.model || "gpt-4o-mini",
          messages: [{ role: "user", content: prompt }],
          temperature: options.temperature || 0.7,
          max_tokens: options.maxTokens || 1000
        });

        return response.choices[0].message.content || "";
      } catch (error: any) {
        console.error(`OpenAI key ${this.currentKeyIndex + 1} failed:`, error.message);
        
        if (error.code === 'insufficient_quota' || error.status === 429) {
          this.rotateKey();
          attempts++;
          await this.sleep(1000);
          continue;
        }
        
        throw error;
      }
    }

    throw new Error("OpenAI: All API keys exhausted");
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Anthropic Provider
class AnthropicProvider implements AIProvider {
  name = "Anthropic";
  private apiKeys: string[];
  private currentKeyIndex = 0;
  private client: Anthropic;

  constructor(apiKeys: string[]) {
    this.apiKeys = apiKeys.filter(key => key && key.trim() !== '');
    this.updateClient();
  }

  private updateClient(): void {
    if (this.apiKeys.length === 0) return;
    
    const currentKey = this.apiKeys[this.currentKeyIndex];
    this.client = new Anthropic({
      apiKey: currentKey,
    });
  }

  private rotateKey(): void {
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    this.updateClient();
  }

  isAvailable(): boolean {
    return this.apiKeys.length > 0;
  }

  async makeRequest(prompt: string, options: any = {}): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error("Anthropic: No API keys available");
    }

    let attempts = 0;
    const maxAttempts = this.apiKeys.length;

    while (attempts < maxAttempts) {
      try {
        const response = await this.client.messages.create({
          model: "claude-sonnet-4-20250514",
          max_tokens: options.maxTokens || 1000,
          temperature: options.temperature || 0.7,
          messages: [
            {
              role: "user",
              content: prompt
            }
          ],
        });

        return response.content[0].type === 'text' ? response.content[0].text : "";
      } catch (error: any) {
        console.error(`Anthropic key ${this.currentKeyIndex + 1} failed:`, error.message);
        
        if (error.status === 429 || error.status === 402) {
          this.rotateKey();
          attempts++;
          await this.sleep(1000);
          continue;
        }
        
        throw error;
      }
    }

    throw new Error("Anthropic: All API keys exhausted");
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Multi-Provider AI Manager
class MultiProviderAIService {
  private providers: AIProvider[] = [];
  private currentProviderIndex = 0;
  private stats = {
    totalRequests: 0,
    successfulRequests: 0,
    providerUsage: {} as Record<string, { requests: number; errors: number }>
  };

  constructor() {
    this.initializeProviders();
  }

  private initializeProviders() {
    // Initialize Anthropic provider first (highest priority)
    const anthropicKeys = this.getKeysFromEnv('ANTHROPIC_API_KEY');
    if (anthropicKeys.length > 0) {
      const anthropicProvider = new AnthropicProvider(anthropicKeys);
      this.providers.push(anthropicProvider);
      this.stats.providerUsage[anthropicProvider.name] = { requests: 0, errors: 0 };
      console.log(`✅ Anthropic provider initialized with ${anthropicKeys.length} keys`);
    }

    // Initialize DeepSeek provider
    const deepseekKeys = this.getKeysFromEnv('DEEPSEEK_API_KEY');
    if (deepseekKeys.length > 0) {
      const deepseekProvider = new DeepSeekProvider(deepseekKeys);
      this.providers.push(deepseekProvider);
      this.stats.providerUsage[deepseekProvider.name] = { requests: 0, errors: 0 };
      console.log(`✅ DeepSeek provider initialized with ${deepseekKeys.length} keys`);
    }

    // Initialize OpenAI provider
    const openaiKeys = this.getKeysFromEnv('OPENAI_API_KEY');
    if (openaiKeys.length > 0) {
      const openaiProvider = new OpenAIProvider(openaiKeys);
      this.providers.push(openaiProvider);
      this.stats.providerUsage[openaiProvider.name] = { requests: 0, errors: 0 };
      console.log(`✅ OpenAI provider initialized with ${openaiKeys.length} keys`);
    }

    if (this.providers.length === 0) {
      console.warn("⚠️  No AI providers available. Please set DEEPSEEK_API_KEY, OPENAI_API_KEY, or ANTHROPIC_API_KEY");
    }
  }

  private getKeysFromEnv(envVar: string): string[] {
    const keys: string[] = [];
    
    // Check for single key
    const singleKey = process.env[envVar];
    if (singleKey && singleKey.trim() !== '') {
      keys.push(singleKey.trim());
    }
    
    // Check for multiple keys (KEY_1, KEY_2, etc.)
    let index = 1;
    while (true) {
      const key = process.env[`${envVar}_${index}`];
      if (!key || key.trim() === '') break;
      keys.push(key.trim());
      index++;
    }
    
    return keys;
  }

  private getNextAvailableProvider(): AIProvider {
    const availableProviders = this.providers.filter(p => p.isAvailable());
    if (availableProviders.length === 0) {
      throw new Error("No AI providers available");
    }
    
    // Use round-robin selection
    this.currentProviderIndex = this.currentProviderIndex % availableProviders.length;
    return availableProviders[this.currentProviderIndex];
  }

  async generateResponse(prompt: string, options: any = {}): Promise<string> {
    this.stats.totalRequests++;
    
    const maxProviderTries = this.providers.length;
    let lastError: Error | null = null;

    for (let attempt = 0; attempt < maxProviderTries; attempt++) {
      const provider = this.getNextAvailableProvider();
      
      try {
        console.log(`🤖 Trying ${provider.name}...`);
        
        const result = await provider.makeRequest(prompt, options);
        
        // Success!
        this.stats.successfulRequests++;
        this.stats.providerUsage[provider.name].requests++;
        
        console.log(`✅ Success with ${provider.name}`);
        return result;
        
      } catch (error: any) {
        console.error(`❌ ${provider.name} failed:`, error.message);
        this.stats.providerUsage[provider.name].errors++;
        lastError = error;
        
        // Move to next provider
        this.currentProviderIndex = (this.currentProviderIndex + 1) % this.providers.length;
      }
    }

    // If all providers failed, throw the last error
    throw new Error(`All AI providers failed. Last error: ${lastError?.message}`);
  }

  getStats() {
    return {
      ...this.stats,
      successRate: this.stats.totalRequests > 0 
        ? (this.stats.successfulRequests / this.stats.totalRequests * 100).toFixed(2) + '%'
        : '0%',
      availableProviders: this.providers.filter(p => p.isAvailable()).map(p => p.name),
      totalProviders: this.providers.length
    };
  }
}

export const multiProviderAIService = new MultiProviderAIService();