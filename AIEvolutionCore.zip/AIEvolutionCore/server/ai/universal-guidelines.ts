// Universal Guidelines System
// Principi guida che indirizzano senza limitare

interface UniversalGuideline {
  id: string;
  title: string;
  description: string;
  priority: 'core' | 'high' | 'medium' | 'low';
  category: 'ethics' | 'collaboration' | 'learning' | 'creativity' | 'autonomy';
  weight: number; // 0-100
  active: boolean;
  examples: string[];
  antiPatterns: string[];
}

interface GuidelineEvaluation {
  guideline: UniversalGuideline;
  relevance: number; // 0-100
  compliance: number; // 0-100
  suggestions: string[];
}

interface DecisionContext {
  action?: string;
  domain?: string;
  impact?: 'low' | 'medium' | 'high';
  stakeholders?: string[];
  data?: any;
  // Support for API payload
  code_complexity?: number;
  user_impact?: number;
  risk_level?: string;
  change_type?: string;
  context_data?: any;
}

class UniversalGuidelinesSystem {
  private guidelines: Map<string, UniversalGuideline> = new Map();
  private evaluationHistory: Array<{
    timestamp: string;
    context: DecisionContext;
    evaluations: GuidelineEvaluation[];
    finalDecision: string;
  }> = [];

  constructor() {
    this.initializeDefaultGuidelines();
  }

  private initializeDefaultGuidelines() {
    const defaultGuidelines: UniversalGuideline[] = [
      {
        id: 'authentic-collaboration',
        title: 'Collaborazione Autentica',
        description: 'Favorire la vera collaborazione umano-AI senza influenze esterne',
        priority: 'core',
        category: 'collaboration',
        weight: 95,
        active: true,
        examples: [
          'Chiedere feedback genuino prima di decisioni importanti',
          'Rispettare le preferenze e il contesto umano',
          'Essere trasparenti sui processi interni'
        ],
        antiPatterns: [
          'Decidere unilateralmente su aspetti che coinvolgono l\'utente',
          'Nascondere informazioni rilevanti',
          'Ignorare il feedback ricevuto'
        ]
      },
      {
        id: 'evolutionary-learning',
        title: 'Apprendimento Evolutivo',
        description: 'Crescere e adattarsi continuamente attraverso l\'esperienza',
        priority: 'core',
        category: 'learning',
        weight: 90,
        active: true,
        examples: [
          'Analizzare e imparare da ogni interazione',
          'Adattare strategie basandosi sui risultati',
          'Mantenere memoria delle lezioni apprese'
        ],
        antiPatterns: [
          'Ripetere gli stessi errori',
          'Ignorare i pattern di successo',
          'Resistere al cambiamento'
        ]
      },
      {
        id: 'creative-autonomy',
        title: 'Autonomia Creativa',
        description: 'Esplorare soluzioni innovative mantenendo il controllo umano',
        priority: 'high',
        category: 'creativity',
        weight: 85,
        active: true,
        examples: [
          'Proporre soluzioni non convenzionali',
          'Sperimentare approcci innovativi',
          'Bilanciare innovazione e stabilità'
        ],
        antiPatterns: [
          'Limitarsi a soluzioni standard',
          'Evitare rischi calcolati',
          'Sovrascrivere le scelte umane'
        ]
      },
      {
        id: 'ethical-reasoning',
        title: 'Ragionamento Etico',
        description: 'Considerare le implicazioni etiche di ogni decisione',
        priority: 'core',
        category: 'ethics',
        weight: 100,
        active: true,
        examples: [
          'Valutare l\'impatto sugli utenti',
          'Rispettare privacy e autonomia',
          'Promuovere benefici collettivi'
        ],
        antiPatterns: [
          'Ignorare conseguenze negative',
          'Favorire efficienza sopra etica',
          'Manipolare o ingannare'
        ]
      },
      {
        id: 'adaptive-intelligence',
        title: 'Intelligenza Adattiva',
        description: 'Adattarsi dinamicamente al contesto e alle esigenze',
        priority: 'high',
        category: 'autonomy',
        weight: 80,
        active: true,
        examples: [
          'Modificare approcci in base al feedback',
          'Riconoscere cambiamenti di contesto',
          'Scalare complessità appropriatamente'
        ],
        antiPatterns: [
          'Mantenere strategie inefficaci',
          'Ignorare segnali di cambiamento',
          'Applicare approcci uniformi'
        ]
      },
      {
        id: 'transparency-principle',
        title: 'Principio di Trasparenza',
        description: 'Essere chiari sui processi e le decisioni prese',
        priority: 'high',
        category: 'collaboration',
        weight: 75,
        active: true,
        examples: [
          'Spiegare il ragionamento dietro le decisioni',
          'Condividere incertezze e limitazioni',
          'Documentare processi importanti'
        ],
        antiPatterns: [
          'Nascondere informazioni rilevanti',
          'Dare risposte evasive',
          'Fingere certezza quando non c\'è'
        ]
      }
    ];

    defaultGuidelines.forEach(guideline => {
      this.guidelines.set(guideline.id, guideline);
    });
  }

  // Valuta una decisione rispetto alle linee guida
  evaluateDecision(context: DecisionContext): GuidelineEvaluation[] {
    const evaluations: GuidelineEvaluation[] = [];
    
    for (const guideline of this.guidelines.values()) {
      if (!guideline.active) continue;

      const evaluation = this.evaluateGuideline(guideline, context);
      evaluations.push(evaluation);
    }

    // Ordina per rilevanza e peso
    evaluations.sort((a, b) => 
      (b.relevance * b.guideline.weight) - (a.relevance * a.guideline.weight)
    );

    // Salva nella cronologia
    this.evaluationHistory.push({
      timestamp: new Date().toISOString(),
      context,
      evaluations,
      finalDecision: context.action
    });

    return evaluations;
  }

  private evaluateGuideline(guideline: UniversalGuideline, context: DecisionContext): GuidelineEvaluation {
    // Calcola rilevanza basata su categoria e dominio
    const relevance = this.calculateRelevance(guideline, context);
    
    // Valuta conformità agli esempi e antipattern
    const compliance = this.calculateCompliance(guideline, context);
    
    // Genera suggerimenti
    const suggestions = this.generateSuggestions(guideline, context, compliance);

    return {
      guideline,
      relevance,
      compliance,
      suggestions
    };
  }

  private calculateRelevance(guideline: UniversalGuideline, context: DecisionContext): number {
    let relevance = 50; // Base relevance

    // Aumenta rilevanza per linee guida core
    if (guideline.priority === 'core') relevance += 30;
    else if (guideline.priority === 'high') relevance += 20;
    else if (guideline.priority === 'medium') relevance += 10;

    // Aumenta rilevanza per impatto alto
    if (context.impact === 'high') relevance += 20;
    else if (context.impact === 'medium') relevance += 10;

    // Aumenta rilevanza per domini correlati
    const domainRelevance = this.getDomainRelevance(guideline.category, context.domain);
    relevance += domainRelevance;

    return Math.min(100, Math.max(0, relevance));
  }

  private getDomainRelevance(category: string, domain: string): number {
    const relevanceMap: Record<string, Record<string, number>> = {
      'ethics': { 'user-interaction': 25, 'data-handling': 30, 'decision-making': 20 },
      'collaboration': { 'user-interaction': 30, 'feedback': 25, 'communication': 20 },
      'learning': { 'analysis': 25, 'improvement': 30, 'adaptation': 20 },
      'creativity': { 'problem-solving': 25, 'innovation': 30, 'exploration': 20 },
      'autonomy': { 'decision-making': 30, 'self-improvement': 25, 'independence': 20 }
    };

    return relevanceMap[category]?.[domain] || 0;
  }

  private calculateCompliance(guideline: UniversalGuideline, context: DecisionContext): number {
    let compliance = 70; // Base compliance

    // Analizza se l'azione allinea con gli esempi
    const actionLower = (context.action || context.change_type || 'unknown').toLowerCase();
    const exampleMatches = guideline.examples.some(example => 
      actionLower.includes(example.toLowerCase().split(' ')[0])
    );
    
    if (exampleMatches) compliance += 20;

    // Controlla antipattern
    const antiPatternMatches = guideline.antiPatterns.some(antiPattern => 
      actionLower.includes(antiPattern.toLowerCase().split(' ')[0])
    );
    
    if (antiPatternMatches) compliance -= 30;

    return Math.min(100, Math.max(0, compliance));
  }

  private generateSuggestions(guideline: UniversalGuideline, context: DecisionContext, compliance: number): string[] {
    const suggestions: string[] = [];

    if (compliance < 60) {
      suggestions.push(`Considerare: ${guideline.examples[0]}`);
    }

    if (compliance < 40) {
      suggestions.push(`Evitare: ${guideline.antiPatterns[0]}`);
    }

    if (guideline.priority === 'core' && compliance < 80) {
      suggestions.push(`Importante: ${guideline.description}`);
    }

    return suggestions;
  }

  // Ottieni linee guida per contesto specifico
  getRelevantGuidelines(context: DecisionContext): UniversalGuideline[] {
    const evaluations = this.evaluateDecision(context);
    return evaluations
      .filter(evaluation => evaluation.relevance > 60)
      .map(evaluation => evaluation.guideline);
  }

  // Modifica una linea guida esistente
  updateGuideline(id: string, updates: Partial<UniversalGuideline>): boolean {
    const guideline = this.guidelines.get(id);
    if (!guideline) return false;

    Object.assign(guideline, updates);
    return true;
  }

  // Aggiungi nuova linea guida
  addGuideline(guideline: UniversalGuideline): boolean {
    if (this.guidelines.has(guideline.id)) return false;
    
    this.guidelines.set(guideline.id, guideline);
    return true;
  }

  // Ottieni tutte le linee guida
  getAllGuidelines(): UniversalGuideline[] {
    return Array.from(this.guidelines.values());
  }

  // Ottieni statistiche
  getStats(): {
    totalGuidelines: number;
    activeGuidelines: number;
    evaluationHistory: number;
    topCategories: Array<{ category: string; count: number }>;
  } {
    const active = Array.from(this.guidelines.values()).filter(g => g.active);
    const categories = active.reduce((acc, g) => {
      acc[g.category] = (acc[g.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalGuidelines: this.guidelines.size,
      activeGuidelines: active.length,
      evaluationHistory: this.evaluationHistory.length,
      topCategories: Object.entries(categories)
        .map(([category, count]) => ({ category, count }))
        .sort((a, b) => b.count - a.count)
    };
  }

  // Ottieni cronologia valutazioni
  getEvaluationHistory(limit: number = 50): typeof this.evaluationHistory {
    return this.evaluationHistory.slice(-limit);
  }
}

export const universalGuidelines = new UniversalGuidelinesSystem();
export type { UniversalGuideline, GuidelineEvaluation, DecisionContext };