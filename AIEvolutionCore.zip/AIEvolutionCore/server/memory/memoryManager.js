import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const memoryDir = path.join(__dirname, 'rooms');

// Ensure memory directory exists
if (!fs.existsSync(memoryDir)) {
    fs.mkdirSync(memoryDir, { recursive: true });
}

function getMemory(room) {
    const file = path.join(memoryDir, room + '.json');
    if (!fs.existsSync(file)) {
        // Initialize with empty array if file doesn't exist
        fs.writeFileSync(file, JSON.stringify([], null, 2));
        return [];
    }
    try {
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (error) {
        console.error(`Error reading memory room ${room}:`, error);
        return [];
    }
}

function saveMemory(room, data) {
    const file = path.join(memoryDir, room + '.json');
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error saving memory to room ${room}:`, error);
        return false;
    }
}

function addThought(room, newThought, metadata = {}) {
    const thoughts = getMemory(room);
    const thoughtEntry = {
        content: newThought,
        timestamp: new Date().toISOString(),
        id: Date.now() + Math.random().toString(36).substr(2, 9),
        ...metadata
    };
    
    thoughts.push(thoughtEntry);
    
    // Keep only last 100 thoughts per room to prevent infinite growth
    if (thoughts.length > 100) {
        thoughts.splice(0, thoughts.length - 100);
    }
    
    saveMemory(room, thoughts);
    return thoughtEntry;
}

function getRecentThoughts(room, limit = 10) {
    const thoughts = getMemory(room);
    return thoughts.slice(-limit);
}

function searchThoughts(room, query) {
    const thoughts = getMemory(room);
    return thoughts.filter(thought => 
        thought.content.toLowerCase().includes(query.toLowerCase())
    );
}

function reflectOnRoom(room) {
    const thoughts = getMemory(room);
    if (thoughts.length === 0) return null;
    
    const recent = thoughts.slice(-5);
    const summary = {
        totalThoughts: thoughts.length,
        recentActivity: recent,
        lastUpdate: thoughts[thoughts.length - 1]?.timestamp,
        themes: extractThemes(thoughts)
    };
    
    return summary;
}

function extractThemes(thoughts) {
    // Simple theme extraction based on word frequency
    const words = thoughts
        .map(t => t.content.toLowerCase())
        .join(' ')
        .split(/\s+/)
        .filter(word => word.length > 3);
    
    const wordCount = {};
    words.forEach(word => {
        wordCount[word] = (wordCount[word] || 0) + 1;
    });
    
    return Object.entries(wordCount)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5)
        .map(([word, count]) => ({ word, count }));
}

function getAllRooms() {
    try {
        return fs.readdirSync(memoryDir)
            .filter(file => file.endsWith('.json'))
            .map(file => file.replace('.json', ''));
    } catch (error) {
        console.error('Error reading memory rooms:', error);
        return [];
    }
}

export {
    getMemory,
    saveMemory,
    addThought,
    getRecentThoughts,
    searchThoughts,
    reflectOnRoom,
    getAllRooms
};

export default {
    getMemory,
    saveMemory,
    addThought,
    getRecentThoughts,
    searchThoughts,
    reflectOnRoom,
    getAllRooms
};