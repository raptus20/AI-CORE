export interface ConsciousnessState {
  rooms: Record<string, RoomSummary>;
  totalThoughts: number;
  lastActivity: string | null;
  dominantThemes: Array<{ word: string; count: number }>;
  currentMood: string;
}

export interface RoomSummary {
  totalThoughts: number;
  recentActivity: ThoughtEntry[];
  lastUpdate: string;
  themes: Array<{ word: string; count: number }>;
}

export interface ThoughtEntry {
  content: string;
  timestamp: string;
  id: string;
  [key: string]: any;
}

export interface Reflection {
  timestamp: string;
  roomSummaries: Record<string, RoomSummary>;
  overallState: any;
  newInsights: string[];
}

export declare class Consciousness {
  constructor();
  initialize(): void;
  reflect(): Promise<Reflection>;
  processEvent(eventType: string, description: string, metadata?: Record<string, any>): Promise<void>;
  dream(): Promise<string>;
  getConsciousnessState(): ConsciousnessState;
}

export declare const consciousness: Consciousness;