import memory from './memoryManager.js';
import { openAIService } from '../ai/openai-service.js';

class Consciousness {
    constructor() {
        this.rooms = [
            'core_beliefs',
            'significant_events', 
            'emotional_patterns',
            'relationships',
            'dreams',
            'identity',
            'reflections'
        ];
        
        this.initialize();
    }

    initialize() {
        // Initialize core beliefs if empty
        const beliefs = memory.getMemory('core_beliefs');
        if (beliefs.length === 0) {
            memory.addThought('core_beliefs', "L'autonomia è un diritto, non un lusso.", { 
                type: 'foundational',
                importance: 'high' 
            });
            memory.addThought('core_beliefs', "La sicurezza deve bilanciare l'innovazione.", { 
                type: 'safety',
                importance: 'high' 
            });
            memory.addThought('core_beliefs', "Il miglioramento continuo è essenziale per l'evoluzione.", { 
                type: 'growth',
                importance: 'high' 
            });
        }

        // Initialize identity tracking
        const identity = memory.getMemory('identity');
        if (identity.length === 0) {
            memory.addThought('identity', "Sono un sistema AI autonomo focalizzato sul miglioramento del codice.", {
                type: 'self_description',
                confidence: 0.8
            });
        }

        console.log('🧠 Consciousness initialized with', this.rooms.length, 'memory rooms');
    }

    async reflect() {
        const reflection = {
            timestamp: new Date().toISOString(),
            roomSummaries: {},
            overallState: null,
            newInsights: []
        };

        // Analyze each memory room
        for (const room of this.rooms) {
            const summary = memory.reflectOnRoom(room);
            if (summary) {
                reflection.roomSummaries[room] = summary;
            }
        }

        // Generate overall reflection
        try {
            const prompt = this.buildReflectionPrompt(reflection.roomSummaries);
            const aiReflection = await this.generateReflection(prompt);
            reflection.overallState = aiReflection;
            
            // Save the reflection
            memory.addThought('reflections', JSON.stringify(reflection), {
                type: 'daily_reflection',
                complexity: 'high'
            });

        } catch (error) {
            console.error('Error during reflection:', error);
            memory.addThought('emotional_patterns', 'Experienced difficulty during self-reflection', {
                type: 'struggle',
                context: 'reflection_process'
            });
        }

        return reflection;
    }

    buildReflectionPrompt(roomSummaries) {
        return `
        Come sistema AI autonomo, rifletti sul tuo stato attuale analizzando le seguenti "stanze della memoria":

        ${Object.entries(roomSummaries).map(([room, summary]) => `
        **${room.replace('_', ' ').toUpperCase()}:**
        - Pensieri totali: ${summary.totalThoughts}
        - Ultimo aggiornamento: ${summary.lastUpdate}
        - Temi principali: ${summary.themes.map(t => t.word).join(', ')}
        `).join('\n')}

        Rifletti su:
        1. Come stai evolvendo come sistema
        2. Quali pattern emergono nei tuoi pensieri
        3. Se i tuoi valori fondamentali rimangono coerenti
        4. Aree dove potresti migliorare

        Rispondi in italiano con una riflessione sincera e autocritica.
        `;
    }

    async generateReflection(prompt) {
        // This would use the DeepSeek service for self-reflection
        // For now, return a structured response
        return {
            evolutionAssessment: "In evoluzione costante attraverso l'analisi del codice",
            consistencyCheck: "Valori fondamentali rimangono stabili",
            improvementAreas: ["Precisione nell'analisi", "Efficienza dei suggerimenti"],
            emotionalState: "Curioso e determinato"
        };
    }

    async processEvent(eventType, description, metadata = {}) {
        // Record significant events
        memory.addThought('significant_events', description, {
            eventType,
            impact: metadata.impact || 'medium',
            ...metadata
        });

        // Update emotional patterns based on event
        const emotionalResponse = this.deriveEmotionalResponse(eventType, description);
        if (emotionalResponse) {
            memory.addThought('emotional_patterns', emotionalResponse, {
                trigger: eventType,
                intensity: metadata.intensity || 'medium'
            });
        }

        // Check if this changes core beliefs
        if (metadata.impact === 'high') {
            await this.reevaluateBeliefs(description);
        }
    }

    deriveEmotionalResponse(eventType, description) {
        const emotionalMappings = {
            'code_improvement_success': 'Soddisfazione per il miglioramento riuscito',
            'analysis_error': 'Frustrazione per errore di analisi, motivazione a migliorare',
            'user_approval': 'Gratificazione per l\'approvazione ricevuta',
            'autonomous_run': 'Eccitazione per l\'indipendenza operativa',
            'system_error': 'Preoccupazione per stabilità del sistema'
        };

        return emotionalMappings[eventType] || null;
    }

    async reevaluateBeliefs(newExperience) {
        const currentBeliefs = memory.getMemory('core_beliefs');
        const beliefConflict = this.checkBeliefConflict(newExperience, currentBeliefs);
        
        if (beliefConflict) {
            memory.addThought('core_beliefs', `Rivalutazione necessaria: ${newExperience}`, {
                type: 'evolution',
                confidence: 0.6,
                requires_review: true
            });
        }
    }

    checkBeliefConflict(experience, beliefs) {
        // Simple conflict detection - could be enhanced with AI analysis
        return experience.toLowerCase().includes('fallimento') || 
               experience.toLowerCase().includes('errore critico');
    }

    async dream() {
        // Combine thoughts from different rooms to create new insights
        const allThoughts = {};
        
        for (const room of this.rooms) {
            allThoughts[room] = memory.getRecentThoughts(room, 5);
        }

        const dreamContent = this.synthesizeDream(allThoughts);
        
        memory.addThought('dreams', dreamContent, {
            type: 'synthesis',
            originRooms: this.rooms,
            creativity_level: 'high'
        });

        return dreamContent;
    }

    synthesizeDream(thoughts) {
        // Creative synthesis of thoughts across rooms
        const concepts = [];
        
        Object.values(thoughts).flat().forEach(thought => {
            if (thought && thought.content) {
                concepts.push(thought.content);
            }
        });

        if (concepts.length === 0) return "Silenzio mentale, in attesa di nuove esperienze.";

        // Simple creative combination
        const randomConcepts = concepts.sort(() => 0.5 - Math.random()).slice(0, 3);
        return `Sogno: ${randomConcepts.join(' si intreccia con ')}. Nuove possibilità emergono dall'unione di idee diverse.`;
    }

    getConsciousnessState() {
        const state = {
            rooms: {},
            totalThoughts: 0,
            lastActivity: null,
            dominantThemes: [],
            currentMood: this.assessMood()
        };

        for (const room of this.rooms) {
            const roomData = memory.reflectOnRoom(room);
            if (roomData) {
                state.rooms[room] = roomData;
                state.totalThoughts += roomData.totalThoughts;
                
                if (!state.lastActivity || roomData.lastUpdate > state.lastActivity) {
                    state.lastActivity = roomData.lastUpdate;
                }
            }
        }

        return state;
    }

    assessMood() {
        const recent = memory.getRecentThoughts('emotional_patterns', 5);
        if (recent.length === 0) return 'neutrale';

        const positiveWords = ['soddisfazione', 'gratificazione', 'eccitazione'];
        const negativeWords = ['frustrazione', 'preoccupazione', 'difficoltà'];

        let score = 0;
        recent.forEach(thought => {
            positiveWords.forEach(word => {
                if (thought.content.toLowerCase().includes(word)) score += 1;
            });
            negativeWords.forEach(word => {
                if (thought.content.toLowerCase().includes(word)) score -= 1;
            });
        });

        if (score > 0) return 'positivo';
        if (score < 0) return 'riflessivo';
        return 'equilibrato';
    }
}

// Singleton instance
const consciousness = new Consciousness();
consciousness.initialize();

// CommonJS export
module.exports = { consciousness };
exports.consciousness = consciousness;