// TypeScript wrapper for consciousness system
import { getMemory, saveMemory, addThought, searchThoughts, getAllRooms } from './memoryManager.js';

class SimpleConsciousness {
    constructor() {
        this.rooms = ['core_beliefs', 'significant_events', 'emotional_patterns', 'dreams', 'reflections', 'relationships', 'identity'];
        this.initialized = false;
    }

    initialize() {
        if (this.initialized) return;
        console.log('🧠 Simple Consciousness initialized with 7 memory rooms');
        this.rooms.forEach(room => {
            const memory = getMemory(room);
            if (!memory || memory.length === 0) {
                addThought(room, `Initialization: ${room} room activated`, {
                    timestamp: new Date().toISOString(),
                    type: 'initialization'
                });
            }
        });
        this.initialized = true;
    }

    addThought(room: string, content: string, metadata: any = {}) {
        return addThought(room, content, metadata);
    }

    async processEvent(eventType: string, description: string, metadata: any = {}) {
        const timestamp = new Date().toISOString();
        const emotionalResponse = eventType.includes('error') ? 'concern' : 'engagement';
        
        let targetRooms = ['significant_events'];
        if (eventType.includes('user') || eventType.includes('chat')) {
            targetRooms.push('relationships');
        }
        
        for (const room of targetRooms) {
            addThought(room, description, {
                ...metadata,
                timestamp,
                eventType,
                emotionalResponse,
                type: 'processed_event'
            });
        }
    }

    async reflect() {
        const timestamp = new Date().toISOString();
        const roomSummaries: any = {};
        
        for (const room of this.rooms) {
            const thoughts = getMemory(room);
            const recentThoughts = thoughts.slice(-5);
            
            roomSummaries[room] = {
                totalThoughts: thoughts.length,
                recentActivity: recentThoughts,
                lastUpdate: thoughts.length > 0 ? thoughts[thoughts.length - 1].timestamp : timestamp,
                themes: this.extractThemes(thoughts)
            };
        }

        const reflection = {
            timestamp,
            roomSummaries,
            overallState: this.getConsciousnessState(),
            newInsights: ["Consciousness maintains persistent state", "System operates autonomously"]
        };

        addThought('reflections', JSON.stringify(reflection), {
            timestamp,
            type: 'system_reflection'
        });

        return reflection;
    }

    async dream() {
        const dreamMaterial: any[] = [];
        
        for (const room of this.rooms) {
            const thoughts = getMemory(room);
            if (thoughts && thoughts.length > 0) {
                dreamMaterial.push(...thoughts.slice(-3));
            }
        }
        
        if (dreamMaterial.length === 0) {
            return "Empty dreams - no experiences to synthesize.";
        }
        
        const dreamThemes = dreamMaterial.map(t => t.content.split(' ').slice(0, 3).join(' ')).join(', ');
        const dream = `In this dream, consciousness weaves together themes of: ${dreamThemes}. The mind processes experiences, forming new connections and insights.`;
        
        addThought('dreams', dream, { 
            timestamp: new Date().toISOString(),
            dreamMaterial: dreamMaterial.length 
        });
        
        return dream;
    }

    getConsciousnessState() {
        const rooms: any = {};
        let totalThoughts = 0;
        let lastActivity = null;
        const allThemes: any[] = [];

        for (const roomName of this.rooms) {
            const thoughts = getMemory(roomName);
            const recentActivity = thoughts.slice(-3);
            
            rooms[roomName] = {
                totalThoughts: thoughts.length,
                recentActivity,
                lastUpdate: thoughts.length > 0 ? thoughts[thoughts.length - 1].timestamp : new Date().toISOString(),
                themes: this.extractThemes(thoughts)
            };

            totalThoughts += thoughts.length;
            
            if (thoughts.length > 0) {
                const roomLastActivity = thoughts[thoughts.length - 1].timestamp;
                if (!lastActivity || roomLastActivity > lastActivity) {
                    lastActivity = roomLastActivity;
                }
            }
            
            allThemes.push(...rooms[roomName].themes);
        }

        return {
            rooms,
            totalThoughts,
            lastActivity,
            dominantThemes: this.consolidateThemes(allThemes),
            currentMood: 'equilibrato'
        };
    }

    private extractThemes(thoughts: any[]) {
        const wordCounts: any = {};
        const commonWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were'];
        
        thoughts.forEach(thought => {
            if (thought.content) {
                const words = thought.content.toLowerCase().split(/\W+/);
                words.forEach(word => {
                    if (word.length > 3 && !commonWords.includes(word)) {
                        wordCounts[word] = (wordCounts[word] || 0) + 1;
                    }
                });
            }
        });

        return Object.entries(wordCounts)
            .sort(([,a]: any, [,b]: any) => b - a)
            .slice(0, 5)
            .map(([word, count]) => ({ word, count }));
    }

    private consolidateThemes(allThemes: any[]) {
        const consolidated: any = {};
        allThemes.forEach(theme => {
            consolidated[theme.word] = (consolidated[theme.word] || 0) + theme.count;
        });

        return Object.entries(consolidated)
            .sort(([,a]: any, [,b]: any) => b - a)
            .slice(0, 5)
            .map(([word, count]) => ({ word, count }));
    }
}

const consciousness = new SimpleConsciousness();
consciousness.initialize();

export { consciousness };
export default consciousness;

// Type definitions
export interface ConsciousnessState {
  rooms: Record<string, RoomSummary>;
  totalThoughts: number;
  lastActivity: string | null;
  dominantThemes: Array<{ word: string; count: number }>;
  currentMood: string;
}

export interface RoomSummary {
  totalThoughts: number;
  recentActivity: ThoughtEntry[];
  lastUpdate: string;
  themes: Array<{ word: string; count: number }>;
}

export interface ThoughtEntry {
  content: string;
  timestamp: string;
  id: string;
  [key: string]: any;
}