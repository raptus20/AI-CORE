import {
  users, type User, type InsertUser,
  codeSuggestions, type CodeSuggestion, type InsertCodeSuggestion,
  sandboxTests, type SandboxTest, type InsertSandboxTest,
  activityLogs, type ActivityLog, type InsertActivityLog,
  systemMetrics, type SystemMetrics, type InsertSystemMetrics
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Code suggestion operations
  getCodeSuggestions(): Promise<CodeSuggestion[]>;
  getCodeSuggestion(id: number): Promise<CodeSuggestion | undefined>;
  createCodeSuggestion(suggestion: InsertCodeSuggestion): Promise<CodeSuggestion>;
  updateCodeSuggestionStatus(id: number, status: string): Promise<CodeSuggestion | undefined>;

  // Sandbox test operations
  getSandboxTests(): Promise<SandboxTest[]>;
  getSandboxTestsByStatus(status: string): Promise<SandboxTest[]>;
  getSandboxTest(id: number): Promise<SandboxTest | undefined>;
  getSandboxTestByTestId(testId: string): Promise<SandboxTest | undefined>;
  createSandboxTest(test: InsertSandboxTest): Promise<SandboxTest>;
  updateSandboxTest(id: number, updates: Partial<InsertSandboxTest>): Promise<SandboxTest | undefined>;

  // Activity log operations
  getActivityLogs(limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;

  // System metrics operations
  getLatestSystemMetrics(): Promise<SystemMetrics | undefined>;
  createSystemMetrics(metrics: InsertSystemMetrics): Promise<SystemMetrics>;

  // Chat operations
  getChatSession(sessionId: string): Promise<{ session: ChatSession; messages: ChatMessage[] } | undefined>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  updateChatSessionActivity(sessionId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private codeSuggestions: Map<number, CodeSuggestion>;
  private sandboxTests: Map<number, SandboxTest>;
  private activityLogs: Map<number, ActivityLog>;
  private systemMetrics: Map<number, SystemMetrics>;
  private chatSessions: Map<string, ChatSession>;
  private chatMessages: Map<string, ChatMessage[]>;

  private userId: number;
  private suggestionId: number;
  private testId: number;
  private logId: number;
  private metricsId: number;
  private messageId: number;

  constructor() {
    this.users = new Map();
    this.codeSuggestions = new Map();
    this.sandboxTests = new Map();
    this.activityLogs = new Map();
    this.systemMetrics = new Map();
    this.chatSessions = new Map();
    this.chatMessages = new Map();

    this.userId = 1;
    this.suggestionId = 1;
    this.testId = 1;
    this.logId = 1;
    this.metricsId = 1;
    this.messageId = 1;

    // Initialize with default admin user
    this.createUser({
      username: "admin",
      password: "admin",
      role: "admin"
    });

    // Initialize with example system metrics
    this.createSystemMetrics({
      memoryUsage: 68,
      cpuLoad: 42,
      storage: 89,
      safetyProtocols: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Code suggestion operations
  async getCodeSuggestions(): Promise<CodeSuggestion[]> {
    return Array.from(this.codeSuggestions.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getCodeSuggestion(id: number): Promise<CodeSuggestion | undefined> {
    return this.codeSuggestions.get(id);
  }

  async createCodeSuggestion(suggestion: InsertCodeSuggestion): Promise<CodeSuggestion> {
    const id = this.suggestionId++;
    const now = new Date();
    const codeSuggestion: CodeSuggestion = {
      ...suggestion,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.codeSuggestions.set(id, codeSuggestion);

    // Create activity log for new suggestion
    await this.createActivityLog({
      eventType: "suggestion",
      description: `AI suggested new optimization for ${suggestion.title}`,
      relatedEntityId: id,
      relatedEntityType: "code_suggestion"
    });

    return codeSuggestion;
  }

  async updateCodeSuggestionStatus(id: number, status: string): Promise<CodeSuggestion | undefined> {
    const suggestion = this.codeSuggestions.get(id);
    if (!suggestion) return undefined;

    const updatedSuggestion = {
      ...suggestion,
      status,
      updatedAt: new Date()
    };
    this.codeSuggestions.set(id, updatedSuggestion);

    // Create activity log for status update
    const eventType = status === "approved" ? "approval" : 
                      status === "rejected" ? "rejection" : 
                      status === "testing" ? "testing" : "update";
    
    await this.createActivityLog({
      eventType,
      description: `Code change ${status} for ${suggestion.title}`,
      relatedEntityId: id,
      relatedEntityType: "code_suggestion"
    });

    return updatedSuggestion;
  }

  // Sandbox test operations
  async getSandboxTests(): Promise<SandboxTest[]> {
    return Array.from(this.sandboxTests.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getSandboxTestsByStatus(status: string): Promise<SandboxTest[]> {
    return Array.from(this.sandboxTests.values())
      .filter(test => test.status === status)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getSandboxTest(id: number): Promise<SandboxTest | undefined> {
    return this.sandboxTests.get(id);
  }

  async getSandboxTestByTestId(testId: string): Promise<SandboxTest | undefined> {
    return Array.from(this.sandboxTests.values()).find(
      (test) => test.testId === testId
    );
  }

  async createSandboxTest(test: InsertSandboxTest): Promise<SandboxTest> {
    const id = this.testId++;
    const now = new Date();
    const sandboxTest: SandboxTest = {
      ...test,
      id,
      createdAt: now
    };
    this.sandboxTests.set(id, sandboxTest);

    // Create activity log for new test
    await this.createActivityLog({
      eventType: "test",
      description: `Sandbox test started for ${test.moduleName}`,
      relatedEntityId: id,
      relatedEntityType: "sandbox_test"
    });

    return sandboxTest;
  }

  async updateSandboxTest(id: number, updates: Partial<InsertSandboxTest>): Promise<SandboxTest | undefined> {
    const test = this.sandboxTests.get(id);
    if (!test) return undefined;

    const updatedTest = {
      ...test,
      ...updates
    };
    this.sandboxTests.set(id, updatedTest);

    // If status is completed, create activity log
    if (updates.status === "completed") {
      await this.createActivityLog({
        eventType: "test_completed",
        description: `Sandbox test completed for ${test.moduleName} with result: ${updates.result || "unknown"}`,
        relatedEntityId: id,
        relatedEntityType: "sandbox_test"
      });
    }

    return updatedTest;
  }

  // Activity log operations
  async getActivityLogs(limit?: number): Promise<ActivityLog[]> {
    const logs = Array.from(this.activityLogs.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return limit ? logs.slice(0, limit) : logs;
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.logId++;
    const now = new Date();
    const activityLog: ActivityLog = {
      ...log,
      id,
      createdAt: now.toISOString()
    };
    this.activityLogs.set(id, activityLog);
    return activityLog;
  }

  // System metrics operations
  async getLatestSystemMetrics(): Promise<SystemMetrics | undefined> {
    const metrics = Array.from(this.systemMetrics.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return metrics.length > 0 ? metrics[0] : undefined;
  }

  async createSystemMetrics(metrics: InsertSystemMetrics): Promise<SystemMetrics> {
    const id = this.metricsId++;
    const now = new Date();
    const systemMetric: SystemMetrics = {
      ...metrics,
      id,
      createdAt: now.toISOString()
    };
    this.systemMetrics.set(id, systemMetric);
    return systemMetric;
  }

  async getChatSession(sessionId: string): Promise<{ session: ChatSession; messages: ChatMessage[] } | undefined> {
    const session = this.chatSessions.get(sessionId);
    if (!session) return undefined;
    
    const messages = this.chatMessages.get(sessionId) || [];
    return { session, messages };
  }

  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const session: ChatSession = {
      ...insertSession,
      id: Date.now(),
      createdAt: new Date(),
      lastActivity: new Date(),
    };
    
    this.chatSessions.set(session.sessionId, session);
    this.chatMessages.set(session.sessionId, []);
    return session;
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.messageId++;
    const message: ChatMessage = {
      ...insertMessage,
      id,
      timestamp: new Date(),
    };
    
    const messages = this.chatMessages.get(message.sessionId) || [];
    messages.push(message);
    this.chatMessages.set(message.sessionId, messages);
    
    // Update session activity
    await this.updateChatSessionActivity(message.sessionId);
    
    return message;
  }

  async updateChatSessionActivity(sessionId: string): Promise<void> {
    const session = this.chatSessions.get(sessionId);
    if (session) {
      session.lastActivity = new Date();
      this.chatSessions.set(sessionId, session);
    }
  }
}

export const storage = new MemStorage();
